using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Exceptions;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class TestService : ITestService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public TestService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<Test>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<Test> tests = await context.Tests.AsNoTracking().Where(x => x.IsActive).OrderByDescending(x => x.AssessmentDate).ToListAsync();
        tests.ForEach(NormalizeUtc);
        return tests;
    }

    public async Task<Test?> GetByIdAsync(int testId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Test? test = await context.Tests.AsNoTracking().FirstOrDefaultAsync(x => x.TestID == testId);

        if (test is not null)
        {
            NormalizeUtc(test);
        }

        return test;
    }

    private static void NormalizeUtc(Test test)
    {
        test.AssessmentDate = DateTime.SpecifyKind(test.AssessmentDate, DateTimeKind.Utc);
        test.CreatedOn = DateTime.SpecifyKind(test.CreatedOn, DateTimeKind.Utc);
    }

    public async Task<Test> CreateAsync(Test test)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        await EnsureUniqueNameAsync(context, test.TestName, excludeTestId: null);
        test.AssessmentDate = DateTime.SpecifyKind(test.AssessmentDate, DateTimeKind.Utc);
        test.CreatedOn = DateTime.SpecifyKind(test.CreatedOn, DateTimeKind.Utc);
        context.Tests.Add(test);
        await context.SaveChangesAsync();
        return test;
    }

    public async Task<Test> UpdateAsync(Test test)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        await EnsureUniqueNameAsync(context, test.TestName, excludeTestId: test.TestID);

        BatchStatus? newStatus = await context.BatchStatuses.AsNoTracking().FirstOrDefaultAsync(x => x.BatchStatusID == test.BatchStatusID);

        if (newStatus?.BatchStatusName == "Completed")
        {
            bool anyIncomplete = await context.ScenarioAssignments
                .AsNoTracking()
                .AnyAsync(x => x.TestID == test.TestID && x.CompletedOn == null);

            if (anyIncomplete)
            {
                throw new InvalidOperationException("This test can't be marked Completed yet — some Sales Reps haven't finished their assigned scenarios.");
            }
        }

        test.AssessmentDate = DateTime.SpecifyKind(test.AssessmentDate, DateTimeKind.Utc);
        test.CreatedOn = DateTime.SpecifyKind(test.CreatedOn, DateTimeKind.Utc);
        context.Tests.Update(test);
        await context.SaveChangesAsync();
        return test;
    }

    private static async Task EnsureUniqueNameAsync(SalesAssessmentDbContext context, string testName, int? excludeTestId)
    {
        string normalizedName = (testName ?? string.Empty).Trim();

        bool nameTaken = await context.Tests
            .AsNoTracking()
            .Where(x => x.IsActive && (excludeTestId == null || x.TestID != excludeTestId))
            .AnyAsync(x => x.TestName.ToLower() == normalizedName.ToLower());

        if (nameTaken)
        {
            throw new DuplicateNameException(nameof(Test.TestName), $"An assessment named \"{normalizedName}\" already exists. Please choose a different name.");
        }
    }

    public async Task<bool> DeleteAsync(int testId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Test? test = await context.Tests.FindAsync(testId);
        if (test is null)
        {
            return false;
        }

        // Tests are referenced by ScenarioAssignment and TestQuestion, so a hard delete
        // would violate FK constraints or orphan those rows. Hide instead.
        test.IsActive = false;
        await context.SaveChangesAsync();
        return true;
    }
}
