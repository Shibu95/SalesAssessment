using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Models;
using System.Text.Json;

namespace SalesAssessment.Web.Services;

public sealed class AssessmentResultService : IAssessmentResultService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public AssessmentResultService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task SaveAsync(AssessmentResult result)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.AssessmentResults.Add(result);
        await context.SaveChangesAsync();
    }

    public async Task<List<AssessmentResult>> GetBySalesRepAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> attemptIds = await context.AssessmentAttempts.Where(x => x.SalesRepID == salesRepId).Select(x => x.AssessmentAttemptID).ToListAsync();
        return await context.AssessmentResults.AsNoTracking().Where(x => attemptIds.Contains(x.AssessmentAttemptID)).OrderByDescending(x => x.CreatedOn).ToListAsync();
    }

    public async Task<AssessmentResult?> GetByAttemptAsync(int attemptId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        return await context.AssessmentResults.AsNoTracking().FirstOrDefaultAsync(x => x.AssessmentAttemptID == attemptId);
    }

    public async Task<AssessmentResult?> GetLatestBySalesRepAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        List<int> attemptIds = await context.AssessmentAttempts.Where(x => x.SalesRepID == salesRepId).Select(x => x.AssessmentAttemptID).ToListAsync();

        return await context.AssessmentResults.AsNoTracking().Where(x => attemptIds.Contains(x.AssessmentAttemptID)).OrderByDescending(x => x.CreatedOn).FirstOrDefaultAsync();
    }

    public async Task<List<HomeAssessmentViewModel>> GetDashboardReportsAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        List<int> attemptIds = await context.AssessmentAttempts.Where(x => x.SalesRepID == salesRepId).Select(x => x.AssessmentAttemptID).ToListAsync();

        return await BuildDashboardReportsAsync(context, attemptIds);
    }

    public async Task<List<HomeAssessmentViewModel>> GetDashboardReportsAsync(int salesRepId, int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        List<int> assignmentIds = await context.ScenarioAssignments
            .Where(a => a.SalesRepID == salesRepId && a.TestID != null)
            .Join(context.Tests.Where(t => t.BatchID == batchId), a => a.TestID, t => t.TestID, (a, t) => a.ScenarioAssignmentID)
            .ToListAsync();

        List<int> attemptIds = await context.AssessmentAttempts
            .Where(x => x.SalesRepID == salesRepId && assignmentIds.Contains(x.ScenarioAssignmentID))
            .Select(x => x.AssessmentAttemptID)
            .ToListAsync();

        return await BuildDashboardReportsAsync(context, attemptIds);
    }

    private static async Task<List<HomeAssessmentViewModel>> BuildDashboardReportsAsync(SalesAssessmentDbContext context, List<int> attemptIds)
    {
        List<AssessmentResult> results = await context.AssessmentResults.AsNoTracking().Where(x => attemptIds.Contains(x.AssessmentAttemptID)).OrderByDescending(x => x.CreatedOn).ToListAsync();

        List<HomeAssessmentViewModel> reports = [];

        foreach (AssessmentResult item in results)
        {
            AssessmentAttempt? attempt = await context.AssessmentAttempts.FirstOrDefaultAsync(x => x.AssessmentAttemptID == item.AssessmentAttemptID);

            Scenario? scenario = await context.Scenarios.FirstOrDefaultAsync(x => x.ScenarioID == attempt!.ScenarioID);

            EvaluationReport report = System.Text.Json.JsonSerializer.Deserialize<EvaluationReport>(item.EvaluationJson, new JsonSerializerOptions
            {
                PropertyNameCaseInsensitive = true
            }) ?? new();

            reports.Add(new HomeAssessmentViewModel
            {
                AssessmentResultID = item.AssessmentResultID,
                ScenarioTitle = scenario?.Title ?? "Unknown",
                CompletedOn = item.CreatedOn,
                Report = report
            });
        }
        return reports;
    }
    public async Task<AssessmentResult?> GetByIdAsync(int assessmentResultId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.AssessmentResults.AsNoTracking().FirstOrDefaultAsync(x => x.AssessmentResultID == assessmentResultId);
    }
}