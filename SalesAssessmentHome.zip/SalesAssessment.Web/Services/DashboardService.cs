using System.Text.Json;
using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public sealed class DashboardService : IDashboardService
{
    private const int OverdueAfterDays = 7;

    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public DashboardService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<DashboardSummaryViewModel> GetSummaryAsync(List<int>? batchIds)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> repIds = await ResolveSalesRepIdsAsync(context, batchIds);

        DateTime monthStart = new(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1, 0, 0, 0, DateTimeKind.Utc);
        int assignedThisMonth = await context.ScenarioAssignments
            .AsNoTracking()
            .Where(x => repIds.Contains(x.SalesRepID) && x.AssignedOn >= monthStart)
            .CountAsync();

        List<Batch> batches = batchIds is null
            ? await context.Batches.AsNoTracking().ToListAsync()
            : await context.Batches.AsNoTracking().Where(x => batchIds.Contains(x.BatchID)).ToListAsync();

        int? startedStatusId = await context.BatchStatuses
            .AsNoTracking()
            .Where(x => x.BatchStatusName == "Started")
            .Select(x => (int?)x.BatchStatusID)
            .FirstOrDefaultAsync();

        int activeBatches = startedStatusId.HasValue ? batches.Count(x => x.BatchStatusID == startedStatusId.Value) : 0;

        int totalAssignments = await context.ScenarioAssignments.AsNoTracking().Where(x => repIds.Contains(x.SalesRepID)).CountAsync();
        int completedAssignments = await context.ScenarioAssignments.AsNoTracking().Where(x => repIds.Contains(x.SalesRepID) && x.CompletedOn != null).CountAsync();
        decimal completionRate = totalAssignments == 0 ? 0 : Math.Round(completedAssignments * 100m / totalAssignments, 1);

        List<int> attemptIdsForReps = await context.AssessmentAttempts
            .AsNoTracking()
            .Where(x => repIds.Contains(x.SalesRepID))
            .Select(x => x.AssessmentAttemptID)
            .ToListAsync();

        decimal? avgScore = await context.AssessmentResults
            .AsNoTracking()
            .Where(x => attemptIdsForReps.Contains(x.AssessmentAttemptID))
            .Select(x => (decimal?)x.OverallScore)
            .AverageAsync();

        return new DashboardSummaryViewModel
        {
            TotalSalesReps = repIds.Count,
            AssignedThisMonth = assignedThisMonth,
            ActiveBatches = activeBatches,
            CompletionRatePercent = completionRate,
            AverageScorePercent = avgScore.HasValue ? Math.Round(avgScore.Value, 1) : null
        };
    }

    public async Task<List<DashboardTrendPointViewModel>> GetTrendAsync(List<int>? batchIds, int weeks = 6)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> repIds = await ResolveSalesRepIdsAsync(context, batchIds);

        DateTime today = DateTime.UtcNow.Date;
        DateTime currentWeekStart = today.AddDays(-(int)today.DayOfWeek);
        DateTime rangeStart = currentWeekStart.AddDays(-7 * (weeks - 1));

        var attempts = await context.AssessmentAttempts
            .AsNoTracking()
            .Where(x => repIds.Contains(x.SalesRepID) && x.CompletedOn != null && x.CompletedOn >= rangeStart)
            .Select(x => new { x.AssessmentAttemptID, x.CompletedOn })
            .ToListAsync();

        List<int> attemptIds = attempts.Select(x => x.AssessmentAttemptID).ToList();
        Dictionary<int, decimal> scoreByAttempt = (await context.AssessmentResults
            .AsNoTracking()
            .Where(x => attemptIds.Contains(x.AssessmentAttemptID))
            .ToListAsync())
            .GroupBy(x => x.AssessmentAttemptID)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(r => r.CreatedOn).First().OverallScore);

        List<DashboardTrendPointViewModel> points = [];

        for (int i = weeks - 1; i >= 0; i--)
        {
            DateTime weekStart = currentWeekStart.AddDays(-7 * i);
            DateTime weekEnd = weekStart.AddDays(7);

            List<decimal> scores = attempts
                .Where(a => a.CompletedOn!.Value.Date >= weekStart && a.CompletedOn.Value.Date < weekEnd)
                .Select(a => scoreByAttempt.TryGetValue(a.AssessmentAttemptID, out decimal score) ? (decimal?)score : null)
                .Where(s => s.HasValue)
                .Select(s => s!.Value)
                .ToList();

            int completedCount = attempts.Count(a => a.CompletedOn!.Value.Date >= weekStart && a.CompletedOn.Value.Date < weekEnd);

            points.Add(new DashboardTrendPointViewModel
            {
                WeekStart = weekStart,
                CompletedCount = completedCount,
                AverageScore = scores.Count == 0 ? null : Math.Round(scores.Average(), 1)
            });
        }

        return points;
    }

    public async Task<DashboardPendingBreakdownViewModel> GetPendingBreakdownAsync(List<int>? batchIds)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> repIds = await ResolveSalesRepIdsAsync(context, batchIds);

        List<ScenarioAssignment> pending = await context.ScenarioAssignments
            .AsNoTracking()
            .Where(x => repIds.Contains(x.SalesRepID) && x.CompletedOn == null)
            .ToListAsync();

        List<int> assignmentIds = pending.Select(x => x.ScenarioAssignmentID).ToList();
        HashSet<int> startedAssignmentIds = (await context.AssessmentAttempts
            .AsNoTracking()
            .Where(x => assignmentIds.Contains(x.ScenarioAssignmentID))
            .Select(x => x.ScenarioAssignmentID)
            .Distinct()
            .ToListAsync())
            .ToHashSet();

        DateTime overdueThreshold = DateTime.UtcNow.AddDays(-OverdueAfterDays);

        DashboardPendingBreakdownViewModel breakdown = new();

        foreach (ScenarioAssignment item in pending)
        {
            if (startedAssignmentIds.Contains(item.ScenarioAssignmentID))
            {
                breakdown.InProgress++;
            }
            else if (item.AssignedOn <= overdueThreshold)
            {
                breakdown.Overdue++;
            }
            else
            {
                breakdown.NotStarted++;
            }
        }

        return breakdown;
    }

    public async Task<List<RecentAssessmentViewModel>> GetRecentAssessmentsAsync(List<int>? batchIds, int take = 100)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> repIds = await ResolveSalesRepIdsAsync(context, batchIds);

        List<ScenarioAssignment> assignments = await context.ScenarioAssignments
            .AsNoTracking()
            .Where(x => repIds.Contains(x.SalesRepID))
            .OrderByDescending(x => x.AssignedOn)
            .Take(take)
            .ToListAsync();

        return await BuildAssessmentViewModelsAsync(context, assignments);
    }

    // Every ScenarioAssignment under this Batch's Tests, regardless of which batch(es) the
    // assignee is otherwise enrolled in. Deliberately NOT built on ResolveSalesRepIdsAsync
    // (rep-membership) like the method above - that resolves "reps enrolled in this batch" and
    // then pulls ALL of their assignments, which would leak assignments that actually belong to
    // a different batch's Test for any rep enrolled in more than one batch. This joins through
    // Test.BatchID directly instead, same pattern already used by
    // AssessmentResultService.GetDashboardReportsAsync(salesRepId, batchId) for a single rep.
    public async Task<List<RecentAssessmentViewModel>> GetBatchParticipantResultsAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        List<ScenarioAssignment> assignments = await context.ScenarioAssignments
            .AsNoTracking()
            .Where(a => a.TestID != null)
            .Join(context.Tests.Where(t => t.BatchID == batchId), a => a.TestID, t => t.TestID, (a, t) => a)
            .OrderByDescending(x => x.AssignedOn)
            .ToListAsync();

        return await BuildAssessmentViewModelsAsync(context, assignments);
    }

    private async Task<List<RecentAssessmentViewModel>> BuildAssessmentViewModelsAsync(SalesAssessmentDbContext context, List<ScenarioAssignment> assignments)
    {
        List<int> assignmentIds = assignments.Select(x => x.ScenarioAssignmentID).ToList();
        List<int> scenarioIds = assignments.Select(x => x.ScenarioID).Distinct().ToList();
        List<int> repIdsInSet = assignments.Select(x => x.SalesRepID).Distinct().ToList();

        Dictionary<int, string> scenarioTitles = await context.Scenarios
            .AsNoTracking()
            .Where(x => scenarioIds.Contains(x.ScenarioID))
            .ToDictionaryAsync(x => x.ScenarioID, x => x.Title);

        Dictionary<int, SalesRep> reps = await context.SalesReps
            .AsNoTracking()
            .Where(x => repIdsInSet.Contains(x.SalesRepID))
            .ToDictionaryAsync(x => x.SalesRepID, x => x);

        // A Sales Rep can now be enrolled in more than one batch at once, so "which batch is this
        // assignment for" can no longer be read off the rep — it comes from the Test the
        // assignment was generated from instead (Test.BatchID is the assignment's real batch
        // lineage, same mechanism the rest of the app already uses for batch-scoping assignments).
        List<int> testIds = assignments.Where(x => x.TestID.HasValue).Select(x => x.TestID!.Value).Distinct().ToList();
        Dictionary<int, int> batchIdByTest = await context.Tests
            .AsNoTracking()
            .Where(x => testIds.Contains(x.TestID))
            .ToDictionaryAsync(x => x.TestID, x => x.BatchID);

        List<int> batchIdsInSet = batchIdByTest.Values.Distinct().ToList();
        Dictionary<int, string> batchNames = await context.Batches
            .AsNoTracking()
            .Where(x => batchIdsInSet.Contains(x.BatchID))
            .ToDictionaryAsync(x => x.BatchID, x => x.BatchName);

        List<AssessmentAttempt> attempts = await context.AssessmentAttempts
            .AsNoTracking()
            .Where(x => assignmentIds.Contains(x.ScenarioAssignmentID))
            .ToListAsync();

        Dictionary<int, AssessmentAttempt> attemptByAssignment = attempts
            .GroupBy(x => x.ScenarioAssignmentID)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(a => a.StartedOn).First());

        List<int> attemptIds = attempts.Select(x => x.AssessmentAttemptID).ToList();
        Dictionary<int, AssessmentResult> resultByAttempt = (await context.AssessmentResults
            .AsNoTracking()
            .Where(x => attemptIds.Contains(x.AssessmentAttemptID))
            .ToListAsync())
            .GroupBy(x => x.AssessmentAttemptID)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(r => r.CreatedOn).First());

        DateTime overdueThreshold = DateTime.UtcNow.AddDays(-OverdueAfterDays);
        List<RecentAssessmentViewModel> list = [];

        foreach (ScenarioAssignment assignment in assignments)
        {
            attemptByAssignment.TryGetValue(assignment.ScenarioAssignmentID, out AssessmentAttempt? attempt);
            AssessmentResult? result = attempt is not null && resultByAttempt.TryGetValue(attempt.AssessmentAttemptID, out AssessmentResult? r) ? r : null;
            reps.TryGetValue(assignment.SalesRepID, out SalesRep? rep);
            int? batchId = assignment.TestID.HasValue && batchIdByTest.TryGetValue(assignment.TestID.Value, out int resolvedBatchId) ? resolvedBatchId : null;

            string status;
            if (assignment.CompletedOn is not null)
            {
                status = "Completed";
            }
            else if (attempt is not null)
            {
                status = "In Progress";
            }
            else if (assignment.AssignedOn <= overdueThreshold)
            {
                status = "Overdue";
            }
            else
            {
                status = "Not Started";
            }

            list.Add(new RecentAssessmentViewModel
            {
                ScenarioAssignmentID = assignment.ScenarioAssignmentID,
                SalesRepID = assignment.SalesRepID,
                SalesRepEmail = rep?.EmailID ?? "Unknown",
                ScenarioTitle = scenarioTitles.GetValueOrDefault(assignment.ScenarioID, "Unknown Scenario"),
                BatchID = batchId,
                BatchName = batchId.HasValue ? batchNames.GetValueOrDefault(batchId.Value, "-") : "-",
                AssignedOn = assignment.AssignedOn,
                CompletedOn = assignment.CompletedOn,
                Status = status,
                OverallScore = result?.OverallScore,
                AttemptID = attempt?.AssessmentAttemptID,
                AssessmentResultID = result?.AssessmentResultID
            });
        }

        return list;
    }

    public async Task<ScoreDistributionViewModel> GetScoreDistributionAsync(List<int>? batchIds)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> repIds = await ResolveSalesRepIdsAsync(context, batchIds);

        List<int> attemptIds = await context.AssessmentAttempts
            .AsNoTracking()
            .Where(x => repIds.Contains(x.SalesRepID))
            .Select(x => x.AssessmentAttemptID)
            .ToListAsync();

        List<decimal> scores = (await context.AssessmentResults
            .AsNoTracking()
            .Where(x => attemptIds.Contains(x.AssessmentAttemptID))
            .ToListAsync())
            .GroupBy(x => x.AssessmentAttemptID)
            .Select(g => g.OrderByDescending(r => r.CreatedOn).First().OverallScore)
            .ToList();

        ScoreDistributionViewModel distribution = new();

        foreach (decimal score in scores)
        {
            if (score >= 80)
            {
                distribution.Excellent++;
            }
            else if (score >= 50)
            {
                distribution.Good++;
            }
            else
            {
                distribution.NeedsImprovement++;
            }
        }

        return distribution;
    }

    public async Task<CoachingThemesViewModel> GetCoachingThemesAsync(List<int>? batchIds, int topN = 5)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> repIds = await ResolveSalesRepIdsAsync(context, batchIds);

        List<int> attemptIds = await context.AssessmentAttempts
            .AsNoTracking()
            .Where(x => repIds.Contains(x.SalesRepID))
            .Select(x => x.AssessmentAttemptID)
            .ToListAsync();

        List<AssessmentResult> results = (await context.AssessmentResults
            .AsNoTracking()
            .Where(x => attemptIds.Contains(x.AssessmentAttemptID))
            .ToListAsync())
            .GroupBy(x => x.AssessmentAttemptID)
            .Select(g => g.OrderByDescending(r => r.CreatedOn).First())
            .ToList();

        JsonSerializerOptions jsonOptions = new() { PropertyNameCaseInsensitive = true };

        List<(string Text, DateTime CreatedOn)> strengthOccurrences = [];
        List<(string Text, DateTime CreatedOn)> developmentOccurrences = [];

        foreach (AssessmentResult result in results)
        {
            EvaluationReport? report;
            try
            {
                report = JsonSerializer.Deserialize<EvaluationReport>(result.EvaluationJson, jsonOptions);
            }
            catch (JsonException)
            {
                continue;
            }

            if (report is null)
            {
                continue;
            }

            foreach (string item in report.KeyStrengths)
            {
                strengthOccurrences.Add((item.Trim(), result.CreatedOn));
            }

            foreach (string item in report.DevelopmentAreas)
            {
                developmentOccurrences.Add((item.Trim(), result.CreatedOn));
            }
        }

        return new CoachingThemesViewModel
        {
            TopStrengths = RankThemes(strengthOccurrences, topN),
            TopDevelopmentAreas = RankThemes(developmentOccurrences, topN)
        };
    }

    private static List<CoachingThemeItemViewModel> RankThemes(List<(string Text, DateTime CreatedOn)> occurrences, int topN)
    {
        return occurrences
            .Where(x => !string.IsNullOrWhiteSpace(x.Text))
            .GroupBy(x => x.Text, StringComparer.OrdinalIgnoreCase)
            .Select(g => new
            {
                Text = g.OrderByDescending(x => x.CreatedOn).First().Text,
                Count = g.Count(),
                LatestOn = g.Max(x => x.CreatedOn)
            })
            .OrderByDescending(x => x.Count)
            .ThenByDescending(x => x.LatestOn)
            .Take(topN)
            .Select(x => new CoachingThemeItemViewModel { Text = x.Text, Count = x.Count })
            .ToList();
    }

    private static async Task<List<int>> ResolveSalesRepIdsAsync(SalesAssessmentDbContext context, List<int>? batchIds)
    {
        IQueryable<SalesRep> query = context.SalesReps.AsNoTracking().Where(x => x.IsActive);

        if (batchIds is not null)
        {
            query = query.Where(x => context.SalesRepBatches.Any(srb => srb.SalesRepID == x.SalesRepID && batchIds.Contains(srb.BatchID)));
        }

        return await query.Select(x => x.SalesRepID).ToListAsync();
    }
}
