using SalesAssessment.Web.Interfaces;
using Azure.Storage.Blobs;
using Azure.Storage.Sas;

namespace SalesAssessment.Web.Services;

public sealed class AudioRecordingService : IAudioRecordingService
{
    private readonly BlobContainerClient _container;

    public AudioRecordingService(IConfiguration configuration)
    {
        string connectionString = configuration["AzureBlobStorage:ConnectionString"]!;
        string containerName = configuration["AzureBlobStorage:ContainerName"]!;
        BlobServiceClient blobServiceClient = new(connectionString);
        _container = blobServiceClient.GetBlobContainerClient(containerName);
    }

    public async Task<string> SaveClipAsync(int attemptId, Stream audioStream)
    {
        string fileName = $"{Guid.NewGuid()}.webm";
        string blobPath = $"attempt-{attemptId}/{fileName}";
        BlobClient blobClient = _container.GetBlobClient(blobPath);
        await blobClient.UploadAsync(audioStream, overwrite: true);
        return blobClient.Uri.ToString();
    }

    public string GetPlaybackUrl(string storedAudioUrl)
    {
        if (string.IsNullOrWhiteSpace(storedAudioUrl))
        {
            return storedAudioUrl;
        }

        // Older recordings (pre-Blob-Storage) were saved as relative wwwroot paths
        // (e.g. "/recordings/20/xyz.webm") - those are served directly by static
        // files and need no signing, so leave anything that isn't a real blob URL alone.
        if (!Uri.TryCreate(storedAudioUrl, UriKind.Absolute, out Uri? uri))
        {
            return storedAudioUrl;
        }

        // The container's access level isn't set anywhere in this codebase (nothing
        // calls CreateIfNotExists/sets PublicAccessType), so a raw blob URL only plays
        // back if the container happens to be public. Generate a short-lived read-only
        // SAS URL instead so playback works regardless of the container's access level,
        // without ever making the recordings themselves publicly accessible.
        string blobName = uri.AbsolutePath.TrimStart('/');
        int slashIndex = blobName.IndexOf('/');
        blobName = slashIndex >= 0 ? blobName[(slashIndex + 1)..] : blobName;

        BlobClient blobClient = _container.GetBlobClient(blobName);

        if (!blobClient.CanGenerateSasUri)
        {
            return storedAudioUrl;
        }

        return blobClient.GenerateSasUri(BlobSasPermissions.Read, DateTimeOffset.UtcNow.AddHours(1)).ToString();
    }
}
