using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class AssessmentAttemptService : IAssessmentAttemptService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public AssessmentAttemptService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<AssessmentAttempt> StartAsync(int assignmentId, int salesRepId, int scenarioId, string conversationId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        // Defense in depth: the UI only ever offers a rep assignments whose Test is already
        // "Started" (see ScenarioAssignmentService.GetBySalesRepAsync), but enforce it here too
        // so a stale page or a direct call can't start an attempt for a test that isn't open.
        ScenarioAssignment? assignment = await context.ScenarioAssignments
            .AsNoTracking()
            .FirstOrDefaultAsync(x => x.ScenarioAssignmentID == assignmentId);

        if (assignment?.TestID is not null)
        {
            Test? test = await context.Tests.AsNoTracking().FirstOrDefaultAsync(x => x.TestID == assignment.TestID);
            BatchStatus? testStatus = test is null
                ? null
                : await context.BatchStatuses.AsNoTracking().FirstOrDefaultAsync(x => x.BatchStatusID == test.BatchStatusID);

            if (testStatus?.BatchStatusName != "Started")
            {
                throw new InvalidOperationException("This assessment is not open yet. Please check back once your trainer starts it.");
            }
        }

        AssessmentAttempt attempt =
            new()
            {
                ScenarioAssignmentID = assignmentId,
                SalesRepID = salesRepId,
                ScenarioID = scenarioId,
                ConversationID = conversationId,
                StartedOn = DateTime.UtcNow
            };

        context.AssessmentAttempts.Add(attempt);
        await context.SaveChangesAsync();
        return attempt;
    }
    public async Task<AssessmentAttempt?> GetByIdAsync(int assessmentAttemptId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.AssessmentAttempts.AsNoTracking().FirstOrDefaultAsync(x => x.AssessmentAttemptID == assessmentAttemptId);
    }

    public async Task CompleteAsync(int attemptId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        AssessmentAttempt? attempt = await context.AssessmentAttempts.FirstOrDefaultAsync(x => x.AssessmentAttemptID == attemptId);

        if (attempt is null)
        {
            return;
        }

        attempt.CompletedOn = DateTime.UtcNow;
        await context.SaveChangesAsync();
    }

    public async Task<AssessmentAttempt?> GetByAssignmentAsync(int scenarioAssignmentId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        return await context.AssessmentAttempts.AsNoTracking().FirstOrDefaultAsync(x => x.ScenarioAssignmentID == scenarioAssignmentId);
    }
}