using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class SalesRepService : ISalesRepService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public SalesRepService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<SalesRep>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<SalesRep> salesReps = await context.SalesReps.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.EmailID).ToListAsync();
        salesReps.ForEach(NormalizeUtc);
        return salesReps;
    }

    public async Task<List<SalesRep>> GetByBatchIdAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<SalesRep> salesReps = await context.SalesReps
            .AsNoTracking()
            .Where(x => x.IsActive && context.SalesRepBatches.Any(srb => srb.SalesRepID == x.SalesRepID && srb.BatchID == batchId))
            .OrderBy(x => x.EmailID)
            .ToListAsync();
        salesReps.ForEach(NormalizeUtc);
        return salesReps;
    }

    public async Task<SalesRep?> GetByIdAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        SalesRep? salesRep = await context.SalesReps.AsNoTracking().FirstOrDefaultAsync(x => x.SalesRepID == salesRepId);

        if (salesRep is not null)
        {
            NormalizeUtc(salesRep);
        }

        return salesRep;
    }

    private static void NormalizeUtc(SalesRep salesRep)
    {
        salesRep.CreatedOn = DateTime.SpecifyKind(salesRep.CreatedOn, DateTimeKind.Utc);
    }

    public async Task<SalesRep> CreateAsync(SalesRep salesRep)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        salesRep.CreatedOn = DateTime.SpecifyKind(salesRep.CreatedOn, DateTimeKind.Utc);
        context.SalesReps.Add(salesRep);
        await context.SaveChangesAsync();
        return salesRep;
    }

    public async Task<SalesRep> UpdateAsync(SalesRep salesRep)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        DateTime existingCreatedOn = await context.SalesReps
            .Where(x => x.SalesRepID == salesRep.SalesRepID)
            .Select(x => x.CreatedOn)
            .FirstOrDefaultAsync();
        salesRep.CreatedOn = DateTime.SpecifyKind(existingCreatedOn, DateTimeKind.Utc);
        context.SalesReps.Update(salesRep);
        await context.SaveChangesAsync();
        return salesRep;
    }

    public async Task<bool> DeleteAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        SalesRep? salesRep = await context.SalesReps.FindAsync(salesRepId);

        if (salesRep is null)
        {
            return false;
        }

        // Sales Reps are referenced by AssessmentAttempt and ScenarioAssignment, so a hard
        // delete would fail on the FK constraint for anyone with assessment history. Hide instead.
        salesRep.IsActive = false;
        await context.SaveChangesAsync();
        return true;
    }

    public async Task<List<int>> GetBatchIdsAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.SalesRepBatches
            .AsNoTracking()
            .Where(x => x.SalesRepID == salesRepId)
            .OrderBy(x => x.EnrolledOn)
            .Select(x => x.BatchID)
            .ToListAsync();
    }

    public async Task SetBatchesAsync(int salesRepId, List<int> batchIds)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<SalesRepBatch> existing = await context.SalesRepBatches.Where(x => x.SalesRepID == salesRepId).ToListAsync();

        List<SalesRepBatch> toRemove = existing.Where(x => !batchIds.Contains(x.BatchID)).ToList();
        context.SalesRepBatches.RemoveRange(toRemove);

        List<int> existingBatchIds = existing.Select(x => x.BatchID).ToList();
        foreach (int batchId in batchIds.Where(x => !existingBatchIds.Contains(x)))
        {
            context.SalesRepBatches.Add(new SalesRepBatch
            {
                SalesRepID = salesRepId,
                BatchID = batchId,
                EnrolledOn = DateTime.UtcNow
            });
        }

        await context.SaveChangesAsync();
    }

    public async Task<Dictionary<int, List<int>>> GetBatchEnrollmentsBulkAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<SalesRepBatch> enrollments = await context.SalesRepBatches.AsNoTracking().ToListAsync();
        return enrollments
            .GroupBy(x => x.SalesRepID)
            .ToDictionary(g => g.Key, g => g.Select(x => x.BatchID).ToList());
    }
}
