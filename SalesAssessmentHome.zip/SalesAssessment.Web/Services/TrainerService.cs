using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class TrainerService : ITrainerService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public TrainerService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<Trainer>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<Trainer> trainers = await context.Trainers.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.EmailID).ToListAsync();
        trainers.ForEach(NormalizeUtc);
        return trainers;
    }

    public async Task<Trainer?> GetByIdAsync(int trainerId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Trainer? trainer = await context.Trainers.AsNoTracking().FirstOrDefaultAsync(x => x.TrainerID == trainerId);

        if (trainer is not null)
        {
            NormalizeUtc(trainer);
        }

        return trainer;
    }

    private static void NormalizeUtc(Trainer trainer)
    {
        trainer.CreatedOn = DateTime.SpecifyKind(trainer.CreatedOn, DateTimeKind.Utc);
    }

    public async Task<Trainer> CreateAsync(Trainer trainer)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        trainer.CreatedOn = DateTime.SpecifyKind(trainer.CreatedOn, DateTimeKind.Utc);
        context.Trainers.Add(trainer);
        await context.SaveChangesAsync();
        return trainer;
    }

    public async Task<Trainer> UpdateAsync(Trainer trainer)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        DateTime existingCreatedOn = await context.Trainers
            .Where(x => x.TrainerID == trainer.TrainerID)
            .Select(x => x.CreatedOn)
            .FirstOrDefaultAsync();
        trainer.CreatedOn = DateTime.SpecifyKind(existingCreatedOn, DateTimeKind.Utc);
        context.Trainers.Update(trainer);
        await context.SaveChangesAsync();
        return trainer;
    }

    public async Task<bool> DeleteAsync(int trainerId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Trainer? trainer = await context.Trainers.FindAsync(trainerId);

        if (trainer is null)
        {
            return false;
        }

        // Trainers are referenced by Test, ScenarioAssignment, and BatchTrainer, so a hard
        // delete would either fail on the FK constraint or orphan those rows. Hide instead.
        trainer.IsActive = false;
        await context.SaveChangesAsync();
        return true;
    }
}
