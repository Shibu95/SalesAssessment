using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public sealed class TestQuestionService : ITestQuestionService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public TestQuestionService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<TestQuestion>> GetByTestIdAsync(int testId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.TestQuestions.AsNoTracking().Where(x => x.TestID == testId).ToListAsync();
    }

    public async Task<TestQuestionCreateResult> CreateAsync(TestQuestion testQuestion)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.TestQuestions.Add(testQuestion);
        await context.SaveChangesAsync();

        AssessmentType? assessmentType = await context.AssessmentTypes
            .FirstOrDefaultAsync(x => x.AssessmentTypeID == testQuestion.AssessmentTypeID);

        if (assessmentType is not null && assessmentType.AssessmentTypeName == "Mock Sales Call")
        {
            (int created, string? warning) = await GenerateScenarioAssignmentsAsync(context, testQuestion);
            return new TestQuestionCreateResult
            {
                TestQuestion = testQuestion,
                AssignmentsCreated = created,
                AssignmentWarning = warning
            };
        }

        return new TestQuestionCreateResult { TestQuestion = testQuestion };
    }

    public async Task<TestQuestion> UpdateAsync(TestQuestion testQuestion)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.TestQuestions.Update(testQuestion);
        await context.SaveChangesAsync();
        return testQuestion;
    }

    private static async Task<(int Created, string? Warning)> GenerateScenarioAssignmentsAsync(SalesAssessmentDbContext context, TestQuestion testQuestion)
    {
        Test? test = await context.Tests.FirstOrDefaultAsync(x => x.TestID == testQuestion.TestID);

        if (test is null)
        {
            return (0, "The test could not be found, so no scenarios were assigned.");
        }

        List<SalesRep> salesReps = await context.SalesReps
            .Where(x => x.IsActive && context.SalesRepBatches.Any(srb => srb.SalesRepID == x.SalesRepID && srb.BatchID == test.BatchID))
            .ToListAsync();

        List<Scenario> pool = await context.Scenarios.Where(x => x.IsActive).ToListAsync();

        AssessmentStatus? assignedStatus = await context.AssessmentStatuses
            .FirstOrDefaultAsync(x => x.AssessmentStatusName == "Assigned");

        if (salesReps.Count == 0)
        {
            return (0, "No Sales Reps are enrolled in this Test's batch, so no scenarios were assigned.");
        }

        if (pool.Count == 0)
        {
            return (0, "No active scenarios exist in the scenario library, so no scenarios were assigned.");
        }

        if (assignedStatus is null)
        {
            return (0, "The \"Assigned\" assessment status is missing from Settings, so no scenarios were assigned.");
        }

        int countToAssign = Math.Min(testQuestion.NoOfQuestions, pool.Count);
        Random random = new();
        DateTime assignedOn = DateTime.UtcNow;

        foreach (SalesRep salesRep in salesReps)
        {
            List<Scenario> shuffled = pool.OrderBy(_ => random.Next()).ToList();

            for (int i = 0; i < countToAssign; i++)
            {
                context.ScenarioAssignments.Add(new ScenarioAssignment
                {
                    ScenarioID = shuffled[i].ScenarioID,
                    SalesRepID = salesRep.SalesRepID,
                    TestID = test.TestID,
                    SequenceNumber = i + 1,
                    AssessmentStatusID = assignedStatus.AssessmentStatusID,
                    AssignedByTrainerID = test.CreatedByTrainerID,
                    AssignedOn = assignedOn
                });
            }
        }

        await context.SaveChangesAsync();
        return (salesReps.Count * countToAssign, null);
    }

    public async Task<bool> DeleteAsync(int testQuestionId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        TestQuestion? item = await context.TestQuestions.FindAsync(testQuestionId);

        if (item is null)
        {
            return false;
        }
        context.TestQuestions.Remove(item);
        await context.SaveChangesAsync();
        return true;
    }
}
