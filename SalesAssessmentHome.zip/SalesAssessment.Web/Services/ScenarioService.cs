using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class ScenarioService : IScenarioService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public ScenarioService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<Scenario>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<Scenario> scenarios = await context.Scenarios.AsNoTracking().Where(x => x.IsActive).OrderByDescending(x => x.CreatedOn).ToListAsync();
        scenarios.ForEach(NormalizeUtc);
        return scenarios;
    }

    public async Task<Scenario?> GetByIdAsync(int scenarioId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Scenario? scenario = await context.Scenarios.AsNoTracking().FirstOrDefaultAsync(x => x.ScenarioID == scenarioId);

        if (scenario is not null)
        {
            NormalizeUtc(scenario);
        }

        return scenario;
    }

    private static void NormalizeUtc(Scenario scenario)
    {
        scenario.CreatedOn = DateTime.SpecifyKind(scenario.CreatedOn, DateTimeKind.Utc);
    }

    public async Task<Scenario> CreateAsync(Scenario scenario)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.Scenarios.Add(scenario);
        await context.SaveChangesAsync();
        return scenario;
    }

    public async Task<Scenario> UpdateAsync(Scenario scenario)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        scenario.CreatedOn = DateTime.SpecifyKind(scenario.CreatedOn, DateTimeKind.Utc);
        context.Scenarios.Update(scenario);
        await context.SaveChangesAsync();
        return scenario;
    }

    public async Task<bool> DeleteAsync(int scenarioId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Scenario? scenario = await context.Scenarios.FindAsync(scenarioId);

        if (scenario is null)
        {
            return false;
        }

        // Scenarios are referenced by ScenarioAssignment and AssessmentAttempt, so a hard
        // delete would either fail on the FK constraint or orphan those rows. Hide instead.
        scenario.IsActive = false;
        await context.SaveChangesAsync();
        return true;
    }
}
