namespace SalesAssessment.Web.Services;

internal static class AppClaimTypes
{
    public const string TrainerID = "TrainerID";
    public const string SalesRepID = "SalesRepID";
}
