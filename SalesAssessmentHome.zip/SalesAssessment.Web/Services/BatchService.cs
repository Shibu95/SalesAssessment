using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Exceptions;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class BatchService : IBatchService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public BatchService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<Batch>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        var batches = await context.Batches.AsNoTracking().Where(x => x.IsActive).OrderByDescending(x => x.CreatedOn).ToListAsync();
        await EnrichAsync(context, batches);
        return batches;
    }

    public async Task<List<Batch>> GetByTrainerIdAsync(int trainerId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> batchIds = await context.BatchTrainers.AsNoTracking().Where(bt => bt.TrainerID == trainerId).Select(bt => bt.BatchID).ToListAsync();

        var batches = await context.Batches.AsNoTracking()
            .Where(x => batchIds.Contains(x.BatchID) && x.IsActive)
            .OrderByDescending(x => x.CreatedOn)
            .ToListAsync();

        await EnrichAsync(context, batches);
        return batches;
    }

    private static async Task EnrichAsync(SalesAssessmentDbContext context, List<Batch> batches)
    {
        // Enrich batches with sales rep count and trainer emails
        foreach (var batch in batches)
        {
            NormalizeUtc(batch);

            // Get sales rep count for this batch
            batch.SalesRepCount = await context.SalesRepBatches.CountAsync(srb => srb.BatchID == batch.BatchID);

            // Get all trainer emails assigned to this batch
            List<int> trainerIds = await context.BatchTrainers.AsNoTracking()
                .Where(bt => bt.BatchID == batch.BatchID)
                .Select(bt => bt.TrainerID)
                .ToListAsync();

            batch.TrainerEmails = await context.Trainers.AsNoTracking()
                .Where(t => trainerIds.Contains(t.TrainerID))
                .OrderBy(t => t.EmailID)
                .Select(t => t.EmailID)
                .ToListAsync();
        }
    }

    public async Task<Batch?> GetByIdAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Batch? batch = await context.Batches.AsNoTracking().FirstOrDefaultAsync(x => x.BatchID == batchId);

        if (batch is not null)
        {
            NormalizeUtc(batch);
        }

        return batch;
    }

    private static void NormalizeUtc(Batch batch)
    {
        batch.StartDate = DateTime.SpecifyKind(batch.StartDate, DateTimeKind.Utc);
        batch.CreatedOn = DateTime.SpecifyKind(batch.CreatedOn, DateTimeKind.Utc);
    }

    public async Task<Batch> CreateAsync(Batch batch)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        await EnsureUniqueNameAsync(context, batch.BatchName, excludeBatchId: null);
        batch.CreatedOn = DateTime.UtcNow;
        batch.StartDate = DateTime.SpecifyKind(batch.StartDate, DateTimeKind.Utc);
        context.Batches.Add(batch);
        await context.SaveChangesAsync();
        return batch;
    }

    public async Task<Batch> UpdateAsync(Batch batch)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        await EnsureUniqueNameAsync(context, batch.BatchName, excludeBatchId: batch.BatchID);
        batch.StartDate = DateTime.SpecifyKind(batch.StartDate, DateTimeKind.Utc);
        DateTime existingCreatedOn = await context.Batches
            .Where(x => x.BatchID == batch.BatchID)
            .Select(x => x.CreatedOn)
            .FirstOrDefaultAsync();
        batch.CreatedOn = DateTime.SpecifyKind(existingCreatedOn, DateTimeKind.Utc);
        context.Batches.Update(batch);
        await context.SaveChangesAsync();
        return batch;
    }

    private static async Task EnsureUniqueNameAsync(SalesAssessmentDbContext context, string batchName, int? excludeBatchId)
    {
        string normalizedName = (batchName ?? string.Empty).Trim();

        bool nameTaken = await context.Batches
            .AsNoTracking()
            .Where(x => x.IsActive && (excludeBatchId == null || x.BatchID != excludeBatchId))
            .AnyAsync(x => x.BatchName.ToLower() == normalizedName.ToLower());

        if (nameTaken)
        {
            throw new DuplicateNameException(nameof(Batch.BatchName), $"A batch named \"{normalizedName}\" already exists. Please choose a different name.");
        }
    }

    public async Task<bool> DeleteAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Batch? batch = await context.Batches.FindAsync(batchId);

        if (batch is null)
        {
            return false;
        }

        // Batches are referenced by Test, BatchTrainer, and SalesRepBatch, so a hard delete
        // would violate FK constraints or orphan those rows. Hide instead.
        batch.IsActive = false;
        await context.SaveChangesAsync();
        return true;
    }

    public async Task<List<Batch>> GetScheduledBatchesAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        BatchStatus? scheduledStatus = await context.BatchStatuses.AsNoTracking().FirstOrDefaultAsync(x => x.BatchStatusName == "Scheduled");
        if (scheduledStatus is null)
        {
            return [];
        }
        return await context.Batches.AsNoTracking().Where(x => x.BatchStatusID == scheduledStatus.BatchStatusID && x.IsActive).OrderBy(x => x.BatchName).ToListAsync();
    }

    public async Task<List<int>> GetTrainerIdsByBatchAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.BatchTrainers.AsNoTracking().Where(bt => bt.BatchID == batchId).Select(bt => bt.TrainerID).ToListAsync();
    }

    public async Task<int> GetParticipantCountAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.SalesRepBatches.CountAsync(srb => srb.BatchID == batchId);
    }

    public async Task AssignTrainersAsync(int batchId, List<int> trainerIds)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        var existingAssignments = context.BatchTrainers.Where(bt => bt.BatchID == batchId);
        context.BatchTrainers.RemoveRange(existingAssignments);
        await context.SaveChangesAsync();

        foreach (int trainerId in trainerIds)
        {
            context.BatchTrainers.Add(new BatchTrainer { BatchID = batchId, TrainerID = trainerId });
        }

        await context.SaveChangesAsync();
    }

    public async Task UploadSalesRepsAsync(int batchId, List<string> emailIds)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        List<string> trimmedEmails = emailIds
            .Where(e => !string.IsNullOrWhiteSpace(e))
            .Select(e => e.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (trimmedEmails.Count == 0)
        {
            return;
        }

        // A Sales Rep's identity (email/login/password) is global, not per-batch, so a rep who
        // already exists — e.g. re-attempting in a new batch after not performing well in an
        // earlier one — must be matched by email across the whole system rather than only within
        // this batch. Enrollment in a batch is tracked separately via SalesRepBatch, so the same
        // rep can now belong to more than one batch at a time.
        List<SalesRep> allReps = await context.SalesReps.ToListAsync();
        List<int> currentEnrollments = await context.SalesRepBatches
            .Where(x => x.BatchID == batchId)
            .Select(x => x.SalesRepID)
            .ToListAsync();

        List<SalesRep> newReps = [];

        foreach (string trimmedEmail in trimmedEmails)
        {
            if (!allReps.Any(sr => sr.EmailID.Equals(trimmedEmail, StringComparison.OrdinalIgnoreCase)))
            {
                SalesRep newRep = new()
                {
                    EmailID = trimmedEmail,
                    CreatedOn = DateTime.UtcNow,
                    // Sales Reps have no standalone "create" UI of their own (they only ever come into
                    // existence via this bulk upload), so they need the same default password Trainers get
                    // on creation — the DB column is NOT NULL, and there's no self-service signup flow to
                    // set one otherwise.
                    Password = "Sales@123"
                };
                context.SalesReps.Add(newRep);
                newReps.Add(newRep);
            }
        }

        if (newReps.Count > 0)
        {
            await context.SaveChangesAsync();
            allReps.AddRange(newReps);
        }

        foreach (string trimmedEmail in trimmedEmails)
        {
            SalesRep salesRep = allReps.First(sr => sr.EmailID.Equals(trimmedEmail, StringComparison.OrdinalIgnoreCase));

            if (!currentEnrollments.Contains(salesRep.SalesRepID))
            {
                context.SalesRepBatches.Add(new SalesRepBatch
                {
                    SalesRepID = salesRep.SalesRepID,
                    BatchID = batchId,
                    EnrolledOn = DateTime.UtcNow
                });
                currentEnrollments.Add(salesRep.SalesRepID);
            }
        }

        await context.SaveChangesAsync();
    }
}
