using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class HrEmployeeService : IHrEmployeeService
{
    private readonly IDbContextFactory<HrReportsDbContext> _contextFactory;
    private readonly ILogger<HrEmployeeService> _logger;

    public HrEmployeeService(IDbContextFactory<HrReportsDbContext> contextFactory, ILogger<HrEmployeeService> logger)
    {
        _contextFactory = contextFactory;
        _logger = logger;
    }

    public async Task<HrEmployee?> GetByEmailAsync(string? email)
    {
        if (string.IsNullOrWhiteSpace(email))
        {
            return null;
        }

        try
        {
            await using HrReportsDbContext context = await _contextFactory.CreateDbContextAsync();
            return await context.EmployeeBasicDetails
                .AsNoTracking()
                .FirstOrDefaultAsync(x => EF.Functions.ILike(x.EmailId!, email.Trim()));
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Unable to fetch HR employee details for {Email}", email);
            return null;
        }
    }

    public async Task<List<HrEmployee>> GetAllAsync()
    {
        try
        {
            await using HrReportsDbContext context = await _contextFactory.CreateDbContextAsync();
            return await context.EmployeeBasicDetails.AsNoTracking().ToListAsync();
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Unable to fetch HR employee list");
            return [];
        }
    }
}
