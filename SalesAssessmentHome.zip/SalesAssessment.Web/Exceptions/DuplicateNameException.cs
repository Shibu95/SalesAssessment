namespace SalesAssessment.Web.Exceptions;

public sealed class DuplicateNameException : InvalidOperationException
{
    public string FieldName { get; }

    public DuplicateNameException(string fieldName, string message) : base(message)
    {
        FieldName = fieldName;
    }
}
