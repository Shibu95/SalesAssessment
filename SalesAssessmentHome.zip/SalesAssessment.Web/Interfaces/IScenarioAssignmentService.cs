using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface IScenarioAssignmentService
{
    Task<List<ScenarioAssignment>> GetAllAsync();

    Task<List<ScenarioAssignment>> GetBySalesRepAsync(int salesRepId);

    Task<List<ScenarioAssignment>> GetBySalesRepAsync(int salesRepId, int batchId);

    Task<ScenarioAssignment?> GetByIdAsync(int scenarioAssignmentId);

    Task<ScenarioAssignment> CreateAsync(ScenarioAssignment assignment);

    Task<ScenarioAssignment?> CompleteAsync(int scenarioAssignmentId);
}