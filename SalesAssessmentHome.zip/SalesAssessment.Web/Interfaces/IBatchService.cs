using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface IBatchService
{
    Task<List<Batch>> GetAllAsync();

    Task<Batch?> GetByIdAsync(int batchId);

    Task<Batch> CreateAsync(Batch batch);

    Task<Batch> UpdateAsync(Batch batch);

    Task<bool> DeleteAsync(int batchId);
    Task<List<Batch>> GetScheduledBatchesAsync();
    Task<List<Batch>> GetByTrainerIdAsync(int trainerId);
    Task<List<int>> GetTrainerIdsByBatchAsync(int batchId);
    Task AssignTrainersAsync(int batchId, List<int> trainerIds);
    Task UploadSalesRepsAsync(int batchId, List<string> emailIds);
    Task<int> GetParticipantCountAsync(int batchId);
}