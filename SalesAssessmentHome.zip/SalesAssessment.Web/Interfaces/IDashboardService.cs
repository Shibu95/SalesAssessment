using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Interfaces;

public interface IDashboardService
{
    Task<DashboardSummaryViewModel> GetSummaryAsync(List<int>? batchIds);
    Task<List<DashboardTrendPointViewModel>> GetTrendAsync(List<int>? batchIds, int weeks = 6);
    Task<DashboardPendingBreakdownViewModel> GetPendingBreakdownAsync(List<int>? batchIds);
    Task<List<RecentAssessmentViewModel>> GetRecentAssessmentsAsync(List<int>? batchIds, int take = 100);
    Task<List<RecentAssessmentViewModel>> GetBatchParticipantResultsAsync(int batchId);
    Task<ScoreDistributionViewModel> GetScoreDistributionAsync(List<int>? batchIds);
    Task<CoachingThemesViewModel> GetCoachingThemesAsync(List<int>? batchIds, int topN = 5);
}
