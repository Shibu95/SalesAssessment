using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface ISalesRepService
{
    Task<List<SalesRep>> GetAllAsync();

    Task<List<SalesRep>> GetByBatchIdAsync(int batchId);

    Task<SalesRep?> GetByIdAsync(int salesRepId);

    Task<SalesRep> CreateAsync(SalesRep salesRep);

    Task<SalesRep> UpdateAsync(SalesRep salesRep);

    Task<bool> DeleteAsync(int salesRepId);

    Task<List<int>> GetBatchIdsAsync(int salesRepId);

    Task SetBatchesAsync(int salesRepId, List<int> batchIds);

    Task<Dictionary<int, List<int>>> GetBatchEnrollmentsBulkAsync();
}