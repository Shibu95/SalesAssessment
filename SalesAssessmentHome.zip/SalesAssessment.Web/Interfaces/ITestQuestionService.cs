using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Interfaces;

public interface ITestQuestionService
{
    Task<List<TestQuestion>> GetByTestIdAsync(int testId);

    Task<TestQuestionCreateResult> CreateAsync(TestQuestion testQuestion);

    Task<TestQuestion> UpdateAsync(TestQuestion testQuestion);

    Task<bool> DeleteAsync(int testQuestionId);
}