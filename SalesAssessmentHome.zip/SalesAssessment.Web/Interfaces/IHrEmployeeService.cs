using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface IHrEmployeeService
{
    Task<HrEmployee?> GetByEmailAsync(string? email);

    Task<List<HrEmployee>> GetAllAsync();
}
