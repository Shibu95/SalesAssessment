using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Interfaces
{
    public interface IAssessmentResultService
    {
        Task SaveAsync(AssessmentResult result);

        Task<List<AssessmentResult>> GetBySalesRepAsync(int salesRepId);

        Task<AssessmentResult?> GetByAttemptAsync(int attemptId);
        Task<AssessmentResult?> GetLatestBySalesRepAsync(int salesRepId);
        Task<List<HomeAssessmentViewModel>> GetDashboardReportsAsync(int salesRepId);
        Task<List<HomeAssessmentViewModel>> GetDashboardReportsAsync(int salesRepId, int batchId);
        Task<AssessmentResult?> GetByIdAsync(int assessmentResultId);
    }
}