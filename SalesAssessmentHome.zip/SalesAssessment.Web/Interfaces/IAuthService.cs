using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Interfaces;

public interface IAuthService
{
    Task<PasswordLoginResult> LoginAsync(string email, string password);

    Task<LoginResponse?> FindByEmailAsync(string email);
}
