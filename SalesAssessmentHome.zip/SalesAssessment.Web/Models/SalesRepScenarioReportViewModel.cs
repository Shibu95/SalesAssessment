namespace SalesAssessment.Web.Models;

public class SalesRepScenarioReportViewModel
{
    public int ScenarioAssignmentID { get; set; }

    public string ScenarioTitle { get; set; } = string.Empty;

    public int SequenceNumber { get; set; }

    public DateTime AssignedOn { get; set; }

    public DateTime? CompletedOn { get; set; }

    public int? AttemptID { get; set; }

    public int? AssessmentResultID { get; set; }

    public decimal? OverallScore { get; set; }

    public string? PerformanceLevel { get; set; }

    public string Status { get; set; } = "Not Started";
}
