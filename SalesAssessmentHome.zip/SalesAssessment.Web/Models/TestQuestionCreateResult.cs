using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Models;

public class TestQuestionCreateResult
{
    public TestQuestion TestQuestion { get; set; } = null!;
    public int AssignmentsCreated { get; set; }
    public string? AssignmentWarning { get; set; }
}
