using System;

namespace SalesAssessment.Web.Models;

public class DashboardSummaryViewModel
{
    public int TotalSalesReps { get; set; }
    public int AssignedThisMonth { get; set; }
    public int ActiveBatches { get; set; }
    public decimal CompletionRatePercent { get; set; }
    public decimal? AverageScorePercent { get; set; }
}

public class DashboardTrendPointViewModel
{
    public DateTime WeekStart { get; set; }
    public int CompletedCount { get; set; }
    public decimal? AverageScore { get; set; }

    public string WeekLabel => WeekStart.ToString("dd MMM");
}

public class DashboardPendingBreakdownViewModel
{
    public int Overdue { get; set; }
    public int InProgress { get; set; }
    public int NotStarted { get; set; }

    public int Total => Overdue + InProgress + NotStarted;
}

public class DashboardPendingSliceViewModel
{
    public string Label { get; set; } = string.Empty;
    public int Value { get; set; }
}

public class ScoreDistributionViewModel
{
    public int Excellent { get; set; }
    public int Good { get; set; }
    public int NeedsImprovement { get; set; }

    public int Total => Excellent + Good + NeedsImprovement;

    public decimal ExcellentPercent => Total == 0 ? 0 : Math.Round(Excellent * 100m / Total, 1);
    public decimal GoodPercent => Total == 0 ? 0 : Math.Round(Good * 100m / Total, 1);
    public decimal NeedsImprovementPercent => Total == 0 ? 0 : Math.Round(NeedsImprovement * 100m / Total, 1);
}

public class CoachingThemeItemViewModel
{
    public string Text { get; set; } = string.Empty;
    public int Count { get; set; }
}

public class CoachingThemesViewModel
{
    public List<CoachingThemeItemViewModel> TopStrengths { get; set; } = [];
    public List<CoachingThemeItemViewModel> TopDevelopmentAreas { get; set; } = [];
}

public class RecentAssessmentViewModel
{
    public int ScenarioAssignmentID { get; set; }
    public int SalesRepID { get; set; }
    public string SalesRepEmail { get; set; } = string.Empty;
    public string ScenarioTitle { get; set; } = string.Empty;
    public int? BatchID { get; set; }
    public string BatchName { get; set; } = string.Empty;
    public DateTime AssignedOn { get; set; }
    public DateTime? CompletedOn { get; set; }
    public string Status { get; set; } = "Not Started";
    public decimal? OverallScore { get; set; }
    public int? AttemptID { get; set; }
    public int? AssessmentResultID { get; set; }
}
