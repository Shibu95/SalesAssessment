namespace SalesAssessment.Web.Models
{
    public enum PasswordLoginStatus
    {
        NotFound,
        NoPasswordSet,
        WrongPassword,
        Success
    }

    public class PasswordLoginResult
    {
        public PasswordLoginStatus Status { get; set; }
        public LoginResponse? User { get; set; }

        public static PasswordLoginResult NotFound() => new() { Status = PasswordLoginStatus.NotFound };
        public static PasswordLoginResult NoPasswordSet() => new() { Status = PasswordLoginStatus.NoPasswordSet };
        public static PasswordLoginResult WrongPassword() => new() { Status = PasswordLoginStatus.WrongPassword };
        public static PasswordLoginResult Success(LoginResponse user) => new() { Status = PasswordLoginStatus.Success, User = user };
    }
}
