using System.Security.Claims;
using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Components;
using SalesAssessment.Web.Controllers;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Models;
using SalesAssessment.Web.Services;
using Syncfusion.Blazor;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.MicrosoftAccount;

var builder = WebApplication.CreateBuilder(args);

Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense(builder.Configuration["SyncfusionLicenseKey"]);

// Add services to the container.
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddSyncfusionBlazor();

// appsettings.Development.json already had a CircuitOptions:DetailedErrors section, but nothing
// was actually binding it - AddInteractiveServerComponents() doesn't read it automatically, so an
// unhandled exception on a circuit only ever showed the generic "unhandled exception" message in
// the browser console, with the real cause visible only in the server's own log output.
builder.Services.Configure<Microsoft.AspNetCore.Components.Server.CircuitOptions>(
    builder.Configuration.GetSection("CircuitOptions"));

AuthenticationBuilder authBuilder = builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.AccessDeniedPath = "/login";
    });

string? microsoftClientId = builder.Configuration["MicrosoftAuth:ClientId"];
string? microsoftClientSecret = builder.Configuration["MicrosoftAuth:ClientSecret"];

if (!string.IsNullOrWhiteSpace(microsoftClientId) && !string.IsNullOrWhiteSpace(microsoftClientSecret))
{
    authBuilder.AddMicrosoftAccount(MicrosoftAccountDefaults.AuthenticationScheme, options =>
    {
        options.ClientId = microsoftClientId;
        options.ClientSecret = microsoftClientSecret;
        options.CallbackPath = "/signin-oidc";

        string? tenantId = builder.Configuration["MicrosoftAuth:TenantId"];
        if (!string.IsNullOrWhiteSpace(tenantId))
        {
            options.AuthorizationEndpoint = $"https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/authorize";
            options.TokenEndpoint = $"https://login.microsoftonline.com/{tenantId}/oauth2/v2.0/token";
        }

        options.Events.OnCreatingTicket = async context =>
        {
            string? email = context.Principal?.FindFirst(ClaimTypes.Email)?.Value
                ?? context.Principal?.FindFirst("preferred_username")?.Value;

            IAuthService authService = context.HttpContext.RequestServices.GetRequiredService<IAuthService>();
            LoginResponse? user = string.IsNullOrEmpty(email) ? null : await authService.FindByEmailAsync(email);

            if (user is null)
            {
                context.Fail("Email not recognized. Please contact your administrator.");
                return;
            }

            ClaimsIdentity identity = (ClaimsIdentity)context.Principal!.Identity!;
            identity.AddClaim(new Claim(ClaimTypes.Name, user.EmailID));
            identity.AddClaim(new Claim(ClaimTypes.Role, user.Role));

            if (user.TrainerID.HasValue)
            {
                identity.AddClaim(new Claim(AppClaimTypes.TrainerID, user.TrainerID.Value.ToString()));
            }

            if (user.SalesRepID.HasValue)
            {
                identity.AddClaim(new Claim(AppClaimTypes.SalesRepID, user.SalesRepID.Value.ToString()));
            }
        };

        options.Events.OnRemoteFailure = context =>
        {
            context.HandleResponse();
            string message = Uri.EscapeDataString(context.Failure?.Message ?? "Microsoft sign-in failed.");
            context.Response.Redirect($"/login?error={message}");
            return Task.CompletedTask;
        };

        options.Events.OnTicketReceived = context =>
        {
            string? role = context.Principal?.FindFirst(ClaimTypes.Role)?.Value;
            context.ReturnUri = AccountController.PostLoginRedirect(role ?? string.Empty);
            return Task.CompletedTask;
        };
    });
}

builder.Services.AddAuthorizationCore();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddScoped<CurrentUserService>();
builder.Services.AddScoped<SidebarService>();

builder.Services.AddDbContextFactory<SalesAssessmentDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Postgres")));

builder.Services.AddDbContextFactory<HrReportsDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("HRReports")));

builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ITrainerService, TrainerService>();
builder.Services.AddScoped<ISalesRepService, SalesRepService>();
builder.Services.AddScoped<IScenarioService, ScenarioService>();
builder.Services.AddScoped<IScenarioAssignmentService, ScenarioAssignmentService>();
builder.Services.AddScoped<IRoleService, RoleService>();
builder.Services.AddScoped<IBatchService, BatchService>();
builder.Services.AddScoped<ITestService, TestService>();
builder.Services.AddScoped<ITestQuestionService, TestQuestionService>();
builder.Services.AddScoped<ILookupService, LookupService>();
builder.Services.AddScoped<IAssessmentAttemptService, AssessmentAttemptService>();
builder.Services.AddScoped<IAssessmentTranscriptService, AssessmentTranscriptService>();
builder.Services.AddScoped<IAssessmentResultService, AssessmentResultService>();
// The default HttpClient timeout is 100s - on a flaky connection that means a single
// failed attempt inside the retry loop could hang for up to 100s before even starting
// its backoff, which is most of what "the customer takes forever to respond" looks like
// from the Sales Rep's side. Fail fast instead so the existing retry/reconnect logic
// actually gets a chance to run within a reasonable total wait.
builder.Services.AddHttpClient<IBoldAgentService, BoldAgentService>(client => client.Timeout = TimeSpan.FromSeconds(35));

// The evaluation call does a lot more work per request than a conversational reply - it
// reasons over the whole transcript and returns a large structured JSON report, not a
// sentence. Measured a plain 10-line transcript taking ~25s end to end, so 20s (fine for
// the conversational client above) was cutting real, successful evaluations off early.
builder.Services.AddHttpClient<IEvaluationAgentService, EvaluationAgentService>(client => client.Timeout = TimeSpan.FromSeconds(90));
builder.Services.AddScoped<IAudioRecordingService, AudioRecordingService>();
builder.Services.AddScoped<IHrEmployeeService, HrEmployeeService>();
builder.Services.AddScoped<IDashboardService, DashboardService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.UseAntiforgery();
app.UseStaticFiles();

app.MapStaticAssets();
app.MapControllers();
app.MapRazorComponents<App>().AddInteractiveServerRenderMode();

app.Run();
