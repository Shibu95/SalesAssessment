window.callAssessment = {

    _recognition: null,
    _dotNetRef: null,
    _silenceTimer: null,
    _finalTranscript: "",
    _manualStop: false,
    _callEnded: false,
    _micStream: null,
    _mediaRecorder: null,
    _recordedChunks: [],
    _volumeContext: null,
    _volumeSource: null,
    _volumeAnalyser: null,
    _volumeRaf: null,
    _repSpeakingNow: false,

    startListening: async function (dotNetRef) {
        this._callEnded = false;

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            dotNetRef.invokeMethodAsync("OnMicUnavailable");
            return;
        }

        this._dotNetRef = dotNetRef;
        this._finalTranscript = "";
        this._manualStop = false;
        this._clearSilenceTimer();

        if (!this._micStream && navigator.mediaDevices) {
            try {
                this._micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            } catch (e) {
                console.error("Microphone access for recording failed", e);
            }
        }

        this._startRecorder();
        this._beginRecognition();
        this._startVolumeMonitor();
    },

    stopListening: function () {
        this._manualStop = true;
        this._clearSilenceTimer();
        this._stopVolumeMonitor();
        if (this._recognition) {
            this._recognition.stop();
        }
        if (this._mediaRecorder && this._mediaRecorder.state !== "inactive") {
            this._mediaRecorder.stop();
        }
    },

    // The "Speaking…" status used to depend entirely on SpeechDetected, which only fires
    // once the cloud speech-to-text engine returns a recognized result - that round trip
    // has real latency (often several seconds for the first result of a new utterance),
    // even though the mic and recording are already live by then. This polls the raw mic
    // volume instead, which reacts near-instantly, and reuses the same SpeechDetected
    // signal so the C# side needs no changes. It only ever flips the UI on early (never
    // touches the silence timer that decides when the rep's turn is actually done -
    // that stays tied to real recognized speech in onresult, unchanged).
    _startVolumeMonitor: function () {
        this._stopVolumeMonitor();

        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!this._micStream || !AudioCtx) {
            return;
        }

        try {
            this._volumeContext = new AudioCtx();
            this._volumeSource = this._volumeContext.createMediaStreamSource(this._micStream);
            this._volumeAnalyser = this._volumeContext.createAnalyser();
            this._volumeAnalyser.fftSize = 512;
            this._volumeSource.connect(this._volumeAnalyser);

            if (this._volumeContext.state === "suspended") {
                this._volumeContext.resume().catch(function () { });
            }
        } catch (e) {
            console.error("Volume monitor setup failed", e);
            this._stopVolumeMonitor();
            return;
        }

        const data = new Uint8Array(this._volumeAnalyser.frequencyBinCount);
        const self = this;
        const VOLUME_THRESHOLD = 12;

        (function poll() {
            if (!self._volumeAnalyser) {
                return;
            }

            self._volumeAnalyser.getByteFrequencyData(data);

            let sum = 0;
            for (let i = 0; i < data.length; i++) {
                sum += data[i];
            }
            const average = sum / data.length;

            if (average > VOLUME_THRESHOLD) {
                if (!self._repSpeakingNow) {
                    self._repSpeakingNow = true;
                    if (self._dotNetRef) {
                        self._dotNetRef.invokeMethodAsync("SpeechDetected");
                    }
                }
            } else {
                self._repSpeakingNow = false;
            }

            self._volumeRaf = requestAnimationFrame(poll);
        })();
    },

    _stopVolumeMonitor: function () {
        if (this._volumeRaf) {
            cancelAnimationFrame(this._volumeRaf);
            this._volumeRaf = null;
        }
        if (this._volumeSource) {
            try { this._volumeSource.disconnect(); } catch (e) { }
            this._volumeSource = null;
        }
        this._volumeAnalyser = null;
        if (this._volumeContext) {
            try { this._volumeContext.close(); } catch (e) { }
            this._volumeContext = null;
        }
        this._repSpeakingNow = false;
    },

    stopAll: function () {
        this._callEnded = true;
        this.stopListening();
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
        if (this._micStream) {
            this._micStream.getTracks().forEach(function (track) { track.stop(); });
            this._micStream = null;
        }
    },

    _startRecorder: function () {
        this._mediaRecorder = null;

        if (!this._micStream || typeof MediaRecorder === "undefined") {
            return;
        }

        try {
            this._recordedChunks = [];
            const recorder = new MediaRecorder(this._micStream);
            const self = this;

            recorder.ondataavailable = function (event) {
                if (event.data && event.data.size > 0) {
                    self._recordedChunks.push(event.data);
                }
            };

            recorder.start();
            this._mediaRecorder = recorder;
        } catch (e) {
            console.error("MediaRecorder start failed", e);
            this._mediaRecorder = null;
        }
    },

    _stopRecorderAndGetBlob: function () {
        const self = this;

        return new Promise(function (resolve) {
            if (!self._mediaRecorder || self._mediaRecorder.state === "inactive") {
                resolve(null);
                return;
            }

            self._mediaRecorder.onstop = function () {
                const blob = self._recordedChunks.length > 0
                    ? new Blob(self._recordedChunks, { type: "audio/webm" })
                    : null;
                resolve(blob);
            };

            self._mediaRecorder.stop();
        });
    },

    _beginRecognition: function () {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        const self = this;

        recognition.lang = "en-US";
        recognition.interimResults = true;
        recognition.continuous = true;

        recognition.onstart = function () {
            self._dotNetRef.invokeMethodAsync("ListeningStarted");
        };

        recognition.onresult = function (event) {
            for (let i = event.resultIndex; i < event.results.length; i++) {
                if (event.results[i].isFinal) {
                    const chunk = event.results[i][0].transcript.trim();
                    if (chunk) {
                        self._finalTranscript = (self._finalTranscript + " " + chunk).trim();
                    }
                }
            }

            self._dotNetRef.invokeMethodAsync("SpeechDetected");
            self._resetSilenceTimer();
        };

        recognition.onerror = function (event) {
            if (event.error === "not-allowed" || event.error === "service-not-allowed") {
                self._manualStop = true;
                self._clearSilenceTimer();
                self._dotNetRef.invokeMethodAsync("OnMicPermissionDenied");
            }
            // Other errors (e.g. "no-speech") are recoverable via the onend restart below.
        };

        recognition.onend = function () {
            self._dotNetRef.invokeMethodAsync("ListeningEnded");

            if (!self._manualStop) {
                // The browser ended the engine on its own (continuous recognition is
                // commonly time-limited) - restart transparently without losing
                // anything already accumulated or resetting the silence timer or the
                // in-progress audio recording.
                self._beginRecognition();
                self._recognition.start();
            }
        };

        this._recognition = recognition;
        recognition.start();
    },

    _resetSilenceTimer: function () {
        this._clearSilenceTimer();

        const self = this;
        this._silenceTimer = setTimeout(function () {
            self._finalizeTurn();
        }, 2000);
    },

    _clearSilenceTimer: function () {
        if (this._silenceTimer) {
            clearTimeout(this._silenceTimer);
            this._silenceTimer = null;
        }
    },

    _finalizeTurn: function () {
        this._manualStop = true;
        this._stopVolumeMonitor();

        if (this._recognition) {
            this._recognition.stop();
        }

        const transcript = this._finalTranscript.trim();
        this._finalTranscript = "";
        const self = this;

        this._stopRecorderAndGetBlob().then(function (blob) {
            if (!transcript) {
                return;
            }

            if (blob && blob.size > 0) {
                blob.arrayBuffer().then(function (buffer) {
                    const streamRef = DotNet.createJSStreamReference(buffer);
                    self._dotNetRef.invokeMethodAsync("ReceiveTranscript", transcript, streamRef);
                });
            } else {
                self._dotNetRef.invokeMethodAsync("ReceiveTranscript", transcript, null);
            }
        });
    }
};

window.callSpeechSynthesis = {

    speak: function (text, dotNetRef) {
        if (!text) {
            return;
        }

        window.callAssessment.stopListening();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "en-US";

        utterance.onstart = function () {
            dotNetRef.invokeMethodAsync("CustomerSpeakingStarted");
        };

        utterance.onend = function () {
            dotNetRef.invokeMethodAsync("CustomerSpeakingEnded");

            if (!window.callAssessment._callEnded) {
                window.callAssessment.startListening(dotNetRef);
            }
        };

        speechSynthesis.speak(utterance);
    }
};

// Independent playback helpers used by the Trainer/Admin Dashboard to listen
// back to a completed call. Deliberately separate from callAssessment /
// callSpeechSynthesis so reviewing a past call never touches live-call state.
window.audioPlayback = {
    _currentAudio: null,
    _currentResolve: null,

    playClip: function (url) {
        const self = this;
        return new Promise(function (resolve) {
            const audio = new Audio(url);
            self._currentAudio = audio;
            self._currentResolve = resolve;
            audio.onended = function () { self._clearCurrent(); resolve(); };
            audio.onerror = function () { self._clearCurrent(); resolve(); };
            audio.play().catch(function () { self._clearCurrent(); resolve(); });
        });
    },

    speak: function (text) {
        const self = this;
        return new Promise(function (resolve) {
            if (!text) {
                resolve();
                return;
            }

            self._currentResolve = resolve;
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = "en-US";
            utterance.onend = function () { self._clearCurrent(); resolve(); };
            utterance.onerror = function () { self._clearCurrent(); resolve(); };
            speechSynthesis.speak(utterance);
        });
    },

    // Lets a caller (e.g. closing the transcript dialog mid-playback) unblock whatever
    // C# await is currently waiting on playClip/speak, instead of leaving audio playing
    // silently in the background with nothing on screen still tracking it.
    stopAll: function () {
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }

        if (this._currentAudio) {
            this._currentAudio.pause();
        }

        if (this._currentResolve) {
            const resolve = this._currentResolve;
            this._clearCurrent();
            resolve();
        }
    },

    // Real pause/resume (not stop) - the currently playing clip or synthesized line stays
    // queued and continues from where it left off, it doesn't restart or move to the next line.
    pause: function () {
        if (window.speechSynthesis && window.speechSynthesis.speaking) {
            window.speechSynthesis.pause();
        }

        if (this._currentAudio && !this._currentAudio.paused) {
            this._currentAudio.pause();
        }
    },

    resume: function () {
        if (window.speechSynthesis && window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
        }

        if (this._currentAudio && this._currentAudio.paused) {
            this._currentAudio.play();
        }
    },

    _clearCurrent: function () {
        this._currentAudio = null;
        this._currentResolve = null;
    },

    scrollToMessage: function (elementId) {
        const el = document.getElementById(elementId);
        if (el) {
            el.scrollIntoView({ behavior: "smooth", block: "center" });
        }
    }
};
