// Close the account dropdown when the user clicks outside it
export function initUserMenuOutsideClick(dotnetRef, containerId) {
    function handleClick(event) {
        const container = document.getElementById(containerId);
        if (container && !container.contains(event.target)) {
            dotnetRef.invokeMethodAsync('CloseUserMenu');
        }
    }

    document.addEventListener('mousedown', handleClick);

    return {
        dispose: () => {
            document.removeEventListener('mousedown', handleClick);
        }
    };
}
