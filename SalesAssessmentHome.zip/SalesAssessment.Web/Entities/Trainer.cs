using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("trainer", Schema = "public")]
    public class Trainer
    {
        [Key]
        public int TrainerID { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Enter a valid email address.")]
        public string EmailID { get; set; } = string.Empty;

        [Range(1, int.MaxValue, ErrorMessage = "Please select a role.")]
        public int RoleID { get; set; }

        [Required]
        public DateTime CreatedOn { get; set; }

        public bool IsActive { get; set; } = true;

        public string? Password { get; set; }

        public string? ProfilePicture { get; set; }
    }
}