using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("batch", Schema = "public")]
    public class Batch
    {
        [Key]
        public int BatchID { get; set; }

        [Required]
        public string BatchName { get; set; } = string.Empty;

        public DateTime StartDate { get; set; }

        public int BatchStatusID { get; set; }

        public DateTime CreatedOn { get; set; }

        public bool IsActive { get; set; } = true;

        [NotMapped]
        public int SalesRepCount { get; set; } = 0;

        [NotMapped]
        public List<string> TrainerEmails { get; set; } = [];
    }
}