using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

namespace SalesAssessment.Web.Entities
{
    [Table("employeebasicdetails", Schema = "public")]
    [Keyless]
    public class HrEmployee
    {
        [Column("employeename")]
        public string EmployeeName { get; set; } = string.Empty;

        [Column("employeeid")]
        public string EmployeeId { get; set; } = string.Empty;

        [Column("emailid")]
        public string? EmailId { get; set; }

        [Column("designationname")]
        public string? DesignationName { get; set; }

        [Column("reportingperson")]
        public string ReportingPerson { get; set; } = string.Empty;

        [Column("manager")]
        public string Manager { get; set; } = string.Empty;

        [Column("teamnames")]
        public string? TeamNames { get; set; }

        [Column("experience")]
        public string? Experience { get; set; }
    }
}
