using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities;

[Table("assessmenttranscript", Schema = "public")]
public class AssessmentTranscript
{
    [Key]
    public int AssessmentTranscriptID { get; set; }

    [Required]
    public int AssessmentAttemptID { get; set; }

    [Required]
    public string Sender { get; set; } = string.Empty;

    [Required]
    public string Message { get; set; } = string.Empty;

    [Required]
    public DateTime CreatedOn { get; set; }

    public string? AudioUrl { get; set; }
}