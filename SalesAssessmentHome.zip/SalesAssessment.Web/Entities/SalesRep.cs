using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("salesrep", Schema = "public")]
    public class SalesRep
    {
        [Key]
        public int SalesRepID { get; set; }

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Enter a valid email address.")]
        public string EmailID { get; set; } = string.Empty;

        [Required]
        public DateTime CreatedOn { get; set; }

        public bool IsActive { get; set; } = true;

        public string? Password { get; set; }

        public string? ProfilePicture { get; set; }
    }
}