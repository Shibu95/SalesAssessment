using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("salesrepbatch", Schema = "public")]
    public class SalesRepBatch
    {
        [Key]
        public int SalesRepBatchID { get; set; }

        public int SalesRepID { get; set; }

        public int BatchID { get; set; }

        public DateTime EnrolledOn { get; set; }
    }
}
