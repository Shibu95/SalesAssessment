using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Data
{
    public class SalesAssessmentDbContext : DbContext
    {
        public SalesAssessmentDbContext(DbContextOptions<SalesAssessmentDbContext> options) : base(options)
        {
        }

        public DbSet<Trainer> Trainers { get; set; }
        public DbSet<SalesRep> SalesReps { get; set; }
        public DbSet<SalesRepBatch> SalesRepBatches { get; set; }
        public DbSet<Scenario> Scenarios { get; set; }
        public DbSet<ScenarioAssignment> ScenarioAssignments { get; set; }
        public DbSet<Industry> Industries { get; set; }
        public DbSet<AssessmentStatus> AssessmentStatuses { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Batch> Batches { get; set; }
        public DbSet<BatchStatus> BatchStatuses { get; set; }
        public DbSet<BatchTrainer> BatchTrainers { get; set; }
        public DbSet<AssessmentType> AssessmentTypes => Set<AssessmentType>();
        public DbSet<Test> Tests { get; set; }
        public DbSet<TestQuestion> TestQuestions { get; set; }
        public DbSet<AssessmentAttempt> AssessmentAttempts { get; set; }
        public DbSet<AssessmentTranscript> AssessmentTranscripts { get; set; }
        public DbSet<AssessmentResult> AssessmentResults { get; set; }
    }
}