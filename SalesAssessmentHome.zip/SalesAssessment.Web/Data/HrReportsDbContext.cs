using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Data
{
    public class HrReportsDbContext : DbContext
    {
        public HrReportsDbContext(DbContextOptions<HrReportsDbContext> options) : base(options)
        {
        }

        public DbSet<HrEmployee> EmployeeBasicDetails { get; set; }
    }
}
