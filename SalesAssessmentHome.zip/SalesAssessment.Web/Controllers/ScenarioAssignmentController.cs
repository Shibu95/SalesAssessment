using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class ScenarioAssignmentController : ControllerBase
{
    private readonly IScenarioAssignmentService _scenarioAssignmentService;

    public ScenarioAssignmentController(IScenarioAssignmentService scenarioAssignmentService)
    {
        _scenarioAssignmentService = scenarioAssignmentService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _scenarioAssignmentService.GetAllAsync());
    }

    [HttpGet("salesrep/{salesRepId:int}")]
    public async Task<IActionResult> GetBySalesRep(int salesRepId)
    {
        return Ok(await _scenarioAssignmentService.GetBySalesRepAsync(salesRepId));
    }

    [HttpPost]
    public async Task<IActionResult> Create(ScenarioAssignment assignment)
    {
        ScenarioAssignment result = await _scenarioAssignmentService.CreateAsync(assignment);
        return Ok(result);
    }

    [HttpPut("{scenarioAssignmentId:int}/complete")]
    public async Task<IActionResult> Complete(int scenarioAssignmentId)
    {
        ScenarioAssignment? result = await _scenarioAssignmentService.CompleteAsync(scenarioAssignmentId);

        if (result is null)
        {
            return NotFound();
        }

        return Ok(result);
    }
}