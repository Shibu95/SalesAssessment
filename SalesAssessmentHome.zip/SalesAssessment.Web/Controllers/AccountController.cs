using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Models;
using SalesAssessment.Web.Services;

namespace SalesAssessment.Web.Controllers;

public class AccountController : ControllerBase
{
    private readonly IAuthService _authService;
    private readonly IConfiguration _configuration;

    public AccountController(IAuthService authService, IConfiguration configuration)
    {
        _authService = authService;
        _configuration = configuration;
    }

    public static string PostLoginRedirect(string role) => role == "SalesRep" ? "/home" : "/";

    [HttpPost("/account/login")]
    public async Task<IActionResult> Login([FromForm] string email, [FromForm] string password)
    {
        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
        {
            return Redirect("/login?error=" + Uri.EscapeDataString("Please enter your email and password."));
        }

        PasswordLoginResult result = await _authService.LoginAsync(email.Trim(), password);

        switch (result.Status)
        {
            case PasswordLoginStatus.NotFound:
                return Redirect("/login?error=" + Uri.EscapeDataString("Email not recognized. Please contact your administrator."));
            case PasswordLoginStatus.NoPasswordSet:
                return Redirect("/login?error=" + Uri.EscapeDataString("No password has been set for this account yet. Please contact your administrator."));
            case PasswordLoginStatus.WrongPassword:
                return Redirect("/login?error=" + Uri.EscapeDataString("Incorrect password. Please try again."));
        }

        LoginResponse user = result.User!;
        List<Claim> claims = new()
        {
            new Claim(ClaimTypes.Name, user.EmailID),
            new Claim(ClaimTypes.Role, user.Role)
        };

        if (user.TrainerID.HasValue)
        {
            claims.Add(new Claim(AppClaimTypes.TrainerID, user.TrainerID.Value.ToString()));
        }

        if (user.SalesRepID.HasValue)
        {
            claims.Add(new Claim(AppClaimTypes.SalesRepID, user.SalesRepID.Value.ToString()));
        }

        ClaimsIdentity identity = new(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        ClaimsPrincipal principal = new(identity);

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal, new AuthenticationProperties
        {
            IsPersistent = true
        });

        return Redirect(PostLoginRedirect(user.Role));
    }

    [HttpGet("/account/microsoft-login")]
    public IActionResult MicrosoftLogin()
    {
        string? clientId = _configuration["MicrosoftAuth:ClientId"];

        if (string.IsNullOrWhiteSpace(clientId))
        {
            return Redirect("/login?error=" + Uri.EscapeDataString("Microsoft sign-in is not configured yet."));
        }

        return Challenge(new AuthenticationProperties { RedirectUri = "/" }, "Microsoft");
    }

    [HttpGet("/account/logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Redirect("/login");
    }
}
