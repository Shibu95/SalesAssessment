using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Entities;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Data;
using Microsoft.EntityFrameworkCore;

namespace SalesAssessment.Web.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize(Roles = "Admin,Manager,Trainer")]
    public class BatchStatusController : ControllerBase
    {
        private readonly SalesAssessmentDbContext _context;

        public BatchStatusController(SalesAssessmentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.BatchStatuses.OrderBy(x => x.BatchStatusName).ToListAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            var batchStatus = await _context.BatchStatuses.FirstOrDefaultAsync(x => x.BatchStatusID == id);

            if (batchStatus == null)
            {
                return NotFound();
            }

            return Ok(batchStatus);
        }
    }
}
