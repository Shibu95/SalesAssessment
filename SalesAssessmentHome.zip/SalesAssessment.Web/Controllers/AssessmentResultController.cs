using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class AssessmentResultController : ControllerBase
{
    private readonly IAssessmentResultService _service;

    public AssessmentResultController(IAssessmentResultService service)
    {
        _service = service;
    }

    [HttpGet("{attemptId:int}")]
    public async Task<IActionResult> GetByAttempt(int attemptId)
    {
        return Ok(await _service.GetByAttemptAsync(attemptId));
    }
}