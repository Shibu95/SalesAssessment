using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class AssessmentAttemptController : ControllerBase
{
    private readonly IAssessmentAttemptService _service;

    public AssessmentAttemptController(IAssessmentAttemptService service)
    {
        _service = service;
    }

    [HttpGet("{scenarioAssignmentId:int}")]
    public async Task<IActionResult> GetByAssignment(int scenarioAssignmentId)
    {
        AssessmentAttempt? result = await _service.GetByAssignmentAsync(scenarioAssignmentId);
        return Ok(result);
    }
}