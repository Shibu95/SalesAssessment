using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin,Manager,Trainer")]
public class TestQuestionController : ControllerBase
{
    private readonly ITestQuestionService _service;

    public TestQuestionController(ITestQuestionService service)
    {
        _service = service;
    }

    [HttpGet("{testId:int}")]
    public async Task<IActionResult> GetByTestId(int testId)
    {
        return Ok(await _service.GetByTestIdAsync(testId));
    }

    [HttpPost]
    public async Task<IActionResult> Create(TestQuestion testQuestion)
    {
        return Ok(await _service.CreateAsync(testQuestion));
    }

    [HttpDelete("{testQuestionId:int}")]
    public async Task<IActionResult> Delete(int testQuestionId)
    {
        bool deleted = await _service.DeleteAsync(testQuestionId);

        if (!deleted)
        {
            return NotFound();
        }
        return NoContent();
    }
}
