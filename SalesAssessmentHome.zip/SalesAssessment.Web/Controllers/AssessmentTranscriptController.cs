using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class AssessmentTranscriptController : ControllerBase
{
    private readonly
        IAssessmentTranscriptService _service;

    public AssessmentTranscriptController(IAssessmentTranscriptService service)
    {
        _service = service;
    }

    [HttpGet("{attemptId:int}")]
    public async Task<IActionResult> GetByAttempt(int attemptId)
    {
        return Ok(await _service.GetByAttemptAsync(attemptId));
    }

    [HttpPost]
    public async Task<IActionResult> Create(AssessmentTranscript transcript)
    {
        await _service.AddAsync(transcript);
        return Ok();
    }
}