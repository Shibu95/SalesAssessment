using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin,Manager")]
public class BatchController : ControllerBase
{
    private readonly IBatchService _batchService;

    public BatchController(IBatchService batchService)
    {
        _batchService = batchService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _batchService.GetAllAsync());
    }

    [HttpGet("{batchId:int}")]
    public async Task<IActionResult> GetById(int batchId)
    {
        Batch? batch = await _batchService.GetByIdAsync(batchId);
        if (batch is null)
        {
            return NotFound();
        }
        return Ok(batch);
    }

    [HttpGet("{batchId:int}/trainers")]
    public async Task<IActionResult> GetTrainersByBatch(int batchId)
    {
        return Ok(await _batchService.GetTrainerIdsByBatchAsync(batchId));
    }

    [HttpPost]
    public async Task<IActionResult> Create(Batch batch)
    {
        return Ok(await _batchService.CreateAsync(batch));
    }

    [HttpPut]
    public async Task<IActionResult> Update(Batch batch)
    {
        return Ok(await _batchService.UpdateAsync(batch));
    }

    [HttpDelete("{batchId:int}")]
    public async Task<IActionResult> Delete(int batchId)
    {
        bool deleted = await _batchService.DeleteAsync(batchId);

        if (!deleted)
        {
            return NotFound();
        }
        return NoContent();
    }

    [HttpPost("assign-trainers")]
    public async Task<IActionResult> AssignTrainers([FromBody] AssignTrainersRequest request)
    {
        if (request?.TrainerIds == null || request.TrainerIds.Count == 0)
        {
            return BadRequest("No trainer IDs provided");
        }

        Batch? batch = await _batchService.GetByIdAsync(request.BatchId);
        if (batch is null)
        {
            return NotFound($"Batch with ID {request.BatchId} not found");
        }

        try
        {
            await _batchService.AssignTrainersAsync(request.BatchId, request.TrainerIds);
            return Ok(new { success = true, message = $"Successfully assigned {request.TrainerIds.Count} trainers to batch" });
        }
        catch (Exception ex)
        {
            return BadRequest($"Error assigning trainers: {ex.Message}");
        }
    }

    [HttpPost("upload-sales-reps")]
    public async Task<IActionResult> UploadSalesReps([FromBody] UploadSalesRepsRequest request)
    {
        if (request?.EmailIds == null || request.EmailIds.Count == 0)
        {
            return BadRequest("No email IDs provided");
        }

        Batch? batch = await _batchService.GetByIdAsync(request.BatchId);
        if (batch is null)
        {
            return NotFound($"Batch with ID {request.BatchId} not found");
        }

        try
        {
            await _batchService.UploadSalesRepsAsync(request.BatchId, request.EmailIds);
            return Ok(new { success = true, message = $"Successfully created {request.EmailIds.Count} sales rep entries" });
        }
        catch (Exception ex)
        {
            return BadRequest($"Error creating sales reps: {ex.Message}");
        }
    }

    [HttpGet("scheduled")]
    public async Task<IActionResult> GetScheduledBatches()
    {
        return Ok(await _batchService.GetScheduledBatchesAsync());
    }
}

public class AssignTrainersRequest
{
    public int BatchId { get; set; }
    public List<int> TrainerIds { get; set; } = new();
}

public class UploadSalesRepsRequest
{
    public int BatchId { get; set; }
    public List<string> EmailIds { get; set; } = new();
}
