namespace SalesAssessment.Web.Interfaces;

public interface IAudioRecordingService
{
    Task<string> SaveClipAsync(int attemptId, Stream audioStream);
}
