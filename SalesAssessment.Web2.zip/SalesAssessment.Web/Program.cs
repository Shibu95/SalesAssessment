using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Components;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Services;
using Syncfusion.Blazor;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Components.Authorization;

var builder = WebApplication.CreateBuilder(args);

Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("Ngo9BigBOggjHTQxAR8/V1JAaF5cX2pCdkx3TXxbf1x2ZFRHal9WTnRcUiweQnxTdENjXn5XcXVWQWNfVkVyXkleZw==");

// Add services to the container.
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddSyncfusionBlazor();
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/login";
        options.AccessDeniedPath = "/login";
    });
builder.Services.AddAuthorizationCore();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddScoped<CurrentUserService>();
builder.Services.AddScoped<AuthenticationStateProvider, PersistentAuthenticationStateProvider>();
builder.Services.AddScoped<SidebarService>();

// Database + application services (previously a separate SalesAssessment.Api process).
// A DbContext factory (not a single scoped DbContext) because Blazor Server's
// DI scope is the whole browser circuit, not one request — a shared DbContext
// would accumulate tracked entities across unrelated operations (e.g. a grid
// load, then an edit) and EF Core throws on the resulting key conflicts.
builder.Services.AddDbContextFactory<SalesAssessmentDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("Postgres")));

builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ITrainerService, TrainerService>();
builder.Services.AddScoped<ISalesRepService, SalesRepService>();
builder.Services.AddScoped<IScenarioService, ScenarioService>();
builder.Services.AddScoped<IScenarioAssignmentService, ScenarioAssignmentService>();
builder.Services.AddScoped<IRoleService, RoleService>();
builder.Services.AddScoped<IBatchService, BatchService>();
builder.Services.AddScoped<ITestService, TestService>();
builder.Services.AddScoped<ITestQuestionService, TestQuestionService>();
builder.Services.AddScoped<ILookupService, LookupService>();
builder.Services.AddScoped<IAssessmentAttemptService, AssessmentAttemptService>();
builder.Services.AddScoped<IAssessmentTranscriptService, AssessmentTranscriptService>();
builder.Services.AddScoped<IAssessmentResultService, AssessmentResultService>();
builder.Services.AddHttpClient<IBoldAgentService, BoldAgentService>();
builder.Services.AddHttpClient<IEvaluationAgentService, EvaluationAgentService>();
builder.Services.AddScoped<IAudioRecordingService, AudioRecordingService>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// This project has no EF Core migrations (schema is managed by hand against
// Postgres), so new columns are applied here idempotently on startup instead.
{
    var contextFactory = app.Services.GetRequiredService<IDbContextFactory<SalesAssessmentDbContext>>();
    await using var db = await contextFactory.CreateDbContextAsync();
    await db.Database.ExecuteSqlRawAsync("""
        ALTER TABLE public.scenarioassignment
            ADD COLUMN IF NOT EXISTS "TestID" integer NULL,
            ADD COLUMN IF NOT EXISTS "SequenceNumber" integer NOT NULL DEFAULT 1,
            ADD COLUMN IF NOT EXISTS "CompletedOn" timestamptz NULL;

        CREATE TABLE IF NOT EXISTS public.assessmentattempt (
            "AssessmentAttemptID" serial PRIMARY KEY,
            "ScenarioAssignmentID" integer NOT NULL,
            "SalesRepID" integer NOT NULL,
            "ScenarioID" integer NOT NULL,
            "ConversationID" text NOT NULL,
            "StartedOn" timestamptz NOT NULL,
            "CompletedOn" timestamptz NULL
        );

        CREATE TABLE IF NOT EXISTS public.assessmenttranscript (
            "AssessmentTranscriptID" serial PRIMARY KEY,
            "AssessmentAttemptID" integer NOT NULL,
            "Sender" text NOT NULL,
            "Message" text NOT NULL,
            "CreatedOn" timestamptz NOT NULL
        );

        CREATE TABLE IF NOT EXISTS public.assessmentresult (
            "AssessmentResultID" serial PRIMARY KEY,
            "AssessmentAttemptID" integer NOT NULL,
            "OverallScore" numeric NOT NULL DEFAULT 0,
            "PerformanceLevel" text NOT NULL DEFAULT '',
            "OverallSummary" text NOT NULL DEFAULT '',
            "OverallReadiness" text NOT NULL DEFAULT '',
            "EvaluationJson" text NOT NULL DEFAULT '',
            "CreatedOn" timestamptz NOT NULL
        );

        ALTER TABLE public.trainer
            ADD COLUMN IF NOT EXISTS "IsActive" boolean NOT NULL DEFAULT true;

        ALTER TABLE public.scenario
            ADD COLUMN IF NOT EXISTS "IsActive" boolean NOT NULL DEFAULT true;

        ALTER TABLE public.assessmenttranscript
            ADD COLUMN IF NOT EXISTS "AudioUrl" text NULL;
        """);
}

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
else
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}

app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAuthentication();
app.UseAuthorization();

app.UseAntiforgery();

// MapStaticAssets() below only serves the build-time asset manifest - it won't
// pick up files created at runtime (e.g. call recordings saved under
// wwwroot/recordings after the app has started), so the classic static file
// middleware is also needed.
app.UseStaticFiles();

app.MapStaticAssets();
app.MapControllers();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
