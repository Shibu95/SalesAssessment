window.callAssessment = {

    _recognition: null,
    _dotNetRef: null,
    _silenceTimer: null,
    _finalTranscript: "",
    _manualStop: false,
    _callEnded: false,
    _micStream: null,
    _mediaRecorder: null,
    _recordedChunks: [],

    startListening: async function (dotNetRef) {
        this._callEnded = false;

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            dotNetRef.invokeMethodAsync("OnMicUnavailable");
            return;
        }

        this._dotNetRef = dotNetRef;
        this._finalTranscript = "";
        this._manualStop = false;
        this._clearSilenceTimer();

        if (!this._micStream && navigator.mediaDevices) {
            try {
                this._micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            } catch (e) {
                console.error("Microphone access for recording failed", e);
            }
        }

        this._startRecorder();
        this._beginRecognition();
    },

    stopListening: function () {
        this._manualStop = true;
        this._clearSilenceTimer();
        if (this._recognition) {
            this._recognition.stop();
        }
        if (this._mediaRecorder && this._mediaRecorder.state !== "inactive") {
            this._mediaRecorder.stop();
        }
    },

    stopAll: function () {
        this._callEnded = true;
        this.stopListening();
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
        if (this._micStream) {
            this._micStream.getTracks().forEach(function (track) { track.stop(); });
            this._micStream = null;
        }
    },

    _startRecorder: function () {
        this._mediaRecorder = null;

        if (!this._micStream || typeof MediaRecorder === "undefined") {
            return;
        }

        try {
            this._recordedChunks = [];
            const recorder = new MediaRecorder(this._micStream);
            const self = this;

            recorder.ondataavailable = function (event) {
                if (event.data && event.data.size > 0) {
                    self._recordedChunks.push(event.data);
                }
            };

            recorder.start();
            this._mediaRecorder = recorder;
        } catch (e) {
            console.error("MediaRecorder start failed", e);
            this._mediaRecorder = null;
        }
    },

    _stopRecorderAndGetBlob: function () {
        const self = this;

        return new Promise(function (resolve) {
            if (!self._mediaRecorder || self._mediaRecorder.state === "inactive") {
                resolve(null);
                return;
            }

            self._mediaRecorder.onstop = function () {
                const blob = self._recordedChunks.length > 0
                    ? new Blob(self._recordedChunks, { type: "audio/webm" })
                    : null;
                resolve(blob);
            };

            self._mediaRecorder.stop();
        });
    },

    _beginRecognition: function () {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        const self = this;

        recognition.lang = "en-US";
        recognition.interimResults = true;
        recognition.continuous = true;

        recognition.onstart = function () {
            self._dotNetRef.invokeMethodAsync("ListeningStarted");
        };

        recognition.onresult = function (event) {
            for (let i = event.resultIndex; i < event.results.length; i++) {
                if (event.results[i].isFinal) {
                    const chunk = event.results[i][0].transcript.trim();
                    if (chunk) {
                        self._finalTranscript = (self._finalTranscript + " " + chunk).trim();
                    }
                }
            }

            self._dotNetRef.invokeMethodAsync("SpeechDetected");
            self._resetSilenceTimer();
        };

        recognition.onerror = function (event) {
            if (event.error === "not-allowed" || event.error === "service-not-allowed") {
                self._manualStop = true;
                self._clearSilenceTimer();
                self._dotNetRef.invokeMethodAsync("OnMicPermissionDenied");
            }
            // Other errors (e.g. "no-speech") are recoverable via the onend restart below.
        };

        recognition.onend = function () {
            self._dotNetRef.invokeMethodAsync("ListeningEnded");

            if (!self._manualStop) {
                // The browser ended the engine on its own (continuous recognition is
                // commonly time-limited) - restart transparently without losing
                // anything already accumulated or resetting the silence timer or the
                // in-progress audio recording.
                self._beginRecognition();
                self._recognition.start();
            }
        };

        this._recognition = recognition;
        recognition.start();
    },

    _resetSilenceTimer: function () {
        this._clearSilenceTimer();

        const self = this;
        this._silenceTimer = setTimeout(function () {
            self._finalizeTurn();
        }, 3000);
    },

    _clearSilenceTimer: function () {
        if (this._silenceTimer) {
            clearTimeout(this._silenceTimer);
            this._silenceTimer = null;
        }
    },

    _finalizeTurn: function () {
        this._manualStop = true;

        if (this._recognition) {
            this._recognition.stop();
        }

        const transcript = this._finalTranscript.trim();
        this._finalTranscript = "";
        const self = this;

        this._stopRecorderAndGetBlob().then(function (blob) {
            if (!transcript) {
                return;
            }

            if (blob && blob.size > 0) {
                blob.arrayBuffer().then(function (buffer) {
                    const streamRef = DotNet.createJSStreamReference(buffer);
                    self._dotNetRef.invokeMethodAsync("ReceiveTranscript", transcript, streamRef);
                });
            } else {
                self._dotNetRef.invokeMethodAsync("ReceiveTranscript", transcript, null);
            }
        });
    }
};

window.callSpeechSynthesis = {

    speak: function (text, dotNetRef) {
        if (!text) {
            return;
        }

        window.callAssessment.stopListening();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "en-US";

        utterance.onstart = function () {
            dotNetRef.invokeMethodAsync("CustomerSpeakingStarted");
        };

        utterance.onend = function () {
            dotNetRef.invokeMethodAsync("CustomerSpeakingEnded");

            if (!window.callAssessment._callEnded) {
                window.callAssessment.startListening(dotNetRef);
            }
        };

        speechSynthesis.speak(utterance);
    }
};

// Independent playback helpers used by the Trainer/Admin Dashboard to listen
// back to a completed call. Deliberately separate from callAssessment /
// callSpeechSynthesis so reviewing a past call never touches live-call state.
window.audioPlayback = {

    playClip: function (url) {
        return new Promise(function (resolve) {
            const audio = new Audio(url);
            audio.onended = function () { resolve(); };
            audio.onerror = function () { resolve(); };
            audio.play().catch(function () { resolve(); });
        });
    },

    speak: function (text) {
        return new Promise(function (resolve) {
            if (!text) {
                resolve();
                return;
            }

            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = "en-US";
            utterance.onend = function () { resolve(); };
            utterance.onerror = function () { resolve(); };
            speechSynthesis.speak(utterance);
        });
    }
};
