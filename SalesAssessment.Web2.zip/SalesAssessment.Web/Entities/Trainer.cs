using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("trainer", Schema = "public")]
    public class Trainer
    {
        [Key]
        public int TrainerID { get; set; }

        [Required]
        public string EmailID { get; set; } = string.Empty;
        [Required]
        public int RoleID { get; set; }

        [Required]
        public DateTime CreatedOn { get; set; }

        public bool IsActive { get; set; } = true;
    }
}