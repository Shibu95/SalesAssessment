using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class AudioRecordingService : IAudioRecordingService
{
    private readonly IWebHostEnvironment _webHostEnvironment;

    public AudioRecordingService(IWebHostEnvironment webHostEnvironment)
    {
        _webHostEnvironment = webHostEnvironment;
    }

    public async Task<string> SaveClipAsync(int attemptId, Stream audioStream)
    {
        string relativeDirectory = Path.Combine("recordings", attemptId.ToString());
        string absoluteDirectory = Path.Combine(_webHostEnvironment.WebRootPath, relativeDirectory);
        Directory.CreateDirectory(absoluteDirectory);

        string fileName = $"{Guid.NewGuid()}.webm";
        string absolutePath = Path.Combine(absoluteDirectory, fileName);

        await using FileStream fileStream = File.Create(absolutePath);
        await audioStream.CopyToAsync(fileStream);

        return $"/{relativeDirectory.Replace('\\', '/')}/{fileName}";
    }
}
