using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class BatchService : IBatchService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public BatchService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<Batch>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        var batches = await context.Batches.AsNoTracking().OrderByDescending(x => x.CreatedOn).ToListAsync();
        await EnrichAsync(context, batches);
        return batches;
    }

    public async Task<List<Batch>> GetByTrainerIdAsync(int trainerId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<int> batchIds = await context.BatchTrainers.AsNoTracking().Where(bt => bt.TrainerID == trainerId).Select(bt => bt.BatchID).ToListAsync();

        var batches = await context.Batches.AsNoTracking()
            .Where(x => batchIds.Contains(x.BatchID))
            .OrderByDescending(x => x.CreatedOn)
            .ToListAsync();

        await EnrichAsync(context, batches);
        return batches;
    }

    private static async Task EnrichAsync(SalesAssessmentDbContext context, List<Batch> batches)
    {
        // Enrich batches with sales rep count and trainer email
        foreach (var batch in batches)
        {
            NormalizeUtc(batch);

            // Get sales rep count for this batch
            batch.SalesRepCount = await context.SalesReps.CountAsync(sr => sr.BatchID == batch.BatchID);

            // Get trainer email for this batch
            var batchTrainer = await context.BatchTrainers.AsNoTracking().FirstOrDefaultAsync(bt => bt.BatchID == batch.BatchID);

            if (batchTrainer != null)
            {
                var trainer = await context.Trainers.AsNoTracking().FirstOrDefaultAsync(t => t.TrainerID == batchTrainer.TrainerID);
                batch.TrainerEmail = trainer?.EmailID ?? string.Empty;
            }
        }
    }

    public async Task<Batch?> GetByIdAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Batch? batch = await context.Batches.AsNoTracking().FirstOrDefaultAsync(x => x.BatchID == batchId);

        if (batch is not null)
        {
            NormalizeUtc(batch);
        }

        return batch;
    }

    private static void NormalizeUtc(Batch batch)
    {
        batch.StartDate = DateTime.SpecifyKind(batch.StartDate, DateTimeKind.Utc);
        batch.CreatedOn = DateTime.SpecifyKind(batch.CreatedOn, DateTimeKind.Utc);
    }

    public async Task<Batch> CreateAsync(Batch batch)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        batch.CreatedOn = DateTime.UtcNow;
        batch.StartDate = DateTime.SpecifyKind(batch.StartDate, DateTimeKind.Utc);
        context.Batches.Add(batch);
        await context.SaveChangesAsync();
        return batch;
    }

    public async Task<Batch> UpdateAsync(Batch batch)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        batch.StartDate = DateTime.SpecifyKind(batch.StartDate, DateTimeKind.Utc);
        DateTime existingCreatedOn = await context.Batches
            .Where(x => x.BatchID == batch.BatchID)
            .Select(x => x.CreatedOn)
            .FirstOrDefaultAsync();
        batch.CreatedOn = DateTime.SpecifyKind(existingCreatedOn, DateTimeKind.Utc);
        context.Batches.Update(batch);
        await context.SaveChangesAsync();
        return batch;
    }

    public async Task<bool> DeleteAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Batch? batch = await context.Batches.FindAsync(batchId);

        if (batch is null)
        {
            return false;
        }

        context.Batches.Remove(batch);
        await context.SaveChangesAsync();
        return true;
    }

    public async Task<List<Batch>> GetStartedBatchesAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        BatchStatus? startedStatus = await context.BatchStatuses.AsNoTracking().FirstOrDefaultAsync(x => x.BatchStatusName == "Started");
        if (startedStatus is null)
        {
            return [];
        }
        return await context.Batches.AsNoTracking().Where(x => x.BatchStatusID == startedStatus.BatchStatusID).OrderBy(x => x.BatchName).ToListAsync();
    }

    public async Task<List<int>> GetTrainerIdsByBatchAsync(int batchId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.BatchTrainers.AsNoTracking().Where(bt => bt.BatchID == batchId).Select(bt => bt.TrainerID).ToListAsync();
    }

    public async Task AssignTrainersAsync(int batchId, List<int> trainerIds)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        var existingAssignments = context.BatchTrainers.Where(bt => bt.BatchID == batchId);
        context.BatchTrainers.RemoveRange(existingAssignments);
        await context.SaveChangesAsync();

        foreach (int trainerId in trainerIds)
        {
            context.BatchTrainers.Add(new BatchTrainer { BatchID = batchId, TrainerID = trainerId });
        }

        await context.SaveChangesAsync();
    }

    public async Task UploadSalesRepsAsync(int batchId, List<string> emailIds)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<SalesRep> existing = await context.SalesReps.AsNoTracking().Where(x => x.BatchID == batchId).ToListAsync();

        foreach (string email in emailIds)
        {
            if (string.IsNullOrWhiteSpace(email))
            {
                continue;
            }

            string trimmedEmail = email.Trim();

            if (existing.Any(sr => sr.EmailID.Equals(trimmedEmail, StringComparison.OrdinalIgnoreCase)))
            {
                continue;
            }

            context.SalesReps.Add(new SalesRep
            {
                EmailID = trimmedEmail,
                BatchID = batchId,
                CreatedOn = DateTime.UtcNow
            });
        }

        await context.SaveChangesAsync();
    }
}
