using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class TestQuestionService : ITestQuestionService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public TestQuestionService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<TestQuestion>> GetByTestIdAsync(int testId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.TestQuestions.AsNoTracking().Where(x => x.TestID == testId).ToListAsync();
    }

    public async Task<TestQuestion> CreateAsync(TestQuestion testQuestion)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.TestQuestions.Add(testQuestion);
        await context.SaveChangesAsync();

        AssessmentType? assessmentType = await context.AssessmentTypes
            .FirstOrDefaultAsync(x => x.AssessmentTypeID == testQuestion.AssessmentTypeID);

        if (assessmentType is not null && assessmentType.AssessmentTypeName == "Mock Sales Call")
        {
            await GenerateScenarioAssignmentsAsync(context, testQuestion);
        }

        return testQuestion;
    }

    public async Task<TestQuestion> UpdateAsync(TestQuestion testQuestion)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.TestQuestions.Update(testQuestion);
        await context.SaveChangesAsync();
        return testQuestion;
    }

    private static async Task GenerateScenarioAssignmentsAsync(SalesAssessmentDbContext context, TestQuestion testQuestion)
    {
        Test? test = await context.Tests.FirstOrDefaultAsync(x => x.TestID == testQuestion.TestID);

        if (test is null)
        {
            return;
        }

        List<SalesRep> salesReps = await context.SalesReps
            .Where(x => x.BatchID == test.BatchID)
            .ToListAsync();

        List<Scenario> pool = await context.Scenarios.Where(x => x.IsActive).ToListAsync();

        AssessmentStatus? assignedStatus = await context.AssessmentStatuses
            .FirstOrDefaultAsync(x => x.AssessmentStatusName == "Assigned");

        if (salesReps.Count == 0 || pool.Count == 0 || assignedStatus is null)
        {
            return;
        }

        int countToAssign = Math.Min(testQuestion.NoOfQuestions, pool.Count);
        Random random = new();
        DateTime assignedOn = DateTime.UtcNow;

        foreach (SalesRep salesRep in salesReps)
        {
            List<Scenario> shuffled = pool.OrderBy(_ => random.Next()).ToList();

            for (int i = 0; i < countToAssign; i++)
            {
                context.ScenarioAssignments.Add(new ScenarioAssignment
                {
                    ScenarioID = shuffled[i].ScenarioID,
                    SalesRepID = salesRep.SalesRepID,
                    TestID = test.TestID,
                    SequenceNumber = i + 1,
                    AssessmentStatusID = assignedStatus.AssessmentStatusID,
                    AssignedByTrainerID = test.CreatedByTrainerID,
                    AssignedOn = assignedOn
                });
            }
        }

        await context.SaveChangesAsync();
    }

    public async Task<bool> DeleteAsync(int testQuestionId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        TestQuestion? item = await context.TestQuestions.FindAsync(testQuestionId);

        if (item is null)
        {
            return false;
        }
        context.TestQuestions.Remove(item);
        await context.SaveChangesAsync();
        return true;
    }
}
