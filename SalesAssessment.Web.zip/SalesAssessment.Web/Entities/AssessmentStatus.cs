using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("assessmentstatus", Schema = "public")]
    public class AssessmentStatus
    {
        [Key]
        public int AssessmentStatusID { get; set; }

        [Required]
        public string AssessmentStatusName { get; set; } = string.Empty;
    }
}