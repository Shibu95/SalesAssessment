using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("concern", Schema = "public")]
    public class Concern
    {
        [Key]
        public int ConcernID { get; set; }

        [Required]
        public string ConcernName { get; set; } = string.Empty;
    }
}