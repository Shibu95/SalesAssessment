using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("testquestion", Schema = "public")]
    public class TestQuestion
    {
        [Key]
        public int TestQuestionID { get; set; }

        public int TestID { get; set; }

        public int AssessmentTypeID { get; set; }

        public int NoOfQuestions { get; set; }
    }
}