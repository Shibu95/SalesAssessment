using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("salesrep", Schema = "public")]
    public class SalesRep
    {
        [Key]
        public int SalesRepID { get; set; }

        [Required]
        public string EmailID { get; set; } = string.Empty;
        public int? BatchID { get; set; }

        [Required]
        public DateTime CreatedOn { get; set; }
    }
}