using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities;

[Table("assessmentresult", Schema = "public")]
public class AssessmentResult
{
    [Key]
    public int AssessmentResultID { get; set; }

    [Required]
    public int AssessmentAttemptID { get; set; }

    public decimal OverallScore { get; set; }

    public string PerformanceLevel { get; set; } = string.Empty;

    public string OverallSummary { get; set; } = string.Empty;
    public string OverallReadiness { get; set; } = string.Empty;

    public string EvaluationJson { get; set; } = string.Empty;

    public DateTime CreatedOn { get; set; }
}