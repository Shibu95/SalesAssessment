using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("customerpersonality", Schema = "public")]
    public class CustomerPersonality
    {
        [Key]
        public int CustomerPersonalityID { get; set; }

        [Required]
        public string Personality { get; set; } = string.Empty;
    }
}