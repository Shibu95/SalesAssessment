using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("industry", Schema = "public")]
    public class Industry
    {
        [Key]
        public int IndustryID { get; set; }

        [Required]
        public string IndustryName { get; set; } = string.Empty;
    }
}