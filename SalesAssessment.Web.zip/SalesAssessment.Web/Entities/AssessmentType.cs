using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities;

[Table("assessmenttype", Schema = "public")]
public class AssessmentType
{
    [Key]
    public int AssessmentTypeID { get; set; }

    [Required]
    public string AssessmentTypeName { get; set; } = string.Empty;
}