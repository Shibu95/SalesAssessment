using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities;

[Table("scenario", Schema = "public")]
public class Scenario
{
    [Key]
    public int ScenarioID { get; set; }

    [Required]
    public string Title { get; set; } = string.Empty;

    [Required]
    public string CustomerName { get; set; } = string.Empty;

    [Required]
    public string Company { get; set; } = string.Empty;

    [Required]
    public int IndustryID { get; set; }

    [Required]
    public string Role { get; set; } = string.Empty;

    [Required]
    public string CustomerPersonality { get; set; } = string.Empty;

    [Required]
    public string BusinessRequirement { get; set; } = string.Empty;

    [Required]
    public string Concerns { get; set; } = string.Empty;

    [Required]
    public int CreatedByTrainerID { get; set; }

    [Required]
    public DateTime CreatedOn { get; set; }
}