using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities;

[Table("assessmentattempt", Schema = "public")]
public class AssessmentAttempt
{
    [Key]
    public int AssessmentAttemptID { get; set; }

    [Required]
    public int ScenarioAssignmentID { get; set; }

    [Required]
    public int SalesRepID { get; set; }

    [Required]
    public int ScenarioID { get; set; }

    [Required]
    public string ConversationID { get; set; } = string.Empty;

    [Required]
    public DateTime StartedOn { get; set; }

    public DateTime? CompletedOn { get; set; }
}