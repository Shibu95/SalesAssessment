using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("test", Schema = "public")]
    public class Test
    {
        [Key]
        public int TestID { get; set; }

        public int BatchID { get; set; }

        public string TestName { get; set; } = string.Empty;

        public DateTime AssessmentDate { get; set; }

        public int BatchStatusID { get; set; }

        public DateTime CreatedOn { get; set; }

        public int CreatedByTrainerID { get; set; }
    }
}