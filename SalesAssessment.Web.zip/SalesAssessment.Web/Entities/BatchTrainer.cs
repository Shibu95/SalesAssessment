using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("batchtrainer", Schema = "public")]
    public class BatchTrainer
    {
        [Key]
        public int BatchTrainerID { get; set; }

        public int BatchID { get; set; }

        public int TrainerID { get; set; }
    }
}