using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("batchstatus", Schema = "public")]
    public class BatchStatus
    {
        [Key]
        public int BatchStatusID { get; set; }

        [Required]
        public string BatchStatusName { get; set; } = string.Empty;
    }

}