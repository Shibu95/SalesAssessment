using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Web.Entities
{
    [Table("scenarioassignment", Schema = "public")]
    public class ScenarioAssignment
    {
        [Key]
        public int ScenarioAssignmentID { get; set; }

        [Required]
        public int ScenarioID { get; set; }

        [Required]
        public int SalesRepID { get; set; }

        [Required]
        public int AssessmentStatusID { get; set; }

        [Required]
        public int AssignedByTrainerID { get; set; }

        [Required]
        public DateTime AssignedOn { get; set; }

        public int? TestID { get; set; }

        public int SequenceNumber { get; set; }

        public DateTime? CompletedOn { get; set; }
    }
}