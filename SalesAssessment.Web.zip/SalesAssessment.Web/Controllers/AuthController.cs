using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _authService;

    public AuthController(IAuthService authService)
    {
        _authService = authService;
    }

    [HttpGet("login/{email}")]
    public async Task<IActionResult> Login(string email)
    {
        LoginResponse? result = await _authService.LoginAsync(email);

        if (result is null)
        {
            return NotFound();
        }

        return Ok(result);
    }
}
