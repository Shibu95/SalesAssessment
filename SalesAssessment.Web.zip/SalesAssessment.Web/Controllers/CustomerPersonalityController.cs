using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Entities;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Data;
using Microsoft.EntityFrameworkCore;

namespace SalesAssessment.Web.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CustomerPersonalityController : ControllerBase
    {
        private readonly SalesAssessmentDbContext _context;

        public CustomerPersonalityController(SalesAssessmentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.CustomerPersonalities.OrderBy(x => x.Personality).ToListAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            CustomerPersonality? personality = await _context.CustomerPersonalities.FirstOrDefaultAsync(x => x.CustomerPersonalityID == id);

            if (personality is null)
            {
                return NotFound();
            }

            return Ok(personality);
        }

        [HttpPost]
        public async Task<IActionResult> Create(CustomerPersonality customerPersonality)
        {
            _context.CustomerPersonalities.Add(customerPersonality);
            await _context.SaveChangesAsync();
            return Ok(customerPersonality);
        }

        [HttpPut]
        public async Task<IActionResult> Update(CustomerPersonality customerPersonality)
        {
            _context.CustomerPersonalities.Update(customerPersonality);
            await _context.SaveChangesAsync();
            return Ok(customerPersonality);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            CustomerPersonality? personality = await _context.CustomerPersonalities.FindAsync(id);

            if (personality is null)
            {
                return NotFound();
            }

            _context.CustomerPersonalities.Remove(personality);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}