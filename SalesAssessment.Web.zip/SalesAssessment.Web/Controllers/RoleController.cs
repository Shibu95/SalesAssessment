using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
public class RoleController : ControllerBase
{
    private readonly IRoleService _roleService;

    public RoleController(IRoleService roleService)
    {
        _roleService = roleService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _roleService.GetAllAsync());
    }

    [HttpGet("{roleId:int}")]
    public async Task<IActionResult> GetById(int roleId)
    {
        Role? role = await _roleService.GetByIdAsync(roleId);

        if (role is null)
        {
            return NotFound();
        }

        return Ok(role);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Role role)
    {
        return Ok(await _roleService.CreateAsync(role));
    }

    [HttpPut]
    public async Task<IActionResult> Update(Role role)
    {
        return Ok(await _roleService.UpdateAsync(role));
    }

    [HttpDelete("{roleId:int}")]
    public async Task<IActionResult> Delete(int roleId)
    {
        bool deleted = await _roleService.DeleteAsync(roleId);

        if (!deleted)
        {
            return NotFound();
        }

        return NoContent();
    }
}