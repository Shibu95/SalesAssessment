using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ScenarioController : ControllerBase
{
    private readonly IScenarioService _scenarioService;

    public ScenarioController(IScenarioService scenarioService)
    {
        _scenarioService = scenarioService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _scenarioService.GetAllAsync());
    }

    [HttpGet("{scenarioId:int}")]
    public async Task<IActionResult> GetById(int scenarioId)
    {
        Scenario? scenario = await _scenarioService.GetByIdAsync(scenarioId);

        if (scenario is null)
        {
            return NotFound();
        }

        return Ok(scenario);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Scenario scenario)
    {
        Scenario result = await _scenarioService.CreateAsync(scenario);

        return Ok(result);
    }

    [HttpPut]
    public async Task<IActionResult> Update(Scenario scenario)
    {
        Scenario result = await _scenarioService.UpdateAsync(scenario);
        return Ok(result);
    }

    [HttpDelete("{scenarioId:int}")]
    public async Task<IActionResult> Delete(int scenarioId)
    {
        bool deleted = await _scenarioService.DeleteAsync(scenarioId);

        if (!deleted)
        {
            return NotFound();
        }

        return NoContent();
    }
}