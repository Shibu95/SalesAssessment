using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Entities;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Web.Data;
using Microsoft.EntityFrameworkCore;

namespace SalesAssessment.Web.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ConcernController : ControllerBase
    {
        private readonly SalesAssessmentDbContext _context;

        public ConcernController(SalesAssessmentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.Concerns.OrderBy(x => x.ConcernName).ToListAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            Concern? concerns = await _context.Concerns.FirstOrDefaultAsync(x => x.ConcernID == id);

            if (concerns is null)
            {
                return NotFound();
            }

            return Ok(concerns);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Concern concern)
        {
            _context.Concerns.Add(concern);
            await _context.SaveChangesAsync();
            return Ok(concern);
        }

        [HttpPut]
        public async Task<IActionResult> Update(Concern concern)
        {
            _context.Concerns.Update(concern);
            await _context.SaveChangesAsync();
            return Ok(concern);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            Concern? concerns = await _context.Concerns.FindAsync(id);

            if (concerns is null)
            {
                return NotFound();
            }

            _context.Concerns.Remove(concerns);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}