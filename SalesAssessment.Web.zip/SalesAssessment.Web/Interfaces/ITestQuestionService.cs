using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface ITestQuestionService
{
    Task<List<TestQuestion>> GetByTestIdAsync(int testId);

    Task<TestQuestion> CreateAsync(TestQuestion testQuestion);

    Task<TestQuestion> UpdateAsync(TestQuestion testQuestion);

    Task<bool> DeleteAsync(int testQuestionId);
}