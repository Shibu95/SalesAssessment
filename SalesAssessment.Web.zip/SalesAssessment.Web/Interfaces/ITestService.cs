using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface ITestService
{
    Task<List<Test>> GetAllAsync();

    Task<Test?> GetByIdAsync(int testId);

    Task<Test> CreateAsync(Test test);

    Task<Test> UpdateAsync(Test test);

    Task<bool> DeleteAsync(int testId);
}