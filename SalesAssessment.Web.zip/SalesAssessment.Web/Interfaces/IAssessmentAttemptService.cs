using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces
{
    public interface IAssessmentAttemptService
    {
        Task<AssessmentAttempt> StartAsync(int assignmentId, int salesRepId, int scenarioId, string conversationId);
        Task<AssessmentAttempt?> GetByIdAsync(int assessmentAttemptId);
        Task CompleteAsync(int attemptId);
        Task<AssessmentAttempt?> GetByAssignmentAsync(int scenarioAssignmentId);
    }
}