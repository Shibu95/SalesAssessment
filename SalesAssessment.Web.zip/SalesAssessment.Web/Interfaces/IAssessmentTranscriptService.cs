using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces
{
    public interface IAssessmentTranscriptService
    {
        Task AddAsync(AssessmentTranscript transcript);

        Task<List<AssessmentTranscript>> GetByAttemptAsync(int attemptId);
    }
}