namespace SalesAssessment.Web.Interfaces;

public interface ILookupService
{
    Task<List<T>> GetAllAsync<T>() where T : class;

    Task<T> CreateAsync<T>(T entity) where T : class;

    Task<T> UpdateAsync<T>(T entity) where T : class;

    Task<bool> DeleteAsync<T>(int id) where T : class;
}
