using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface IScenarioService
{
    Task<List<Scenario>> GetAllAsync();

    Task<Scenario?> GetByIdAsync(int scenarioId);

    Task<Scenario> CreateAsync(Scenario scenario);

    Task<Scenario> UpdateAsync(Scenario scenario);

    Task<bool> DeleteAsync(int scenarioId);
}