using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Interfaces;

public interface IAuthService
{
    Task<LoginResponse?> LoginAsync(string email);
}
