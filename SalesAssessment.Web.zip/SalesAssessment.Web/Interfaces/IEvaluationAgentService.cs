using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Interfaces;

public interface IEvaluationAgentService
{
    Task<EvaluationReport> AnalyzeTranscriptAsync(string transcript);
}