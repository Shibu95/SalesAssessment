using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface ISalesRepService
{
    Task<List<SalesRep>> GetAllAsync();

    Task<SalesRep?> GetByIdAsync(int salesRepId);

    Task<SalesRep> CreateAsync(SalesRep salesRep);

    Task<SalesRep> UpdateAsync(SalesRep salesRep);

    Task<bool> DeleteAsync(int salesRepId);
}