using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface ITrainerService
{
    Task<List<Trainer>> GetAllAsync();

    Task<Trainer?> GetByIdAsync(int trainerId);

    Task<Trainer> CreateAsync(Trainer trainer);

    Task<Trainer> UpdateAsync(Trainer trainer);

    Task<bool> DeleteAsync(int trainerId);
}