using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Entities;

namespace SalesAssessment.Web.Interfaces;

public interface IBoldAgentService
{
    Task<string> CreateConversationAsync();

    Task<string> SendMessageAsync(string conversationId, string message);

    Task InitializeScenarioAsync(string conversationId, Scenario scenario);
}