using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models
{
    public class DashboardAssessmentViewModel
    {
        public decimal OverallScore { get; set; }

        public string PerformanceLevel { get; set; } = string.Empty;

        public string OverallSummary { get; set; } = string.Empty;

        public List<string> KeyStrengths { get; set; } = [];

        public List<string> DevelopmentAreas { get; set; } = [];
    }
}