namespace SalesAssessment.Web.Models;

public class HomeAssessmentViewModel
{
    public int AssessmentResultID { get; set; }

    public string ScenarioTitle { get; set; } = string.Empty;

    public DateTime CompletedOn { get; set; }

    public EvaluationReport Report { get; set; } = new();
}