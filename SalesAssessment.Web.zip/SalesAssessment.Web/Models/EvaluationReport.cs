using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models;

public class EvaluationReport
{
    public decimal OverallScore { get; set; }

    public string PerformanceLevel { get; set; } = string.Empty;

    public string OverallSummary { get; set; } = string.Empty;

    public List<CompetencyResult> Competencies { get; set; } = [];

    public List<string> KeyStrengths { get; set; } = [];

    public List<string> DevelopmentAreas { get; set; } = [];

    public List<string> CoachingRecommendations { get; set; } = [];

    public string OverallReadiness { get; set; } = string.Empty;
}