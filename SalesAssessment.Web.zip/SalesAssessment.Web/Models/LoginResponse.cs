namespace SalesAssessment.Web.Models
{
    public class LoginResponse
    {
        public string EmailID { get; set; } = string.Empty;
        public string Role { get; set; } = string.Empty;
        public int? TrainerID { get; set; }
        public int? SalesRepID { get; set; }
    }
}
