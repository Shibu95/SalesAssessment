using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models;

public sealed class CreateConversationResponse
{
    public string Id { get; set; } = string.Empty;

    public string Message { get; set; } = string.Empty;
}