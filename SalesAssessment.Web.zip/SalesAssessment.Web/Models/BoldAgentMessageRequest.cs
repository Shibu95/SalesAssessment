using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models;

public class BoldAgentMessageRequest
{
    public string Content { get; set; } = string.Empty;

    public int ChunkRetrievalStrategy { get; set; } = 1;

    public int OrchestrationStrategy { get; set; } = 1;
}