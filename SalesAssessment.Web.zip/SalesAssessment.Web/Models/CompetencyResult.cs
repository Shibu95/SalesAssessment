using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models;

public class CompetencyResult
{
    public string Name { get; set; } = string.Empty;

    public decimal Score { get; set; }

    public List<string> Strengths { get; set; } = [];

    public List<string> Improvements { get; set; } = [];
}