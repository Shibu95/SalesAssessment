using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models
{
    public class MessageResult
    {
        public string? Content { get; set; }

        public string? TextContent { get; set; }
    }
}