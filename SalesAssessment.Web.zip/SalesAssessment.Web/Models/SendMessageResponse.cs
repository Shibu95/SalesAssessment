using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models
{
    public class SendMessageResponse
    {
        public MessageResult? Message { get; set; }
    }
}