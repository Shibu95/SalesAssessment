// Auto-collapse sidebar on mobile, expand on desktop
export function initSidebarResponsive(dotnetRef) {
    const MOBILE_BREAKPOINT = 640;

    function handleResize() {
        const isCollapsed = window.innerWidth <= MOBILE_BREAKPOINT;
        
        // Get current sidebar state
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            // On mobile (≤640px): force collapsed
            if (isCollapsed && !sidebar.classList.contains('collapsed')) {
                dotnetRef.invokeMethodAsync('SetSidebarCollapsed', true);
            }
            // On desktop (>640px): expand if needed
            else if (!isCollapsed && sidebar.classList.contains('collapsed')) {
                // Optionally auto-expand on desktop, or keep manual control
                // Uncomment next line to auto-expand on desktop
                // dotnetRef.invokeMethodAsync('SetSidebarCollapsed', false);
            }
        }
    }

    // Check on initial load
    handleResize();

    // Listen for window resize
    window.addEventListener('resize', handleResize);

    // Return cleanup function
    return {
        dispose: () => {
            window.removeEventListener('resize', handleResize);
        }
    };
}
