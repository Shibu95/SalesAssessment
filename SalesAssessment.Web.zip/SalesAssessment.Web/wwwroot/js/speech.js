window.speechRecognition = {

    startRecognition: function (dotNetHelper) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            alert("Speech Recognition is not supported in this browser.");
            return;
        }

        const recognition = new SpeechRecognition();

        recognition.lang = "en-US";
        recognition.interimResults = false;
        recognition.continuous = false;

        recognition.onresult = function (event) {
            const transcript = event.results[0][0].transcript;
            dotNetHelper.invokeMethodAsync("ReceiveTranscript", transcript);
        };

        recognition.onerror = function (event) {
            console.error(event);
        };

        recognition.start();
    }
};

window.speechSynthesisService = {

    speakAndListen: function (text, dotnetRef) {

        if (!text) {
            return;
        }

        const utterance = new SpeechSynthesisUtterance(text);

        utterance.lang = "en-US";

        utterance.onend = function () {
            window.speechRecognition.startRecognition(dotnetRef);
        };

        speechSynthesis.speak(utterance);
    }
};

recognition.onstart = function () {

    dotnetRef.invokeMethodAsync("ListeningStarted");
};

recognition.onend = function () {

    dotnetRef.invokeMethodAsync("ListeningEnded");
};