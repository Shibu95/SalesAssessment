// File download utility for Excel and other files
window.downloadFile = function (data, filename) {
    let blob;

    // Check if data is base64 string or byte array
    if (typeof data === 'string') {
        try {
            // Clean the base64 string - remove whitespace and newlines
            const cleanBase64 = data.replace(/\s/g, '');

            // Decode base64 to binary string
            const byteCharacters = atob(cleanBase64);
            const byteNumbers = new Array(byteCharacters.length);

            for (let i = 0; i < byteCharacters.length; i++) {
                byteNumbers[i] = byteCharacters.charCodeAt(i);
            }

            const byteArray = new Uint8Array(byteNumbers);
            blob = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        } catch (error) {
            console.error('Base64 decode error:', error);
            // Fallback: treat as regular data URL or plain text
            blob = new Blob([data], { type: 'application/octet-stream' });
        }
    } else if (data instanceof Uint8Array) {
        blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    } else {
        blob = new Blob([data], { type: 'application/octet-stream' });
    }

    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename || 'download';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
};
