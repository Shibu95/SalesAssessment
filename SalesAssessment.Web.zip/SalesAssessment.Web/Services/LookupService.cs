using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class LookupService : ILookupService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public LookupService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<T>> GetAllAsync<T>() where T : class
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.Set<T>().AsNoTracking().ToListAsync();
    }

    public async Task<T> CreateAsync<T>(T entity) where T : class
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.Set<T>().Add(entity);
        await context.SaveChangesAsync();
        return entity;
    }

    public async Task<T> UpdateAsync<T>(T entity) where T : class
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.Set<T>().Update(entity);
        await context.SaveChangesAsync();
        return entity;
    }

    public async Task<bool> DeleteAsync<T>(int id) where T : class
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        T? entity = await context.Set<T>().FindAsync(id);

        if (entity is null)
        {
            return false;
        }

        context.Set<T>().Remove(entity);
        await context.SaveChangesAsync();
        return true;
    }
}
