using Microsoft.AspNetCore.Components.Authorization;
using System.Security.Claims;

namespace SalesAssessment.Web.Services
{
    public class PersistentAuthenticationStateProvider : AuthenticationStateProvider
    {
        private static readonly ClaimsPrincipal _unauthenticatedUser = new(new ClaimsIdentity());

        private readonly CurrentUserService _currentUserService;

        public PersistentAuthenticationStateProvider(CurrentUserService currentUserService)
        {
            _currentUserService = currentUserService;
            _currentUserService.OnChange += HandleUserChanged;
        }

        public override Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            if (!_currentUserService.IsLoggedIn)
            {
                return Task.FromResult(new AuthenticationState(_unauthenticatedUser));
            }

            var identity = new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.NameIdentifier, _currentUserService.Email!),
                new Claim(ClaimTypes.Name, _currentUserService.Email!),
                new Claim(ClaimTypes.Role, _currentUserService.Role!)
            }, "Custom");

            var user = new ClaimsPrincipal(identity);
            return Task.FromResult(new AuthenticationState(user));
        }

        private void HandleUserChanged()
        {
            NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
        }
    }
}
