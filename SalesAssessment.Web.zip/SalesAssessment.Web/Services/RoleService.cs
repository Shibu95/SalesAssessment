using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class RoleService : IRoleService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public RoleService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<Role>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.Roles.AsNoTracking().OrderBy(x => x.RoleName).ToListAsync();
    }

    public async Task<Role?> GetByIdAsync(int roleId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.Roles.AsNoTracking().FirstOrDefaultAsync(x => x.RoleID == roleId);
    }

    public async Task<Role> CreateAsync(Role role)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.Roles.Add(role);
        await context.SaveChangesAsync();
        return role;
    }

    public async Task<Role> UpdateAsync(Role role)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.Roles.Update(role);
        await context.SaveChangesAsync();
        return role;
    }

    public async Task<bool> DeleteAsync(int roleId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Role? role = await context.Roles.FindAsync(roleId);

        if (role is null)
        {
            return false;
        }

        context.Roles.Remove(role);
        await context.SaveChangesAsync();
        return true;
    }
}
