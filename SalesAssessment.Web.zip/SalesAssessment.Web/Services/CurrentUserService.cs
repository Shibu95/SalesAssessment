namespace SalesAssessment.Web.Services;

public class CurrentUserService
{
    public string? Email { get; private set; }
    public string? Role { get; private set; }
    public int? SalesRepID { get; private set; }
    public bool IsLoggedIn => !string.IsNullOrEmpty(Email);

    public event Action? OnChange;

    public void SetUser(string email, string role, int? salesRepId = null)
    {
        Email = email;
        Role = role;
        SalesRepID = salesRepId;
        OnChange?.Invoke();
    }

    public void Logout()
    {
        Email = null;
        Role = null;
        SalesRepID = null;
        OnChange?.Invoke();
    }
}
