using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class SalesRepService : ISalesRepService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public SalesRepService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<SalesRep>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<SalesRep> salesReps = await context.SalesReps.AsNoTracking().OrderBy(x => x.EmailID).ToListAsync();
        salesReps.ForEach(NormalizeUtc);
        return salesReps;
    }

    public async Task<SalesRep?> GetByIdAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        SalesRep? salesRep = await context.SalesReps.AsNoTracking().FirstOrDefaultAsync(x => x.SalesRepID == salesRepId);

        if (salesRep is not null)
        {
            NormalizeUtc(salesRep);
        }

        return salesRep;
    }

    private static void NormalizeUtc(SalesRep salesRep)
    {
        salesRep.CreatedOn = DateTime.SpecifyKind(salesRep.CreatedOn, DateTimeKind.Utc);
    }

    public async Task<SalesRep> CreateAsync(SalesRep salesRep)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        salesRep.CreatedOn = DateTime.SpecifyKind(salesRep.CreatedOn, DateTimeKind.Utc);
        context.SalesReps.Add(salesRep);
        await context.SaveChangesAsync();
        return salesRep;
    }

    public async Task<SalesRep> UpdateAsync(SalesRep salesRep)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        DateTime existingCreatedOn = await context.SalesReps
            .Where(x => x.SalesRepID == salesRep.SalesRepID)
            .Select(x => x.CreatedOn)
            .FirstOrDefaultAsync();
        salesRep.CreatedOn = DateTime.SpecifyKind(existingCreatedOn, DateTimeKind.Utc);
        context.SalesReps.Update(salesRep);
        await context.SaveChangesAsync();
        return salesRep;
    }

    public async Task<bool> DeleteAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        SalesRep? salesRep = await context.SalesReps.FindAsync(salesRepId);

        if (salesRep is null)
        {
            return false;
        }

        context.SalesReps.Remove(salesRep);
        await context.SaveChangesAsync();
        return true;
    }
}
