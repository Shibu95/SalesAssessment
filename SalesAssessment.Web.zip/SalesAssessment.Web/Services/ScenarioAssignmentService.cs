using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class ScenarioAssignmentService : IScenarioAssignmentService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public ScenarioAssignmentService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<ScenarioAssignment>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.ScenarioAssignments.AsNoTracking().OrderByDescending(x => x.AssignedOn).ToListAsync();
    }

    public async Task<List<ScenarioAssignment>> GetBySalesRepAsync(int salesRepId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        return await context.ScenarioAssignments
            .AsNoTracking()
            .Where(x => x.SalesRepID == salesRepId)
            .OrderBy(x => x.TestID)
            .ThenBy(x => x.SequenceNumber)
            .ToListAsync();
    }

    public async Task<ScenarioAssignment> CreateAsync(ScenarioAssignment assignment)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.ScenarioAssignments.Add(assignment);
        await context.SaveChangesAsync();
        return assignment;
    }

    public async Task<ScenarioAssignment?> CompleteAsync(int scenarioAssignmentId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        ScenarioAssignment? assignment = await context.ScenarioAssignments
            .FirstOrDefaultAsync(x => x.ScenarioAssignmentID == scenarioAssignmentId);

        if (assignment is null)
        {
            return null;
        }

        AssessmentStatus? completedStatus = await context.AssessmentStatuses
            .FirstOrDefaultAsync(x => x.AssessmentStatusName == "Completed");

        if (completedStatus is not null)
        {
            assignment.AssessmentStatusID = completedStatus.AssessmentStatusID;
        }

        assignment.CompletedOn = DateTime.UtcNow;
        await context.SaveChangesAsync();
        return assignment;
    }
}
