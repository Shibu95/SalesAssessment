using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class TestService : ITestService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public TestService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<List<Test>> GetAllAsync()
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        List<Test> tests = await context.Tests.AsNoTracking().OrderByDescending(x => x.AssessmentDate).ToListAsync();
        tests.ForEach(NormalizeUtc);
        return tests;
    }

    public async Task<Test?> GetByIdAsync(int testId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Test? test = await context.Tests.AsNoTracking().FirstOrDefaultAsync(x => x.TestID == testId);

        if (test is not null)
        {
            NormalizeUtc(test);
        }

        return test;
    }

    private static void NormalizeUtc(Test test)
    {
        test.AssessmentDate = DateTime.SpecifyKind(test.AssessmentDate, DateTimeKind.Utc);
        test.CreatedOn = DateTime.SpecifyKind(test.CreatedOn, DateTimeKind.Utc);
    }

    public async Task<Test> CreateAsync(Test test)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        test.AssessmentDate = DateTime.SpecifyKind(test.AssessmentDate, DateTimeKind.Utc);
        test.CreatedOn = DateTime.SpecifyKind(test.CreatedOn, DateTimeKind.Utc);
        context.Tests.Add(test);
        await context.SaveChangesAsync();
        return test;
    }

    public async Task<Test> UpdateAsync(Test test)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        test.AssessmentDate = DateTime.SpecifyKind(test.AssessmentDate, DateTimeKind.Utc);
        test.CreatedOn = DateTime.SpecifyKind(test.CreatedOn, DateTimeKind.Utc);
        context.Tests.Update(test);
        await context.SaveChangesAsync();
        return test;
    }

    public async Task<bool> DeleteAsync(int testId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        Test? test = await context.Tests.FindAsync(testId);
        if (test is null)
        {
            return false;
        }
        context.Tests.Remove(test);
        await context.SaveChangesAsync();
        return true;
    }
}
