using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public sealed class AuthService : IAuthService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public AuthService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task<LoginResponse?> LoginAsync(string email)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        string normalizedEmail = email.Trim();

        var salesRep = await context.SalesReps
            .AsNoTracking()
            .FirstOrDefaultAsync(x => EF.Functions.ILike(x.EmailID, normalizedEmail));

        if (salesRep is not null)
        {
            return new LoginResponse
            {
                EmailID = salesRep.EmailID,
                Role = "SalesRep",
                SalesRepID = salesRep.SalesRepID
            };
        }

        var trainer = await context.Trainers
            .AsNoTracking()
            .FirstOrDefaultAsync(x => EF.Functions.ILike(x.EmailID, normalizedEmail));

        if (trainer is not null)
        {
            Entities.Role? role = await context.Roles.AsNoTracking().FirstOrDefaultAsync(x => x.RoleID == trainer.RoleID);

            return new LoginResponse
            {
                EmailID = trainer.EmailID,
                Role = role?.RoleName ?? "Trainer",
                TrainerID = trainer.TrainerID
            };
        }

        return null;
    }
}
