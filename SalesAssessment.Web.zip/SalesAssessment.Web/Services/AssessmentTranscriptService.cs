using Microsoft.EntityFrameworkCore;
using SalesAssessment.Web.Data;
using SalesAssessment.Web.Entities;
using SalesAssessment.Web.Interfaces;

namespace SalesAssessment.Web.Services;

public sealed class AssessmentTranscriptService : IAssessmentTranscriptService
{
    private readonly IDbContextFactory<SalesAssessmentDbContext> _contextFactory;

    public AssessmentTranscriptService(IDbContextFactory<SalesAssessmentDbContext> contextFactory)
    {
        _contextFactory = contextFactory;
    }

    public async Task AddAsync(AssessmentTranscript transcript)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();
        context.AssessmentTranscripts.Add(transcript);
        await context.SaveChangesAsync();
    }

    public async Task<List<AssessmentTranscript>> GetByAttemptAsync(int attemptId)
    {
        await using SalesAssessmentDbContext context = await _contextFactory.CreateDbContextAsync();

        return await context.AssessmentTranscripts.AsNoTracking().Where(x => x.AssessmentAttemptID == attemptId).OrderBy(x => x.CreatedOn).ToListAsync();
    }
}