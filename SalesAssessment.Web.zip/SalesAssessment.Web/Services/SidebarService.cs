namespace SalesAssessment.Web.Services;

public class SidebarService
{
    public bool IsCollapsed { get; private set; } = true;

    public event Action? OnChange;

    public void Toggle()
    {
        IsCollapsed = !IsCollapsed;
        OnChange?.Invoke();
    }

    public void Set(bool collapsed)
    {
        IsCollapsed = collapsed;
        OnChange?.Invoke();
    }
}