namespace SalesAssessment.Web.Helpers;

/// <summary>
/// Resolves what to show for a person's name.
///
/// Names are not stored in this application - the salesrep and trainer tables hold only
/// an email - so the name always comes from the external HR database, keyed on email.
/// A person with no HR record therefore has no name, and that is reported as-is rather
/// than reconstructed from their email address: a name manufactured from the local part
/// would be a guess rendered in the same place as real HR data, with nothing to tell the
/// two apart.
///
/// Screens that still need to identify the person when no name exists show the email
/// itself, in its own right and clearly as an address - that decision belongs to each
/// screen, so nothing here substitutes one for the other.
/// </summary>
public static class PersonNameHelper
{
    /// <summary>
    /// The HR name, or an em dash when this person has no HR record - which is what a
    /// grid cell or a field labelled "Employee Name" should show in that case.
    /// </summary>
    public static string DisplayName(string? hrName) =>
        !string.IsNullOrWhiteSpace(hrName) ? hrName.Trim() : "-";

    /// <summary>
    /// Avatar initials from the HR name; the email's first letter when there is no HR
    /// record. A single letter is a label, not a claim about the person's name.
    /// </summary>
    public static string Initials(string? hrName, string? email)
    {
        if (!string.IsNullOrWhiteSpace(hrName))
        {
            string[] parts = hrName.Trim().Split(' ', StringSplitOptions.RemoveEmptyEntries);

            if (parts.Length >= 2)
            {
                return $"{parts[0][0]}{parts[^1][0]}".ToUpperInvariant();
            }

            if (parts.Length == 1)
            {
                return parts[0][..1].ToUpperInvariant();
            }
        }

        return string.IsNullOrWhiteSpace(email) ? "?" : email[..1].ToUpperInvariant();
    }
}
