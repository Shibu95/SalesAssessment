namespace SalesAssessment.Web.Helpers;

public static class AssessmentBadgeHelper
{
    public static string StatusBadgeClass(string status) => status switch
    {
        "Completed" => "bg-success",
        "In Progress" => "bg-warning text-dark",
        _ => "bg-secondary"
    };

    public static string ScoreBadgeClass(decimal score) => score switch
    {
        >= 80 => "bg-success",
        >= 50 => "bg-warning text-dark",
        _ => "bg-danger"
    };
}
