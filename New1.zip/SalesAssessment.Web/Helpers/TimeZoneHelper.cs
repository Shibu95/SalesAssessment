namespace SalesAssessment.Web.Helpers;

// All timestamps in this app are stored in UTC (DateTime.UtcNow at write time, Npgsql
// connection configured for UTC). Kenya has no DST and is a fixed UTC+3 offset year-round,
// so a custom zero-dependency TimeZoneInfo is used instead of TimeZoneInfo.FindSystemTimeZoneById -
// that call needs an OS timezone database entry whose ID differs between Windows
// ("E. Africa Standard Time") and Linux ("Africa/Nairobi"), which would silently behave
// differently (or throw) depending on where the app is deployed.
public static class TimeZoneHelper
{
    public static readonly TimeZoneInfo KenyaTimeZone = TimeZoneInfo.CreateCustomTimeZone(
        id: "Kenya Standard Time",
        baseUtcOffset: TimeSpan.FromHours(3),
        displayName: "Kenya Standard Time (EAT)",
        standardDisplayName: "EAT");

    public static DateTime ToKenyaTime(this DateTime utcValue)
    {
        DateTime utc = DateTime.SpecifyKind(utcValue, DateTimeKind.Utc);
        return TimeZoneInfo.ConvertTimeFromUtc(utc, KenyaTimeZone);
    }

    public static DateTime? ToKenyaTime(this DateTime? utcValue)
    {
        return utcValue.HasValue ? utcValue.Value.ToKenyaTime() : null;
    }

    public static DateTime NowInKenya => DateTime.UtcNow.ToKenyaTime();
}
