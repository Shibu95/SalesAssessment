window.callAssessment = {

    _recognition: null,
    _recognitionGeneration: 0,
    _dotNetRef: null,
    _silenceTimer: null,
    _finalTranscript: "",
    _lastInterimTranscript: "",
    _manualStop: false,
    _callEnded: false,
    _micStream: null,
    _mediaRecorder: null,
    _recordedChunks: [],
    _volumeContext: null,
    _volumeSource: null,
    _volumeAnalyser: null,
    _volumeRaf: null,
    _repSpeakingNow: false,
    _inactivityTimer: null,
    _rebuildCount: 0,
    _emptyFinalizeCount: 0,
    _consecutiveRapidFailures: 0,

    // How long a turn can go with zero *recognized* speech (real onresult events,
    // not raw mic volume - see _startVolumeMonitor's poll loop for why volume
    // alone can't reset this) before assuming the pipeline has gone silently deaf
    // and forcing a clean rebuild.
    INACTIVITY_TIMEOUT_MS: 40000,
    MAX_REBUILD_ATTEMPTS: 3,

    // A recognition session that ends within this long of starting counts as a
    // "rapid failure" (failure mode #2 above), not a normal browser-timeout
    // restart. Consecutive rapid failures get an exponential backoff before
    // retrying instead of an immediate retry, and give up after MAX_RAPID_FAILURES.
    RAPID_FAIL_THRESHOLD_MS: 1500,
    MAX_RAPID_FAILURES: 6,
    RAPID_FAIL_BASE_BACKOFF_MS: 500,
    RAPID_FAIL_MAX_BACKOFF_MS: 8000,

    // ------------------------------------------------------------------------
    // Turn lifecycle
    // ------------------------------------------------------------------------

    // isRetry: true when this is an internal same-turn retry (nothing usable was
    // recognized last attempt - see _finalizeTurn) rather than a genuinely new
    // turn starting after the customer's reply. Only genuinely new turns reset
    // _emptyFinalizeCount and _consecutiveRapidFailures - otherwise a string of
    // consecutive failures would never reach their caps and this would retry
    // forever instead of eventually surfacing a clear error.
    startListening: async function (dotNetRef, isRetry) {
        this._callEnded = false;

        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            dotNetRef.invokeMethodAsync("OnMicUnavailable");
            return;
        }

        this._dotNetRef = dotNetRef;
        this._finalTranscript = "";
        this._lastInterimTranscript = "";
        this._manualStop = false;
        this._rebuildCount = 0;
        if (!isRetry) {
            this._emptyFinalizeCount = 0;
            this._consecutiveRapidFailures = 0;
        }
        this._clearSilenceTimer();

        await this._ensureMicStream();

        this._startRecorder();
        this._beginRecognition();
        this._startVolumeMonitor();
        this._armInactivityTimer();
    },

    stopListening: function () {
        this._manualStop = true;
        this._clearSilenceTimer();
        this._clearInactivityTimer();
        this._stopVolumeMonitor();
        // Bump the generation *before* calling stop() so that instance's onstart/
        // onresult/onend - which can still fire asynchronously after this returns,
        // e.g. while the customer's TTS turn is already underway - are all
        // recognized as stale and ignored instead of flipping call state again.
        this._recognitionGeneration++;
        if (this._recognition) {
            this._recognition.stop();
        }
        if (this._mediaRecorder && this._mediaRecorder.state !== "inactive") {
            this._mediaRecorder.stop();
        }
    },

    stopAll: function () {
        this._callEnded = true;
        this.stopListening();
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }
        if (this._micStream) {
            this._micStream.getTracks().forEach(function (track) { track.stop(); });
            this._micStream = null;
        }
    },

    // The mic stream used to be acquired once and trusted for the rest of the
    // call. If the underlying track ever ends or goes stale (OS-level
    // revocation, device change, browser throttling a long-running stream) there
    // was nothing to notice or recover - every later turn's volume monitor and
    // recorder would silently get no audio. Now checked/re-acquired at the start
    // of every turn.
    _ensureMicStream: async function () {
        const track = this._micStream && this._micStream.getAudioTracks()[0];
        if (track && track.readyState === "live") {
            return;
        }

        if (this._micStream) {
            try { this._micStream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) { }
        }
        this._micStream = null;

        if (navigator.mediaDevices) {
            try {
                this._micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
            } catch (e) {
                console.error("Microphone access for recording failed", e);
            }
        }
    },

    // ------------------------------------------------------------------------
    // Inactivity monitor: catches "recognition is running but producing nothing"
    // ------------------------------------------------------------------------
    // Fires if a full turn goes by with no recognized speech (see
    // INACTIVITY_TIMEOUT_MS) - most likely because the engine has gone silently
    // deaf after a restart, with
    // no error ever surfacing to notice it on its own. Rebuilds the whole
    // listening pipeline from scratch rather than trusting whatever state it's
    // currently in. This is a different failure shape than the rapid-restart
    // circuit breaker below: this is "it looks alive but isn't producing
    // anything"; that one is "it can't even stay alive long enough to try".
    _armInactivityTimer: function () {
        this._clearInactivityTimer();

        const self = this;
        this._inactivityTimer = setTimeout(function () {
            if (self._manualStop || self._callEnded) {
                return;
            }

            self._rebuildCount++;

            if (self._rebuildCount > self.MAX_REBUILD_ATTEMPTS) {
                console.warn("callAssessment: no mic activity detected for " + self.INACTIVITY_TIMEOUT_MS + "ms, giving up after " + (self._rebuildCount - 1) + " rebuild attempt(s)");
                self._giveUp();
                return;
            }

            console.warn("callAssessment: no mic activity detected for " + self.INACTIVITY_TIMEOUT_MS + "ms, rebuilding listening pipeline (attempt " + self._rebuildCount + " of " + self.MAX_REBUILD_ATTEMPTS + ")");
            self._rebuildListening();
        }, this.INACTIVITY_TIMEOUT_MS);
    },

    _clearInactivityTimer: function () {
        if (this._inactivityTimer) {
            clearTimeout(this._inactivityTimer);
            this._inactivityTimer = null;
        }
    },

    _rebuildListening: async function () {

        if (this._recognition) {
            try {
                this._recognition.onend = null;
                this._recognition.onresult = null;
                this._recognition.onerror = null;
                this._recognition.stop();
            } catch (e) { }
        }

        await this._ensureMicStream();
        this._beginRecognition();
        this._startVolumeMonitor();
        this._armInactivityTimer();
    },

    // Every self-healing path funnels through here once it's exhausted its
    // retries, so there's exactly one place that decides "this is now a hard
    // failure the rep needs to act on" and exactly one signal (OnMicInactivityFailed)
    // the C# side needs to handle for all of them.
    _giveUp: function () {
        this._clearInactivityTimer();
        this._clearSilenceTimer();
        if (this._dotNetRef) {
            this._dotNetRef.invokeMethodAsync("OnMicInactivityFailed");
        }
    },

    // ------------------------------------------------------------------------
    // Volume monitor - drives the near-instant "Speaking…" UI indicator
    // ------------------------------------------------------------------------
    // The "Speaking…" status used to depend entirely on SpeechDetected, which
    // only fires once the cloud speech-to-text engine returns a recognized
    // result - that round trip has real latency (often several seconds for the
    // first result of a new utterance), even though the mic and recording are
    // already live by then. This polls the raw mic volume instead, which reacts
    // near-instantly, and reuses the same SpeechDetected signal so the C# side
    // needs no changes.
    //
    // It only ever flips the UI on early. It deliberately does NOT reset the
    // silence timer (that stays tied to real recognized speech in onresult) or
    // the inactivity timer (see the comment inside the poll loop for why -
    // resetting it on volume alone is what let a real failure hide behind a UI
    // that looked like it was working).
    _startVolumeMonitor: function () {
        this._stopVolumeMonitor();

        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!this._micStream || !AudioCtx) {
            return;
        }

        try {
            this._volumeContext = new AudioCtx();
            this._volumeSource = this._volumeContext.createMediaStreamSource(this._micStream);
            this._volumeAnalyser = this._volumeContext.createAnalyser();
            this._volumeAnalyser.fftSize = 512;
            this._volumeSource.connect(this._volumeAnalyser);

            if (this._volumeContext.state === "suspended") {
                this._volumeContext.resume().catch(function () { });
            }
        } catch (e) {
            console.error("Volume monitor setup failed", e);
            this._stopVolumeMonitor();
            return;
        }

        const data = new Uint8Array(this._volumeAnalyser.frequencyBinCount);
        const self = this;
        const VOLUME_THRESHOLD = 12;

        (function poll() {
            if (!self._volumeAnalyser) {
                return;
            }

            self._volumeAnalyser.getByteFrequencyData(data);

            let sum = 0;
            for (let i = 0; i < data.length; i++) {
                sum += data[i];
            }
            const average = sum / data.length;

            if (average > VOLUME_THRESHOLD) {
                // Deliberately NOT touching the inactivity timer here - raw mic volume
                // only proves something audible is happening near the mic, it says nothing
                // about whether SpeechRecognition is actually transcribing it. Resetting
                // it on volume too would let ambient noise or the rep's own
                // voice mask a real recognition failure forever, which is exactly what
                // happened before this was fixed: the UI showed "Speaking..." (driven by
                // this volume signal) while recognition.onresult never fired even once.
                if (!self._repSpeakingNow) {
                    self._repSpeakingNow = true;
                    if (self._dotNetRef) {
                        self._dotNetRef.invokeMethodAsync("SpeechDetected");
                    }
                }
            } else {
                self._repSpeakingNow = false;
            }

            self._volumeRaf = requestAnimationFrame(poll);
        })();
    },

    _stopVolumeMonitor: function () {
        if (this._volumeRaf) {
            cancelAnimationFrame(this._volumeRaf);
            this._volumeRaf = null;
        }
        if (this._volumeSource) {
            try { this._volumeSource.disconnect(); } catch (e) { }
            this._volumeSource = null;
        }
        this._volumeAnalyser = null;
        if (this._volumeContext) {
            try { this._volumeContext.close(); } catch (e) { }
            this._volumeContext = null;
        }
        this._repSpeakingNow = false;
    },

    // ------------------------------------------------------------------------
    // Call recording (best-effort - never blocks or breaks the live turn)
    // ------------------------------------------------------------------------
    _startRecorder: function () {
        this._mediaRecorder = null;

        if (!this._micStream || typeof MediaRecorder === "undefined") {
            return;
        }

        try {
            this._recordedChunks = [];
            const recorder = new MediaRecorder(this._micStream);
            const self = this;

            recorder.ondataavailable = function (event) {
                if (event.data && event.data.size > 0) {
                    self._recordedChunks.push(event.data);
                }
            };

            recorder.start();
            this._mediaRecorder = recorder;
        } catch (e) {
            console.error("MediaRecorder start failed", e);
            this._mediaRecorder = null;
        }
    },

    _stopRecorderAndGetBlob: function () {
        const self = this;

        return new Promise(function (resolve) {
            if (!self._mediaRecorder || self._mediaRecorder.state === "inactive") {
                resolve(null);
                return;
            }

            self._mediaRecorder.onstop = function () {
                const blob = self._recordedChunks.length > 0
                    ? new Blob(self._recordedChunks, { type: "audio/webm" })
                    : null;
                resolve(blob);
            };

            self._mediaRecorder.stop();
        });
    },

    // ------------------------------------------------------------------------
    // Speech recognition engine
    // ------------------------------------------------------------------------
    _beginRecognition: function () {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        const self = this;
        const attemptStartedAt = Date.now();

        // Every instance created here supersedes whatever came before it - bumping
        // the generation counter and having each handler check it's still current
        // (see the module comment, failure mode #4) means a stale instance from an
        // old rebuild/retry/turn can never act on the live state again, even if the
        // browser still delivers one of its events after the fact.
        const myGeneration = ++this._recognitionGeneration;

        recognition.lang = "en-US";
        recognition.interimResults = true;
        recognition.continuous = true;

        recognition.onstart = function () {
            if (myGeneration !== self._recognitionGeneration) {
                return;
            }
            self._dotNetRef.invokeMethodAsync("ListeningStarted");
        };

        recognition.onresult = function (event) {
            if (myGeneration !== self._recognitionGeneration) {
                return;
            }

            let sawFinal = false;

            for (let i = event.resultIndex; i < event.results.length; i++) {
                const chunk = event.results[i][0].transcript.trim();

                if (event.results[i].isFinal) {
                    sawFinal = true;
                    if (chunk) {
                        self._finalTranscript = (self._finalTranscript + " " + chunk).trim();
                    }
                } else if (chunk) {
                    // Tracked separately from _finalTranscript so _finalizeTurn has
                    // something to fall back on if the recognizer keeps producing
                    // interim results but never promotes any of them to final for
                    // this whole turn - see the comment there for why that matters.
                    self._lastInterimTranscript = chunk;
                }
            }

            // A real result is the strongest possible evidence the pipeline is
            // healthy - clear both failure counters, not just the inactivity timer.
            self._consecutiveRapidFailures = 0;
            self._dotNetRef.invokeMethodAsync("SpeechDetected");
            self._resetSilenceTimer();
            self._armInactivityTimer();
        };

        recognition.onerror = function (event) {
            if (myGeneration !== self._recognitionGeneration) {
                return;
            }

            if (event.error === "not-allowed" || event.error === "service-not-allowed") {
                self._manualStop = true;
                self._clearSilenceTimer();
                self._clearInactivityTimer();
                self._dotNetRef.invokeMethodAsync("OnMicPermissionDenied");
            }
            // Other errors (e.g. "no-speech") are recoverable via the onend restart
            // below, which now backs off if they keep recurring rapidly.
        };

        recognition.onend = function () {
            if (myGeneration !== self._recognitionGeneration) {
                return;
            }

            const sessionDurationMs = Date.now() - attemptStartedAt;

            self._dotNetRef.invokeMethodAsync("ListeningEnded");

            if (self._manualStop) {
                return;
            }

            self._restartAfterUnexpectedEnd(sessionDurationMs);
        };

        this._recognition = recognition;

        try {
            recognition.start();
        } catch (e) {
            // Should be unreachable in normal operation (onend never double-starts,
            // and every restart path here goes through the same backoff logic), but
            // this is the backstop: if start() ever throws for any reason, treat it
            // exactly like an instant onend rather than leaving a half-started
            // recognizer sitting there silently.
            console.error("SpeechRecognition.start() failed", e);
            if (myGeneration === self._recognitionGeneration) {
                self._restartAfterUnexpectedEnd(0);
            }
        }
    },

    // Single decision point for "the browser ended recognition on its own or
    // start() itself failed - what now?" A session that ran for a healthy while
    // (>= RAPID_FAIL_THRESHOLD_MS) before ending is treated as the normal,
    // expected case (continuous recognition is commonly time-limited) and
    // restarts immediately. A session that ended almost as soon as it began is
    // treated as a real failure: back off exponentially before retrying, and
    // give up with a clear error after MAX_RAPID_FAILURES in a row, instead of
    // spinning in a tight zero-delay loop forever - which is what used to pin
    // the CPU and spam the SignalR circuit with thousands of ListeningStarted/
    // ListeningEnded calls per second while never giving a real session a chance
    // to actually hear anything.
    _restartAfterUnexpectedEnd: function (sessionDurationMs) {
        if (this._callEnded) {
            return;
        }

        const self = this;

        if (sessionDurationMs >= this.RAPID_FAIL_THRESHOLD_MS) {
            this._consecutiveRapidFailures = 0;
            this._beginRecognition();
            return;
        }

        this._consecutiveRapidFailures++;

        if (this._consecutiveRapidFailures > this.MAX_RAPID_FAILURES) {
            console.error("callAssessment: recognition failed to stay active " + (this._consecutiveRapidFailures - 1) + " times in a row (each under " + this.RAPID_FAIL_THRESHOLD_MS + "ms), giving up");
            this._giveUp();
            return;
        }

        const delay = Math.min(
            this.RAPID_FAIL_BASE_BACKOFF_MS * Math.pow(2, this._consecutiveRapidFailures - 1),
            this.RAPID_FAIL_MAX_BACKOFF_MS);

        console.warn("callAssessment: recognition ended after only " + sessionDurationMs + "ms (attempt " + this._consecutiveRapidFailures + " of " + this.MAX_RAPID_FAILURES + "), retrying in " + delay + "ms");

        setTimeout(function () {
            if (!self._manualStop && !self._callEnded) {
                self._beginRecognition();
            }
        }, delay);
    },

    // ------------------------------------------------------------------------
    // Silence detection -> turn finalization
    // ------------------------------------------------------------------------
    _resetSilenceTimer: function () {
        this._clearSilenceTimer();

        const self = this;
        this._silenceTimer = setTimeout(function () {
            self._finalizeTurn();
        }, 2000);
    },

    _clearSilenceTimer: function () {
        if (this._silenceTimer) {
            clearTimeout(this._silenceTimer);
            this._silenceTimer = null;
        }
    },

    _finalizeTurn: function () {
        this._manualStop = true;
        this._clearInactivityTimer();
        this._stopVolumeMonitor();

        // Same reasoning as stopListening(): invalidate this instance's generation
        // before stopping it so a late onresult/onend can't act on state that's
        // already moved on to finalizing the turn.
        this._recognitionGeneration++;
        if (this._recognition) {
            this._recognition.stop();
        }

        // Falls back to the last interim (non-final) chunk if recognition never
        // promoted anything to a final result this turn - see the module comment
        // at the top of this file for why that matters.
        const transcript = (this._finalTranscript.trim() || this._lastInterimTranscript.trim());
        this._finalTranscript = "";
        this._lastInterimTranscript = "";
        const self = this;

        this._stopRecorderAndGetBlob().then(function (blob) {
            if (!transcript) {
                self._emptyFinalizeCount++;
                console.warn("callAssessment: turn ended with no usable transcript at all (attempt " + self._emptyFinalizeCount + " of " + self.MAX_REBUILD_ATTEMPTS + ")");

                if (self._emptyFinalizeCount > self.MAX_REBUILD_ATTEMPTS) {
                    self._giveUp();
                    return;
                }

                self.startListening(self._dotNetRef, true);
                return;
            }

            self._emptyFinalizeCount = 0;

            if (blob && blob.size > 0) {
                blob.arrayBuffer().then(function (buffer) {
                    const streamRef = DotNet.createJSStreamReference(buffer);
                    self._dotNetRef.invokeMethodAsync("ReceiveTranscript", transcript, streamRef);
                });
            } else {
                self._dotNetRef.invokeMethodAsync("ReceiveTranscript", transcript, null);
            }
        });
    }
};

window.callSpeechSynthesis = {

    speak: function (text, dotNetRef) {

        if (!text) {
            return;
        }

        window.callAssessment.stopListening();

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = "en-US";

        utterance.onstart = function () {
            dotNetRef.invokeMethodAsync("CustomerSpeakingStarted");
        };

        utterance.onend = function () {
            dotNetRef.invokeMethodAsync("CustomerSpeakingEnded");

            if (!window.callAssessment._callEnded) {
                window.callAssessment.startListening(dotNetRef);
            }
        };

        speechSynthesis.speak(utterance);
    }
};

// Independent playback helpers used by the Trainer/Admin Dashboard to listen
// back to a completed call. Deliberately separate from callAssessment /
// callSpeechSynthesis so reviewing a past call never touches live-call state.
window.audioPlayback = {
    _currentAudio: null,
    _currentResolve: null,

    playClip: function (url) {
        const self = this;
        return new Promise(function (resolve) {
            const audio = new Audio(url);
            self._currentAudio = audio;
            self._currentResolve = resolve;
            audio.onended = function () { self._clearCurrent(); resolve(); };
            audio.onerror = function () { self._clearCurrent(); resolve(); };
            audio.play().catch(function () { self._clearCurrent(); resolve(); });
        });
    },

    speak: function (text) {
        const self = this;
        return new Promise(function (resolve) {
            if (!text) {
                resolve();
                return;
            }

            self._currentResolve = resolve;
            const utterance = new SpeechSynthesisUtterance(text);
            utterance.lang = "en-US";
            utterance.onend = function () { self._clearCurrent(); resolve(); };
            utterance.onerror = function () { self._clearCurrent(); resolve(); };
            speechSynthesis.speak(utterance);
        });
    },

    // Lets a caller (e.g. closing the transcript dialog mid-playback) unblock whatever
    // C# await is currently waiting on playClip/speak, instead of leaving audio playing
    // silently in the background with nothing on screen still tracking it.
    stopAll: function () {
        if (window.speechSynthesis) {
            window.speechSynthesis.cancel();
        }

        if (this._currentAudio) {
            this._currentAudio.pause();
        }

        if (this._currentResolve) {
            const resolve = this._currentResolve;
            this._clearCurrent();
            resolve();
        }
    },

    // Real pause/resume (not stop) - the currently playing clip or synthesized line stays
    // queued and continues from where it left off, it doesn't restart or move to the next line.
    pause: function () {
        if (window.speechSynthesis && window.speechSynthesis.speaking) {
            window.speechSynthesis.pause();
        }

        if (this._currentAudio && !this._currentAudio.paused) {
            this._currentAudio.pause();
        }
    },

    resume: function () {
        if (window.speechSynthesis && window.speechSynthesis.paused) {
            window.speechSynthesis.resume();
        }

        if (this._currentAudio && this._currentAudio.paused) {
            this._currentAudio.play();
        }
    },

    _clearCurrent: function () {
        this._currentAudio = null;
        this._currentResolve = null;
    },

    scrollToMessage: function (elementId) {
        const el = document.getElementById(elementId);
        if (el) {
            el.scrollIntoView({ behavior: "smooth", block: "center" });
        }
    }
};
