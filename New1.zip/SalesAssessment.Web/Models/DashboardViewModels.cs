using System;

namespace SalesAssessment.Web.Models;

public class DashboardSummaryViewModel
{
    public int TotalSalesReps { get; set; }
    public int AssignedThisMonth { get; set; }
    public int ActiveBatches { get; set; }
    public decimal CompletionRatePercent { get; set; }
    public decimal? AverageScorePercent { get; set; }

    public int NewSalesRepsThisMonth { get; set; }
    public int AssignedLastMonth { get; set; }
    public decimal? AverageScoreLastMonth { get; set; }
}

// One point on the completions trend. Named by period rather than by week because
// the chart now plots one point per day; the shape is otherwise identical, so the
// bucket size is the service's decision rather than something baked into the model.
public class DashboardTrendPointViewModel
{
    public DateTime PeriodStart { get; set; }
    public int CompletedCount { get; set; }
    public decimal? AverageScore { get; set; }

    // "Tue 05" - weekday plus date. A bare date reads ambiguously on a 7-point axis,
    // where the day of the week is the thing that makes a dip or spike meaningful.
    public string PeriodLabel => PeriodStart.ToString("ddd dd");
}

public class DashboardPendingBreakdownViewModel
{
    public int InProgress { get; set; }
    public int NotStarted { get; set; }

    public int Total => InProgress + NotStarted;
}

public class DashboardPendingSliceViewModel
{
    public string Label { get; set; } = string.Empty;
    public int Value { get; set; }
    public string Color { get; set; } = string.Empty;
}

public class ScoreDistributionViewModel
{
    public int Excellent { get; set; }
    public int Good { get; set; }
    public int NeedsImprovement { get; set; }

    public int Total => Excellent + Good + NeedsImprovement;

    public decimal ExcellentPercent => Total == 0 ? 0 : Math.Round(Excellent * 100m / Total, 1);
    public decimal GoodPercent => Total == 0 ? 0 : Math.Round(Good * 100m / Total, 1);
    public decimal NeedsImprovementPercent => Total == 0 ? 0 : Math.Round(NeedsImprovement * 100m / Total, 1);
}

public class CoachingThemeItemViewModel
{
    public string Text { get; set; } = string.Empty;
    public int Count { get; set; }
}

public class CoachingThemesViewModel
{
    public List<CoachingThemeItemViewModel> TopStrengths { get; set; } = [];
    public List<CoachingThemeItemViewModel> TopDevelopmentAreas { get; set; } = [];
}

public class BatchPerformanceViewModel
{
    public int BatchID { get; set; }
    public string BatchName { get; set; } = string.Empty;
    public string StatusName { get; set; } = "-";
    public int ParticipantCount { get; set; }
    public int TotalAssignments { get; set; }
    public int CompletedAssignments { get; set; }
    public decimal? AverageScore { get; set; }
    public DateTime StartDate { get; set; }

    public decimal CompletionPercent => TotalAssignments == 0 ? 0 : Math.Round(CompletedAssignments * 100m / TotalAssignments, 1);
}

public class RecentAssessmentViewModel
{
    public int ScenarioAssignmentID { get; set; }
    public int SalesRepID { get; set; }
    public string SalesRepEmail { get; set; } = string.Empty;
    public string ScenarioTitle { get; set; } = string.Empty;
    public int? BatchID { get; set; }
    public string BatchName { get; set; } = string.Empty;
    public DateTime AssignedOn { get; set; }
    public DateTime? CompletedOn { get; set; }
    public string Status { get; set; } = "Not Started";
    public decimal? OverallScore { get; set; }
    public int? AttemptID { get; set; }
    public int? AssessmentResultID { get; set; }
}
