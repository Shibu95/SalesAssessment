using System.Net.Http.Json;
using System.Text.Json;
using SalesAssessment.Web.Interfaces;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public sealed class EvaluationAgentService : IEvaluationAgentService
{
    private readonly HttpClient _httpClient;
    private readonly IConfiguration _configuration;
    public EvaluationAgentService(HttpClient httpClient, IConfiguration configuration)
    {
        _httpClient = httpClient;
        _configuration = configuration;
    }

    public async Task<EvaluationReport> AnalyzeTranscriptAsync(string transcript)
    {
        string conversationId = await CreateConversationAsync();
        string prompt =
$$"""
Role Mapping

Sales Rep:
The trainee being evaluated.

Customer:
The prospect/customer.

Evaluate ONLY the Sales Rep.

Return ONLY valid JSON.

{"overallScore": 0,
  "performanceLevel": "",
  "overallSummary": "",
  "competencies": [],
  "keyStrengths": [],
  "developmentAreas": [],
  "coachingRecommendations": [],
  "overallReadiness": ""
}

Conversation:

{{transcript}}
""";

        string json = await SendMessageAsync(conversationId, prompt);
        json = CleanJson(json);

        try
        {
            return JsonSerializer.Deserialize<
                EvaluationReport>(
                    json,
                    new JsonSerializerOptions
                    {
                        PropertyNameCaseInsensitive = true
                    })
                ?? new EvaluationReport();
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Evaluation Parsing Error: {ex}");
            Console.WriteLine(json);
            return new EvaluationReport
            {
                OverallSummary = "Evaluation parsing failed."
            };
        }
    }

    private async Task<string> CreateConversationAsync()
    {
        string apiKey = _configuration["BoldAgent:ApiKey"]!;
        string agentId = _configuration["BoldAgent:EvaluationAgentId"]!;
        string endpoint = $"https://syncfusion.boldagent.ai/developer-api/v1/agents/{agentId}/conversations";

        HttpRequestMessage request = new(HttpMethod.Post, endpoint);

        request.Headers.Add("X-Api-Key", apiKey);

        request.Content = JsonContent.Create(new { });

        HttpResponseMessage response = await _httpClient.SendAsync(request);

        response.EnsureSuccessStatusCode();

        CreateConversationResponse? result = await response.Content.ReadFromJsonAsync<CreateConversationResponse>();

        return result?.Id ?? string.Empty;
    }

    private async Task<string> SendMessageAsync(string conversationId, string message)
    {
        string apiKey = _configuration["BoldAgent:ApiKey"]!;

        string agentId = _configuration["BoldAgent:EvaluationAgentId"]!;

        string endpoint = $"https://syncfusion.boldagent.ai/developer-api/v1/agents/{agentId}/conversations/{conversationId}/messages";

        HttpRequestMessage request = new(HttpMethod.Post, endpoint);

        request.Headers.Add("X-Api-Key", apiKey);

        request.Content = JsonContent.Create(
                new BoldAgentMessageRequest
                {
                    Content = message
                });

        HttpResponseMessage response = await _httpClient.SendAsync(request);

        string responseText = await response.Content.ReadAsStringAsync();

        Console.WriteLine($"Evaluator Response: {responseText}");

        response.EnsureSuccessStatusCode();

        SendMessageResponse? result =
            JsonSerializer.Deserialize<SendMessageResponse>(responseText, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        return result?.Message?.Content ?? result?.Message?.TextContent ?? "{}";
    }

    private static string CleanJson(string json)
    {
        if (string.IsNullOrWhiteSpace(json))
        {
            return "{}";
        }

        json = json.Trim();

        if (json.StartsWith("```json"))
        {
            json = json.Replace("```json", "");
        }

        if (json.StartsWith("```"))
        {
            json = json.Replace("```", "");
        }

        if (json.EndsWith("```"))
        {
            int index =
                json.LastIndexOf("```");

            if (index >= 0)
            {
                json = json[..index];
            }
        }

        return json.Trim();
    }
}