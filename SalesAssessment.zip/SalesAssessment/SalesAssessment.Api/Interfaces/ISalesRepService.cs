using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Interfaces;

public interface ISalesRepService
{
    Task<List<SalesRep>> GetAllAsync();

    Task<SalesRep?> GetByIdAsync(int salesRepId);

    Task<SalesRep> CreateAsync(SalesRep salesRep);

    Task<bool> DeleteAsync(int salesRepId);
}