using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Interfaces;

public interface IBatchService
{
    Task<List<Batch>> GetAllAsync();

    Task<Batch?> GetByIdAsync(int batchId);

    Task<Batch> CreateAsync(Batch batch);

    Task<Batch> UpdateAsync(Batch batch);

    Task<bool> DeleteAsync(int batchId);
    Task<List<Batch>> GetStartedBatchesAsync();
}