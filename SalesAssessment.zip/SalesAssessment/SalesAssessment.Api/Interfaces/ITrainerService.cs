using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Interfaces;

public interface ITrainerService
{
    Task<List<Trainer>> GetAllAsync();

    Task<Trainer?> GetByIdAsync(int trainerId);

    Task<Trainer> CreateAsync(Trainer trainer);

    Task<bool> DeleteAsync(int trainerId);
}