using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Interfaces;

public interface IRoleService
{
    Task<List<Role>> GetAllAsync();

    Task<Role?> GetByIdAsync(int roleId);

    Task<Role> CreateAsync(Role role);

    Task<Role> UpdateAsync(Role role);

    Task<bool> DeleteAsync(int roleId);
}