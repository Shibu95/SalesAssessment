using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Interfaces;

public interface IScenarioService
{
    Task<List<Scenario>> GetAllAsync();

    Task<Scenario?> GetByIdAsync(int scenarioId);

    Task<Scenario> CreateAsync(Scenario scenario);

    Task<Scenario> UpdateAsync(Scenario scenario);

    Task<bool> DeleteAsync(int scenarioId);
}