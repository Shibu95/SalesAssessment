using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Interfaces;

public interface IScenarioAssignmentService
{
    Task<List<ScenarioAssignment>> GetAllAsync();

    Task<List<ScenarioAssignment>> GetBySalesRepAsync(int salesRepId);

    Task<ScenarioAssignment> CreateAsync(ScenarioAssignment assignment);
}