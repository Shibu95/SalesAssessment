using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Interfaces;

public interface ITestQuestionService
{
    Task<List<TestQuestion>> GetByTestIdAsync(int testId);

    Task<TestQuestion> CreateAsync(TestQuestion testQuestion);

    Task<bool> DeleteAsync(int testQuestionId);
}