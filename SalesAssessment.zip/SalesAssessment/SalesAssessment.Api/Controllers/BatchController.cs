using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BatchController : ControllerBase
{
    private readonly IBatchService _batchService;
    private readonly ISalesRepService _salesRepService;
    private readonly SalesAssessmentDbContext _context;

    public BatchController(IBatchService batchService, ISalesRepService salesRepService, SalesAssessmentDbContext context)
    {
        _batchService = batchService;
        _salesRepService = salesRepService;
        _context = context;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _batchService.GetAllAsync());
    }

    [HttpGet("{batchId:int}")]
    public async Task<IActionResult> GetById(int batchId)
    {
        Batch? batch = await _batchService.GetByIdAsync(batchId);
        if (batch is null)
        {
            return NotFound();
        }
        return Ok(batch);
    }

    [HttpGet("{batchId:int}/trainers")]
    public async Task<IActionResult> GetTrainersByBatch(int batchId)
    {
        var trainers = await _context.BatchTrainers.Where(bt => bt.BatchID == batchId).Select(bt => bt.TrainerID).ToListAsync();
        return Ok(trainers);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Batch batch)
    {
        return Ok(await _batchService.CreateAsync(batch));
    }

    [HttpPut]
    public async Task<IActionResult> Update(Batch batch)
    {
        return Ok(await _batchService.UpdateAsync(batch));
    }

    [HttpDelete("{batchId:int}")]
    public async Task<IActionResult> Delete(int batchId)
    {
        bool deleted = await _batchService.DeleteAsync(batchId);

        if (!deleted)
        {
            return NotFound();
        }
        return NoContent();
    }

    [HttpPost("assign-trainers")]
    public async Task<IActionResult> AssignTrainers([FromBody] AssignTrainersRequest request)
    {
        if (request?.TrainerIds == null || request.TrainerIds.Count == 0)
        {
            return BadRequest("No trainer IDs provided");
        }
        // Verify batch exists
        Batch? batch = await _batchService.GetByIdAsync(request.BatchId);
        if (batch is null)
        {
            return NotFound($"Batch with ID {request.BatchId} not found");
        }

        try
        {
            // Delete existing batch trainer assignments
            var existingAssignments = _context.BatchTrainers.Where(bt => bt.BatchID == request.BatchId).ToList();

            _context.BatchTrainers.RemoveRange(existingAssignments);
            await _context.SaveChangesAsync();

            // Create new batch trainer assignments
            foreach (var trainerId in request.TrainerIds)
            {
                var batchTrainer = new BatchTrainer
                {
                    BatchID = request.BatchId,
                    TrainerID = trainerId
                };
                _context.BatchTrainers.Add(batchTrainer);
            }

            await _context.SaveChangesAsync();
            return Ok(new { success = true, message = $"Successfully assigned {request.TrainerIds.Count} trainers to batch" });
        }
        catch (Exception ex)
        {
            return BadRequest($"Error assigning trainers: {ex.Message}");
        }
    }

    [HttpPost("upload-sales-reps")]
    public async Task<IActionResult> UploadSalesReps([FromBody] UploadSalesRepsRequest request)
    {
        if (request?.EmailIds == null || request.EmailIds.Count == 0)
        {
            return BadRequest("No email IDs provided");
        }

        // Verify batch exists
        Batch? batch = await _batchService.GetByIdAsync(request.BatchId);
        if (batch is null)
        {
            return NotFound($"Batch with ID {request.BatchId} not found");
        }

        try
        {
            // Create SalesRep entries for each email
            foreach (var email in request.EmailIds)
            {
                if (string.IsNullOrWhiteSpace(email))
                    continue;

                // Check if SalesRep with this email already exists for this batch
                var existingSalesRep = await _salesRepService.GetAllAsync();
                if (existingSalesRep.Any(sr => sr.EmailID.Equals(email, StringComparison.OrdinalIgnoreCase) && sr.BatchID == request.BatchId))
                {
                    continue; // Skip duplicates
                }

                var salesRep = new SalesRep
                {
                    EmailID = email.Trim(),
                    BatchID = request.BatchId,
                    CreatedOn = DateTime.UtcNow
                };

                await _salesRepService.CreateAsync(salesRep);
            }

            return Ok(new { success = true, message = $"Successfully created {request.EmailIds.Count} sales rep entries" });
        }
        catch (Exception ex)
        {
            return BadRequest($"Error creating sales reps: {ex.Message}");
        }
    }

    [HttpGet("started")]
    public async Task<IActionResult> GetStartedBatches()
    {
        return Ok(await _batchService.GetStartedBatchesAsync());
    }
}



public class AssignTrainersRequest
{
    public int BatchId { get; set; }
    public List<int> TrainerIds { get; set; } = new();
}

public class UploadSalesRepsRequest
{
    public int BatchId { get; set; }
    public List<string> EmailIds { get; set; } = new();
}