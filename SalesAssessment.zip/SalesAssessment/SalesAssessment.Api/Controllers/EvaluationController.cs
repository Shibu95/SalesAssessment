using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Api.Controllers
{
    public class EvaluationController
    {
        
    }
}