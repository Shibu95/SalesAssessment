using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class GoalController : ControllerBase
    {
        private readonly SalesAssessmentDbContext _context;

        public GoalController(SalesAssessmentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.Goals.OrderBy(x => x.GoalName).ToListAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            Goal? goal = await _context.Goals.FirstOrDefaultAsync(x => x.GoalID == id);

            if (goal is null)
            {
                return NotFound();
            }

            return Ok(goal);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Goal goal)
        {
            _context.Goals.Add(goal);

            await _context.SaveChangesAsync();

            return Ok(goal);
        }

        [HttpPut]
        public async Task<IActionResult> Update(Goal goal)
        {
            _context.Goals.Update(goal);

            await _context.SaveChangesAsync();

            return Ok(goal);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            Goal? goal = await _context.Goals.FindAsync(id);

            if (goal is null)
            {
                return NotFound();
            }

            _context.Goals.Remove(goal);

            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}