using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AssessmentTypeController : ControllerBase
    {
        private readonly SalesAssessmentDbContext _context;

        public AssessmentTypeController(SalesAssessmentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.AssessmentTypes.OrderBy(x => x.AssessmentTypeName).ToListAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            AssessmentType? assessmentType = await _context.AssessmentTypes.FirstOrDefaultAsync(x => x.AssessmentTypeID == id);

            if (assessmentType is null)
            {
                return NotFound();
            }

            return Ok(assessmentType);
        }

        [HttpPost]
        public async Task<IActionResult> Create(AssessmentType assessmentType)
        {
            _context.AssessmentTypes.Add(assessmentType);
            await _context.SaveChangesAsync();
            return Ok(assessmentType);
        }

        [HttpPut]
        public async Task<IActionResult> Update(AssessmentType assessmentType)
        {
            _context.AssessmentTypes.Update(assessmentType);
            await _context.SaveChangesAsync();
            return Ok(assessmentType);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            AssessmentType? assessmentType = await _context.AssessmentTypes.FindAsync(id);

            if (assessmentType is null)
            {
                return NotFound();
            }

            _context.AssessmentTypes.Remove(assessmentType);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}