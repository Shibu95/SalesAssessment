using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SalesRepController : ControllerBase
{
    private readonly ISalesRepService _salesRepService;

    public SalesRepController(ISalesRepService salesRepService)
    {
        _salesRepService = salesRepService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _salesRepService.GetAllAsync());
    }

    [HttpGet("{salesRepId:int}")]
    public async Task<IActionResult> GetById(int salesRepId)
    {
        SalesRep? salesRep = await _salesRepService.GetByIdAsync(salesRepId);

        if (salesRep is null)
        {
            return NotFound();
        }

        return Ok(salesRep);
    }

    [HttpPost]
    public async Task<IActionResult> Create(SalesRep salesRep)
    {
        SalesRep result = await _salesRepService.CreateAsync(salesRep);
        return Ok(result);
    }

    [HttpDelete("{salesRepId:int}")]
    public async Task<IActionResult> Delete(int salesRepId)
    {
        bool deleted = await _salesRepService.DeleteAsync(salesRepId);

        if (!deleted)
        {
            return NotFound();
        }

        return NoContent();
    }
}