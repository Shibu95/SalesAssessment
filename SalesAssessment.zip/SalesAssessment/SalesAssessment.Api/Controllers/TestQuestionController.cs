using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TestQuestionController : ControllerBase
{
    private readonly ITestQuestionService _service;

    public TestQuestionController(ITestQuestionService service)
    {
        _service = service;
    }

    [HttpGet("{testId:int}")]
    public async Task<IActionResult> GetByTestId(int testId)
    {
        return Ok(await _service.GetByTestIdAsync(testId));
    }

    [HttpPost]
    public async Task<IActionResult> Create(TestQuestion testQuestion)
    {
        return Ok(await _service.CreateAsync(testQuestion));
    }

    [HttpDelete("{testQuestionId:int}")]
    public async Task<IActionResult> Delete(int testQuestionId)
    {
        bool deleted = await _service.DeleteAsync(testQuestionId);

        if (!deleted)
        {
            return NotFound();
        }
        return NoContent();
    }
}
