using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TestController : ControllerBase
{
    private readonly ITestService _service;

    public TestController(ITestService service)
    {
        _service = service;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _service.GetAllAsync());
    }

    [HttpGet("{testId:int}")]
    public async Task<IActionResult> GetById(int testId)
    {
        Test? test = await _service.GetByIdAsync(testId);

        if (test is null)
        {
            return NotFound();
        }
        return Ok(test);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Test test)
    {
        try
        {
            Test result = await _service.CreateAsync(test);

            return Ok(result);
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.ToString());

            throw;
        }
    }

    [HttpPut]
    public async Task<IActionResult> Update(Test test)
    {
        return Ok(await _service.UpdateAsync(test));
    }

    [HttpDelete("{testId:int}")]
    public async Task<IActionResult> Delete(int testId)
    {
        bool deleted = await _service.DeleteAsync(testId);

        if (!deleted)
        {
            return NotFound();
        }
        return NoContent();
    }
}