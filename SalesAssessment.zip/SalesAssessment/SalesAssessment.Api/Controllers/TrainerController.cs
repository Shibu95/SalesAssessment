using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TrainerController : ControllerBase
{
    private readonly ITrainerService _trainerService;

    public TrainerController(ITrainerService trainerService)
    {
        _trainerService = trainerService;
    }

    [HttpGet]
    public async Task<IActionResult> GetAll()
    {
        return Ok(await _trainerService.GetAllAsync());
    }

    [HttpGet("{trainerId:int}")]
    public async Task<IActionResult> GetById(int trainerId)
    {
        Trainer? trainer = await _trainerService.GetByIdAsync(trainerId);

        if (trainer is null)
        {
            return NotFound();
        }

        return Ok(trainer);
    }

    [HttpPost]
    public async Task<IActionResult> Create(Trainer trainer)
    {
        Trainer result = await _trainerService.CreateAsync(trainer);
        return Ok(result);
    }

    [HttpDelete("{trainerId:int}")]
    public async Task<IActionResult> Delete(int trainerId)
    {
        bool deleted = await _trainerService.DeleteAsync(trainerId);

        if (!deleted)
        {
            return NotFound();
        }

        return NoContent();
    }
}