using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Api.Entities;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Api.Data;
using Microsoft.EntityFrameworkCore;

namespace SalesAssessment.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AssessmentStatusController : ControllerBase
    {
        private readonly SalesAssessmentDbContext _context;

        public AssessmentStatusController(SalesAssessmentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.AssessmentStatuses.OrderBy(x => x.AssessmentStatusName).ToListAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            AssessmentStatus? assessmentStatus = await _context.AssessmentStatuses.FirstOrDefaultAsync(x => x.AssessmentStatusID == id);

            if (assessmentStatus is null)
            {
                return NotFound();
            }

            return Ok(assessmentStatus);
        }

        [HttpPost]
        public async Task<IActionResult> Create(AssessmentStatus assessmentStatus)
        {
            _context.AssessmentStatuses.Add(assessmentStatus);
            await _context.SaveChangesAsync();
            return Ok(assessmentStatus);
        }

        [HttpPut]
        public async Task<IActionResult> Update(AssessmentStatus assessmentStatus)
        {
            _context.AssessmentStatuses.Update(assessmentStatus);
            await _context.SaveChangesAsync();
            return Ok(assessmentStatus);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            AssessmentStatus? assessmentStatus = await _context.AssessmentStatuses.FindAsync(id);

            if (assessmentStatus is null)
            {
                return NotFound();
            }

            _context.AssessmentStatuses.Remove(assessmentStatus);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}