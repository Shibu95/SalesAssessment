using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Api.Entities;
using Microsoft.AspNetCore.Mvc;
using SalesAssessment.Api.Data;
using Microsoft.EntityFrameworkCore;

namespace SalesAssessment.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class IndustryController : ControllerBase
    {
        private readonly SalesAssessmentDbContext _context;

        public IndustryController(SalesAssessmentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.Industries.OrderBy(x => x.IndustryName).ToListAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            Industry? industry = await _context.Industries.FirstOrDefaultAsync(x => x.IndustryID == id);

            if (industry is null)
            {
                return NotFound();
            }

            return Ok(industry);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Industry industry)
        {
            _context.Industries.Add(industry);
            await _context.SaveChangesAsync();
            return Ok(industry);
        }

        [HttpPut]
        public async Task<IActionResult> Update(Industry industry)
        {
            _context.Industries.Update(industry);
            await _context.SaveChangesAsync();
            return Ok(industry);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            Industry? industry = await _context.Industries.FindAsync(id);

            if (industry is null)
            {
                return NotFound();
            }

            _context.Industries.Remove(industry);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }
}