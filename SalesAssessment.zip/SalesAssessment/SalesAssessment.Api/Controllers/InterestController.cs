using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class InterestController : ControllerBase
    {
        private readonly SalesAssessmentDbContext _context;

        public InterestController(SalesAssessmentDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            return Ok(await _context.Interests.OrderBy(x => x.InterestName).ToListAsync());
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetById(int id)
        {
            Interest? interest = await _context.Interests.FirstOrDefaultAsync(x => x.InterestID == id);

            if (interest is null)
            {
                return NotFound();
            }

            return Ok(interest);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Interest interest)
        {
            _context.Interests.Add(interest);

            await _context.SaveChangesAsync();

            return Ok(interest);
        }

        [HttpPut]
        public async Task<IActionResult> Update(Interest interest)
        {
            _context.Interests.Update(interest);

            await _context.SaveChangesAsync();

            return Ok(interest);
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Delete(int id)
        {
            Interest? interest = await _context.Interests.FindAsync(id);

            if (interest is null)
            {
                return NotFound();
            }

            _context.Interests.Remove(interest);

            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}