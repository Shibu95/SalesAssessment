using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Api.Entities
{
    [Table("salesrepevaluationresult", Schema = "public")]
    public class SalesRepEvaluationResult
    {
        [Key]
        public int SalesRepEvaluationResultID { get; set; }

        [Required]
        public int SalesRepID { get; set; }

        [Required]
        public int ScenarioID { get; set; }

        [Required]
        public decimal OverallScore { get; set; }

        [Required]
        public string PerformanceLevel { get; set; } = string.Empty;

        public string OverallSummary { get; set; } = string.Empty;

        public string Transcript { get; set; } = string.Empty;

        public string EvaluationJson { get; set; } = string.Empty;

        [Required]
        public DateTime CompletedOn { get; set; }
    }
}
