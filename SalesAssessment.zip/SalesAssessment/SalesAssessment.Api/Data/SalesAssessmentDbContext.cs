using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Entities;

namespace SalesAssessment.Api.Data
{
    public class SalesAssessmentDbContext : DbContext
    {
        public SalesAssessmentDbContext(DbContextOptions<SalesAssessmentDbContext> options) : base(options)
        {
        }

        public DbSet<Trainer> Trainers { get; set; }
        public DbSet<SalesRep> SalesReps { get; set; }
        public DbSet<Scenario> Scenarios { get; set; }
        public DbSet<ScenarioAssignment> ScenarioAssignments { get; set; }
        public DbSet<SalesRepEvaluationResult> SalesRepEvaluationResults { get; set; }
        public DbSet<Industry> Industries { get; set; }
        public DbSet<CustomerPersonality> CustomerPersonalities { get; set; }
        public DbSet<Interest> Interests { get; set; }
        public DbSet<Concern> Concerns { get; set; }
        public DbSet<Goal> Goals { get; set; }
        public DbSet<AssessmentStatus> AssessmentStatuses { get; set; }
        public DbSet<Role> Roles { get; set; }
        public DbSet<Batch> Batches { get; set; }
        public DbSet<BatchStatus> BatchStatuses { get; set; }
        public DbSet<BatchTrainer> BatchTrainers { get; set; }
        public DbSet<AssessmentType> AssessmentTypes => Set<AssessmentType>();
        public DbSet<Test> Tests { get; set; }
        public DbSet<TestQuestion> TestQuestions { get; set; }
    }
}