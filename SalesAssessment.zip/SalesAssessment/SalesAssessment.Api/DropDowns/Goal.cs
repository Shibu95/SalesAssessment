using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Api.Entities
{
    [Table("goal", Schema = "public")]
    public class Goal
    {
        [Key]
        public int GoalID { get; set; }

        [Required]
        public string GoalName { get; set; } = string.Empty;
    }
}