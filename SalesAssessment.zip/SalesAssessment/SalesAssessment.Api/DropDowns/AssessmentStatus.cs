using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Api.Entities
{
    [Table("assessmentstatus", Schema = "public")]
    public class AssessmentStatus
    {
        [Key]
        public int AssessmentStatusID { get; set; }

        [Required]
        public string AssessmentStatusName { get; set; } = string.Empty;
    }
}