using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace SalesAssessment.Api.Entities
{
    [Table("interest", Schema = "public")]
    public class Interest
    {
        [Key]
        public int InterestID { get; set; }

        [Required]
        public string InterestName { get; set; } = string.Empty;
    }
}