using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Services;

public sealed class ScenarioAssignmentService : IScenarioAssignmentService
{
    private readonly SalesAssessmentDbContext _context;

    public ScenarioAssignmentService(SalesAssessmentDbContext context)
    {
        _context = context;
    }

    public async Task<List<ScenarioAssignment>> GetAllAsync()
    {
        return await _context.ScenarioAssignments.OrderByDescending(x => x.AssignedOn).ToListAsync();
    }

    public async Task<List<ScenarioAssignment>> GetBySalesRepAsync(int salesRepId)
    {
        return await _context.ScenarioAssignments.Where(x => x.SalesRepID == salesRepId).ToListAsync();
    }

    public async Task<ScenarioAssignment> CreateAsync(ScenarioAssignment assignment)
    {
        _context.ScenarioAssignments.Add(assignment);
        await _context.SaveChangesAsync();
        return assignment;
    }
}