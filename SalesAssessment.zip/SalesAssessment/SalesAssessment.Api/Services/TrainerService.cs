using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Services;

public sealed class TrainerService : ITrainerService
{
    private readonly SalesAssessmentDbContext _context;

    public TrainerService(SalesAssessmentDbContext context)
    {
        _context = context;
    }

    public async Task<List<Trainer>> GetAllAsync()
    {
        return await _context.Trainers.OrderBy(x => x.EmailID).ToListAsync();
    }

    public async Task<Trainer?> GetByIdAsync(int trainerId)
    {
        return await _context.Trainers.FirstOrDefaultAsync(x => x.TrainerID == trainerId);
    }

    public async Task<Trainer> CreateAsync(Trainer trainer)
    {
        _context.Trainers.Add(trainer);
        await _context.SaveChangesAsync();
        return trainer;
    }

    public async Task<bool> DeleteAsync(int trainerId)
    {
        Trainer? trainer = await _context.Trainers.FindAsync(trainerId);

        if (trainer is null)
        {
            return false;
        }

        _context.Trainers.Remove(trainer);
        await _context.SaveChangesAsync();
        return true;
    }
}