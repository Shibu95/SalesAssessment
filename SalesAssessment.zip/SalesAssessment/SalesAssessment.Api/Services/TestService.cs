using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Services;

public sealed class TestService : ITestService
{
    private readonly SalesAssessmentDbContext _context;

    public TestService(SalesAssessmentDbContext context)
    {
        _context = context;
    }

    public async Task<List<Test>> GetAllAsync()
    {
        return await _context.Tests.OrderByDescending(x => x.AssessmentDate).ToListAsync();
    }

    public async Task<Test?> GetByIdAsync(int testId)
    {
        return await _context.Tests.FirstOrDefaultAsync(x => x.TestID == testId);
    }

    public async Task<Test> CreateAsync(Test test)
    {
        test.AssessmentDate = DateTime.SpecifyKind(test.AssessmentDate, DateTimeKind.Utc);

        test.CreatedOn = DateTime.SpecifyKind(test.CreatedOn, DateTimeKind.Utc);

        _context.Tests.Add(test);

        await _context.SaveChangesAsync();

        return test;
    }

    public async Task<Test> UpdateAsync(Test test)
    {
        test.AssessmentDate = DateTime.SpecifyKind(
                test.CreatedOn,
                DateTimeKind.Utc);
        _context.Tests.Update(test);
        await _context.SaveChangesAsync();
        return test;
    }

    public async Task<bool> DeleteAsync(int testId)
    {
        Test? test = await _context.Tests.FindAsync(testId);
        if (test is null)
        {
            return false;
        }
        _context.Tests.Remove(test);
        await _context.SaveChangesAsync();
        return true;
    }
}