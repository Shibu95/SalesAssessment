using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Services;

public sealed class TestQuestionService : ITestQuestionService
{
    private readonly SalesAssessmentDbContext _context;
    public TestQuestionService(SalesAssessmentDbContext context)
    {
        _context = context;
    }

    public async Task<List<TestQuestion>> GetByTestIdAsync(int testId)
    {
        return await _context.TestQuestions.Where(x => x.TestID == testId).ToListAsync();
    }

    public async Task<TestQuestion> CreateAsync(TestQuestion testQuestion)
    {
        _context.TestQuestions.Add(testQuestion);
        await _context.SaveChangesAsync();
        return testQuestion;
    }

    public async Task<bool> DeleteAsync(int testQuestionId)
    {
        TestQuestion? item = await _context.TestQuestions.FindAsync(testQuestionId);

        if (item is null)
        {
            return false;
        }
        _context.TestQuestions.Remove(item);
        await _context.SaveChangesAsync();
        return true;
    }
}