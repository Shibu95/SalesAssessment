using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Services;

public sealed class BatchService : IBatchService
{
    private readonly SalesAssessmentDbContext _context;

    public BatchService(SalesAssessmentDbContext context)
    {
        _context = context;
    }

    public async Task<List<Batch>> GetAllAsync()
    {
        var batches = await _context.Batches.OrderByDescending(x => x.CreatedOn).ToListAsync();

        // Enrich batches with sales rep count and trainer email
        foreach (var batch in batches)
        {
            // Get sales rep count for this batch
            batch.SalesRepCount = await _context.SalesReps.Where(sr => sr.BatchID == batch.BatchID).CountAsync();

            // Get trainer email for this batch
            var batchTrainer = await _context.BatchTrainers.Where(bt => bt.BatchID == batch.BatchID).FirstOrDefaultAsync();

            if (batchTrainer != null)
            {
                var trainer = await _context.Trainers.FirstOrDefaultAsync(t => t.TrainerID == batchTrainer.TrainerID);
                batch.TrainerEmail = trainer?.EmailID ?? string.Empty;
            }
        }

        return batches;
    }

    public async Task<Batch?> GetByIdAsync(int batchId)
    {
        return await _context.Batches.FirstOrDefaultAsync(x => x.BatchID == batchId);
    }

    public async Task<Batch> CreateAsync(Batch batch)
    {
        batch.CreatedOn = DateTime.UtcNow;
        _context.Batches.Add(batch);
        await _context.SaveChangesAsync();
        return batch;
    }

    public async Task<Batch> UpdateAsync(Batch batch)
    {
        _context.Batches.Update(batch);
        await _context.SaveChangesAsync();
        return batch;
    }

    public async Task<bool> DeleteAsync(int batchId)
    {
        Batch? batch = await _context.Batches.FindAsync(batchId);

        if (batch is null)
        {
            return false;
        }

        _context.Batches.Remove(batch);
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<List<Batch>> GetStartedBatchesAsync()
    {
        BatchStatus? startedStatus = await _context.BatchStatuses.FirstOrDefaultAsync(x => x.BatchStatusName == "Started");
        if (startedStatus is null)
        {
            return [];
        }
        return await _context.Batches.Where(x => x.BatchStatusID == startedStatus.BatchStatusID).OrderBy(x => x.BatchName).ToListAsync();
    }
}
