using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Services;

public sealed class ScenarioService : IScenarioService
{
    private readonly SalesAssessmentDbContext _context;

    public ScenarioService(SalesAssessmentDbContext context)
    {
        _context = context;
    }

    public async Task<List<Scenario>> GetAllAsync()
    {
        return await _context.Scenarios.OrderByDescending(x => x.CreatedOn).ToListAsync();
    }

    public async Task<Scenario?> GetByIdAsync(int scenarioId)
    {
        return await _context.Scenarios.FirstOrDefaultAsync(x => x.ScenarioID == scenarioId);
    }

    public async Task<Scenario> CreateAsync(Scenario scenario)
    {
        _context.Scenarios.Add(scenario);
        await _context.SaveChangesAsync();
        return scenario;
    }

    public async Task<Scenario> UpdateAsync(Scenario scenario)
    {
        _context.Scenarios.Update(scenario);
        await _context.SaveChangesAsync();
        return scenario;
    }

    public async Task<bool> DeleteAsync(int scenarioId)
    {
        Scenario? scenario = await _context.Scenarios.FindAsync(scenarioId);

        if (scenario is null)
        {
            return false;
        }

        _context.Scenarios.Remove(scenario);
        await _context.SaveChangesAsync();
        return true;
    }
}