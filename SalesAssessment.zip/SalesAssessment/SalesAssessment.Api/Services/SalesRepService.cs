using Microsoft.EntityFrameworkCore;
using SalesAssessment.Api.Data;
using SalesAssessment.Api.Entities;
using SalesAssessment.Api.Interfaces;

namespace SalesAssessment.Api.Services;

public sealed class SalesRepService : ISalesRepService
{
    private readonly SalesAssessmentDbContext _context;

    public SalesRepService(SalesAssessmentDbContext context)
    {
        _context = context;
    }

    public async Task<List<SalesRep>> GetAllAsync()
    {
        return await _context.SalesReps.OrderBy(x => x.EmailID).ToListAsync();
    }

    public async Task<SalesRep?> GetByIdAsync(int salesRepId)
    {
        return await _context.SalesReps.FirstOrDefaultAsync(x => x.SalesRepID == salesRepId);
    }

    public async Task<SalesRep> CreateAsync(SalesRep salesRep)
    {
        _context.SalesReps.Add(salesRep);
        await _context.SaveChangesAsync();
        return salesRep;
    }

    public async Task<bool> DeleteAsync(int salesRepId)
    {
        SalesRep? salesRep = await _context.SalesReps.FindAsync(salesRepId);

        if (salesRep is null)
        {
            return false;
        }

        _context.SalesReps.Remove(salesRep);
        await _context.SaveChangesAsync();
        return true;
    }
}