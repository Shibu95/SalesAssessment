using SalesAssessment.Web.Components;
using SalesAssessment.Web.Services;
using Syncfusion.Blazor;
using Microsoft.AspNetCore.Components.Authorization;

var builder = WebApplication.CreateBuilder(args);

Syncfusion.Licensing.SyncfusionLicenseProvider.RegisterLicense("Ngo9BigBOggjHTQxAR8/V1JAaF5cX2pCdkx3TXxbf1x2ZFRHal9WTnRcUiweQnxTdENjXn5XcXVWQWNfVkVyXkleZw==");

// Add services to the container.
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddSyncfusionBlazor();
builder.Services.AddCascadingAuthenticationState();
builder.Services.AddScoped<AuthenticationStateProvider, PersistentAuthenticationStateProvider>();

builder.Services.AddScoped<ApiService>();
builder.Services.AddScoped<LookupApiService>();
builder.Services.AddScoped<ScenarioApiService>();
builder.Services.AddScoped<TrainerApiService>();
builder.Services.AddScoped<SidebarService>();
builder.Services.AddScoped<SalesRepApiService>();
builder.Services.AddScoped<BatchApiService>();
builder.Services.AddScoped<TestApiService>();
builder.Services.AddScoped<TestQuestionApiService>();

builder.Services.AddScoped(sp =>
{
    HttpClient client = new()
    {
        BaseAddress = new Uri("http://localhost:5139/api/")
    };
    return client;
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
