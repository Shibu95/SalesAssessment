using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models
{
    public class Batch
    {
        public int BatchID { get; set; }

        public string BatchName { get; set; } = string.Empty;

        public DateTime StartDate { get; set; }

        public int BatchStatusID { get; set; }

        public List<int> TrainerIDs { get; set; } = [];

        public DateTime CreatedOn { get; set; }

        public int SalesRepCount { get; set; } = 0;

        public string TrainerEmail { get; set; } = string.Empty;
    }
}