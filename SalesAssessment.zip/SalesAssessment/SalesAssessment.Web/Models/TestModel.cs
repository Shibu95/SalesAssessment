using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models;

public class TestModel
{
    public int TestID { get; set; }
    public int BatchID { get; set; }
    public string TestName { get; set; } = string.Empty;
    public DateTime AssessmentDate { get; set; }
    public int BatchStatusID { get; set; }
    public DateTime CreatedOn { get; set; }
    public int CreatedByTrainerID { get; set; }
}