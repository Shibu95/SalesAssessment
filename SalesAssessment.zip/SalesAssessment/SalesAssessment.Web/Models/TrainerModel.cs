using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models
{
    public class TrainerModel
    {
        public int TrainerID { get; set; }

        public string EmailID { get; set; } = string.Empty;
        public int RoleID { get; set; }

        public DateTime CreatedOn { get; set; }
    }
}