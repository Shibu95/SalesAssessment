using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models;

public class ScenarioModel
{
    public int ScenarioID { get; set; }

    public string Title { get; set; } = string.Empty;
    public string CustomerName { get; set; } = string.Empty;
    public string Company { get; set; } = string.Empty;
    public int IndustryID { get; set; }
    public string Role { get; set; } = string.Empty;
    public string CustomerPersonality { get; set; } = string.Empty;
    public string BusinessRequirement { get; set; } = string.Empty;
    public string Concerns { get; set; } = string.Empty;
    public int CreatedByTrainerID { get; set; }
    public DateTime CreatedOn { get; set; }
}