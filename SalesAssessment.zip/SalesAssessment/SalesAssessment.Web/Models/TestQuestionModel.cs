using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models;

public class TestQuestionModel
{
    public int TestQuestionID { get; set; }
    public int TestID { get; set; }
    public int AssessmentTypeID { get; set; }
    public int NoOfQuestions { get; set; }
}