using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models
{
    public class SalesRep
    {
        public int SalesRepID { get; set; }

        public string EmailID { get; set; } = string.Empty;
        public int? BatchID { get; set; }

        public DateTime CreatedOn { get; set; }
    }
}