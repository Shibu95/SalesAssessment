using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models
{
    public class ScenarioAssignmentModel
    {
        public int ScenarioAssignmentID { get; set; }

        public int ScenarioID { get; set; }

        public int SalesRepID { get; set; }

        public int AssessmentStatusID { get; set; }

        public int AssignedByTrainerID { get; set; }

        public DateTime AssignedOn { get; set; }
    }
}