using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public class TrainerApiService
{
    private readonly ApiService _apiService;

    public TrainerApiService(
        ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task<List<TrainerModel>>
        GetAllTrainersAsync()
    {
        return await _apiService
            .GetListAsync<TrainerModel>(
                "Trainer");
    }

    public async Task CreateTrainerAsync(
        TrainerModel trainer)
    {
        await _apiService
            .PostAsync(
                "Trainer",
                trainer);
    }

    public async Task UpdateTrainerAsync(
        TrainerModel trainer)
    {
        await _apiService
            .PutAsync(
                "Trainer",
                trainer);
    }

    public async Task DeleteTrainerAsync(
        int trainerId)
    {
        await _apiService
            .DeleteAsync(
                $"Trainer/{trainerId}");
    }
}