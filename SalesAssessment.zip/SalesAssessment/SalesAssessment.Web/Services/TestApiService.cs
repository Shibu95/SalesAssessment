using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public class TestApiService
{
    private readonly ApiService _apiService;

    public TestApiService(ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task<List<TestModel>> GetAllAsync()
    {
        return await _apiService.GetListAsync<TestModel>("Test");
    }

    public async Task<TestModel?> GetByIdAsync(int testId)
    {
        return await _apiService.GetAsync<TestModel>($"Test/{testId}");
    }

    // public async Task CreateAsync(TestModel test)
    // {
    //     await _apiService.PostAsync("Test", test);
    // }
    public async Task<TestModel> CreateAsync(TestModel test)
    {
        return await _apiService.PostAndReadAsync<TestModel, TestModel>("Test", test);
    }

    public async Task UpdateAsync(TestModel test)
    {
        await _apiService.PutAsync("Test", test);
    }

    public async Task DeleteAsync(int testId)
    {
        await _apiService.DeleteAsync($"Test/{testId}");
    }

}