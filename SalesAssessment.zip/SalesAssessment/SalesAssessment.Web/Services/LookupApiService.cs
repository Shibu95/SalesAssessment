using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public class LookupApiService
{
    private readonly ApiService _apiService;

    public LookupApiService(ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task<List<T>> GetAllAsync<T>(string controller)
    {
        return await _apiService.GetListAsync<T>(controller);
    }

    public async Task<T?> GetByIdAsync<T>(string controller, int id)
    {
        return await _apiService.GetAsync<T>($"{controller}/{id}");
    }

    public async Task CreateAsync<T>(string controller, T model)
    {
        await _apiService.PostAsync(controller, model);
    }

    public async Task UpdateAsync<T>(string controller, T model)
    {
        await _apiService.PutAsync(controller, model);
    }

    public async Task DeleteAsync(string controller, int id)
    {
        await _apiService.DeleteAsync($"{controller}/{id}");
    }
}