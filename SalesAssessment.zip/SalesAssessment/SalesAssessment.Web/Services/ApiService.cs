using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Services
{
    public class ApiService
    {
        private readonly HttpClient _httpClient;

        public ApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<List<T>> GetListAsync<T>(string url)
        {
            string apiUrl = $"{_httpClient.BaseAddress}{url}";

            Console.WriteLine($"Calling API: {apiUrl}");

            return await _httpClient.GetFromJsonAsync<List<T>>(url) ?? [];
        }

        public async Task<T?> GetAsync<T>(string url)
        {
            return await _httpClient.GetFromJsonAsync<T>(url);
        }

        public async Task<HttpResponseMessage> PostAsync<T>(string url, T model)
        {
            return await _httpClient.PostAsJsonAsync(url, model);
        }

        public async Task<HttpResponseMessage> PutAsync<T>(string url, T model)
        {
            return await _httpClient.PutAsJsonAsync(url, model);
        }

        public async Task<HttpResponseMessage> DeleteAsync(string url)
        {
            return await _httpClient.DeleteAsync(url);
        }

        public async Task<TResult> PostAndReadAsync<TRequest, TResult>(string url, TRequest model)
        {
            HttpResponseMessage response = await _httpClient.PostAsJsonAsync(url, model);
            string content = await response.Content.ReadAsStringAsync();
            Console.WriteLine(content);
            response.EnsureSuccessStatusCode();
            return System.Text.Json.JsonSerializer.Deserialize<TResult>(content)!;
        }
    }
}