using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services
{
    public class BatchApiService
    {
        private readonly ApiService _apiService;

        public BatchApiService(ApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<List<Batch>> GetAllAsync()
        {
            return await _apiService.GetListAsync<Batch>("Batch");
        }

        public async Task<Batch> GetAsync(int id)
        {
            return await _apiService.GetAsync<Batch>($"Batch/{id}");
        }

        public async Task<List<int>> GetTrainersByBatchAsync(int batchId)
        {
            return await _apiService.GetListAsync<int>($"Batch/{batchId}/trainers");
        }

        public async Task<Batch> CreateAsync(Batch batch)
        {
            var response = await _apiService.PostAsync("Batch", batch);

            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                return System.Text.Json.JsonSerializer.Deserialize<Batch>(content,
                    new System.Text.Json.JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? new Batch();
            }

            return new Batch();
        }

        public async Task UpdateAsync(Batch batch)
        {
            await _apiService.PutAsync("Batch", batch);
        }

        public async Task DeleteAsync(int id)
        {
            await _apiService.DeleteAsync($"Batch/{id}");
        }

        public async Task AssignTrainersAsync(int batchId, List<int> trainerIds)
        {
            var payload = new { batchId, trainerIds };
            await _apiService.PostAsync("Batch/assign-trainers", payload);
        }

        public async Task UploadSalesRepsAsync(int batchId, List<string> emailIds)
        {
            var payload = new { batchId, emailIds };
            await _apiService.PostAsync("Batch/upload-sales-reps", payload);
        }

        public async Task<List<Batch>> GetStartedBatchesAsync()
        {
            return await _apiService.GetListAsync<Batch>("Batch/started");
        }
    }
}