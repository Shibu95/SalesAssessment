using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public class TestQuestionApiService
{
    private readonly ApiService _apiService;

    public TestQuestionApiService(ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task<List<TestQuestionModel>> GetByTestIdAsync(int testId)
    {
        return await _apiService.GetListAsync<TestQuestionModel>($"TestQuestion/{testId}");
    }

    public async Task CreateAsync(TestQuestionModel model)
    {
        await _apiService.PostAsync("TestQuestion", model);
    }

    public async Task DeleteAsync(int id)
    {
        await _apiService.DeleteAsync($"TestQuestion/{id}");
    }
}