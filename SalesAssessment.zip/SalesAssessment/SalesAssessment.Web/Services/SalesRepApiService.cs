using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services
{
    public class SalesRepApiService
    {
        private readonly ApiService _apiService;

        public SalesRepApiService(
            ApiService apiService)
        {
            _apiService = apiService;
        }

        public async Task<List<SalesRep>>
            GetAllAsync()
        {
            return await _apiService
                .GetListAsync<SalesRep>(
                    "SalesRep");
        }

        public async Task CreateAsync(
            SalesRep salesRep)
        {
            await _apiService
                .PostAsync(
                    "SalesRep",
                    salesRep);
        }

        public async Task UpdateAsync(
            SalesRep salesRep)
        {
            await _apiService
                .PutAsync(
                    "SalesRep",
                    salesRep);
        }

        public async Task DeleteAsync(
            int id)
        {
            await _apiService
                .DeleteAsync(
                    $"SalesRep/{id}");
        }
    }
}