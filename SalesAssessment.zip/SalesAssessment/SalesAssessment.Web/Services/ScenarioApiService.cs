using SalesAssessment.Web.Models;

namespace SalesAssessment.Web.Services;

public class ScenarioApiService
{
    private readonly ApiService _apiService;

    public ScenarioApiService(ApiService apiService)
    {
        _apiService = apiService;
    }

    public async Task<List<ScenarioModel>> GetAllScenariosAsync()
    {
        return await _apiService.GetListAsync<ScenarioModel>("Scenario");
    }

    public async Task<ScenarioModel?> GetScenarioByIdAsync(int scenarioId)
    {
        return await _apiService.GetAsync<ScenarioModel>($"Scenario/{scenarioId}");
    }

    public async Task CreateScenarioAsync(ScenarioModel scenario)
    {
        scenario.CreatedByTrainerID = 1;
        await _apiService.PostAsync("Scenario", scenario);
    }

    public async Task UpdateScenarioAsync(ScenarioModel scenario)
    {
        await _apiService.PutAsync("Scenario", scenario);
    }

    public async Task DeleteScenarioAsync(int scenarioId)
    {
        await _apiService.DeleteAsync($"Scenario/{scenarioId}");
    }
}