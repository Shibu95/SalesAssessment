using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.Models;

public class AssessmentTypeModel
{
    public int AssessmentTypeID { get; set; }

    public string AssessmentTypeName { get; set; } = string.Empty;
}