namespace SalesAssessment.Web.DropDowns;

public class Role
{
    public int RoleID { get; set; }

    public string RoleName { get; set; } = string.Empty;
}