using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.DropDowns
{
    public class Interest
    {
        public int InterestID { get; set; }
        public string InterestName { get; set; } = string.Empty;
    }
}