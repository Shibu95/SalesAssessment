using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.DropDowns
{
    public class Goal
    {
        public int GoalID { get; set; }
        public string GoalName { get; set; } = string.Empty;
    }
}