using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.DropDowns
{
    public class Concern
    {
        public int ConcernID { get; set; }
        public string ConcernName { get; set; } = string.Empty;
    }
}