using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.DropDowns
{
    public class Industry
    {
        public int IndustryID { get; set; }
        public string IndustryName { get; set; } = string.Empty;
    }
}