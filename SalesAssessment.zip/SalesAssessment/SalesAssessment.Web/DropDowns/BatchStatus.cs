using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.DropDowns
{
    public class BatchStatus
    {
        public int BatchStatusID { get; set; }

        public string BatchStatusName { get; set; } = string.Empty;
    }
}