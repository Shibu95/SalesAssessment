using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.DropDowns
{
    public class CustomerPersonality
    {
        public int CustomerPersonalityID { get; set; }
        public string Personality { get; set; } = string.Empty;
    }
}