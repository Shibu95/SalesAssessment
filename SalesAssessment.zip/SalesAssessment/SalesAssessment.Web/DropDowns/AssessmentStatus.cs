using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SalesAssessment.Web.DropDowns
{
    public class AssessmentStatus
    {
        public int AssessmentStatusID { get; set; }
        public string AssessmentStatusName { get; set; } = string.Empty;
    }
}